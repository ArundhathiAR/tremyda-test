# TrePortal

Health Portal based on Next JS

## Getting Started

Follow these instructions to get the project up and running on your local machine.

### Prerequisites

Make sure you have Node.js version 20.12.2 installed on your machine.

You can install Node.js version 20.12.2 from [Node.js website](https://nodejs.org/).

### Installation

1. Clone the repository to your local machine:

```bash
git clone https://github.com/your-username/project-name.git

```

2. Navigate into the project directory:

```bash
cd project-name
```

# Install pakages and dependencies

To run the Next.js project:

```bash
npm install
```

# Running the Next.js Project

To run the Next.js project:

```bash
npm run dev
```

This will start the development server and the application will be accessible at http://localhost:3000.

# Running Storybook

To run Storybook and test components:

```bash
npm run storybook
```

# Build the Next.js Project

To run the Next.js project:

```bash
npm run build
```
