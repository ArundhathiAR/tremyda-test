// utils/websocket.js
const WEBSOCKET_URL =
  'wss://4eku3cs6h1.execute-api.ap-south-1.amazonaws.com/dev';

export const createWebSocketConnection = () => {
  const socket = new WebSocket(WEBSOCKET_URL);

  socket.onopen = () => {
    console.log('WebSocket connection established');
  };

  socket.onmessage = (event) => {
    console.log('Message from server: ', event.data);
    // Handle incoming messages (user activity updates)
  };

  socket.onclose = (event) => {
    console.log('WebSocket connection closed: ', event);
  };

  socket.onerror = (error) => {
    console.error('WebSocket error: ', error);
  };

  return socket;
};
