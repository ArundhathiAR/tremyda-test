import type { Meta, StoryObj } from '@storybook/react';
import PageDemo from './PageDemo';

const meta = {
  title: 'Layout/Page',
  component: PageDemo,
  parameters: {
    layout: 'centered'
  }
} as Meta<typeof PageDemo>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};
