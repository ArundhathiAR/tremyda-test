import type { Meta, StoryObj } from '@storybook/react';
import HeaderDemo from './HeaderDemo';

const meta = {
  title: 'Layout/Header',
  component: HeaderDemo,
  parameters: {
    layout: 'centered'
  }
} as Meta<typeof HeaderDemo>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};
