import type { Meta, StoryObj } from '@storybook/react';
import SidebarDemo from './SidebarDemo';

const meta = {
  title: 'Layout/Sidebar',
  component: SidebarDemo,
  parameters: {
    layout: 'centered'
  }
} as Meta<typeof SidebarDemo>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};
