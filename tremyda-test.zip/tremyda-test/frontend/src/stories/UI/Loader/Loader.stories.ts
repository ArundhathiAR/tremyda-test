import { LoadingSpinner } from '@/components/ui/loader';
import type { Meta, StoryObj } from '@storybook/react';

const meta = {
  title: 'UI/Loader',
  component: LoadingSpinner,
  parameters: {
    layout: 'centered'
  }
} as Meta<typeof LoadingSpinner>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Primary: Story = {};

export const Large: Story = {
  args: {
    className: 'size-20'
  }
};
