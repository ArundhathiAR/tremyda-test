import * as React from 'react';

import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';

export function SelectDemo() {
  return (
    <Select>
      <SelectTrigger className="w-[180px]">
        <SelectValue placeholder="Select a Item" />
      </SelectTrigger>
      <SelectContent>
        <SelectGroup>
          <SelectLabel>ITEMS</SelectLabel>
          <SelectItem value="item1">Item1</SelectItem>
          <SelectItem value="item2">Item2</SelectItem>
          <SelectItem value="item3">Item3</SelectItem>
          <SelectItem value="item4">Item4</SelectItem>
          <SelectItem value="item5">Item5</SelectItem>
        </SelectGroup>
      </SelectContent>
    </Select>
  );
}
