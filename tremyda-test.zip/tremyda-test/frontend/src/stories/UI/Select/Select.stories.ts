import type { Meta, StoryObj } from '@storybook/react';
import { SelectDemo } from './SelectDemo';

const meta = {
  title: 'UI/Select',
  component: SelectDemo,
  parameters: {
    layout: 'centered'
  }
} as Meta<typeof SelectDemo>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};
