import type { Meta, StoryObj } from '@storybook/react';
import DialogDemo from './DialogDemo';

const meta = {
  title: 'UI/Dialog',
  component: DialogDemo,
  parameters: {
    layout: 'centered'
  }
} as Meta<typeof DialogDemo>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};
