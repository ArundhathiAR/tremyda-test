import type { Meta, StoryObj } from '@storybook/react';
import { CardDemo } from './CardDemo';

const meta = {
  title: 'UI/Card',
  component: CardDemo,
  parameters: {
    layout: 'centered'
  }
} as Meta<typeof CardDemo>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Teritory1: Story = {
  args: {
    variant: 'default',
    title: 'Cohorts',
    number: 40
  }
};

export const Teritory2: Story = {
  args: {
    variant: 'teritory2',
    title: 'Subjects',
    number: 20
  }
};

export const Teritory3: Story = {
  args: {
    variant: 'teritory3',
    title: 'Sites',
    number: 94
  }
};

export const Teritory4: Story = {
  args: {
    variant: 'teritory4',
    title: 'Devices',
    number: 21
  }
};
