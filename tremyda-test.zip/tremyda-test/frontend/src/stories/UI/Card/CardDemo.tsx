import * as React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { FlaskConical } from 'lucide-react';
import { cva } from 'class-variance-authority';
import { cn } from '@/lib/utils';

type Variant =
  | 'default'
  | 'teritory2'
  | 'teritory3'
  | 'teritory4'
  | null
  | undefined;

const cardVariants = cva('w-[250px]', {
  variants: {
    variant: {
      default: 'bg-tertiary-dark',
      teritory2: 'bg-tertiary-light',
      teritory3: 'bg-tertiary-lighter',
      teritory4: 'bg-tertiary-lightest'
    }
  },
  defaultVariants: {
    variant: 'default'
  }
});

type CardProp = {
  variant?: Variant;
  title: string;
  number: number;
  icon?: any;
};

export function CardDemo({
  variant = 'default',
  title = 'title',
  number = 0,
  icon = <FlaskConical size={24} />
}: CardProp) {
  return (
    <Card className={cn(cardVariants({ variant }))}>
      <CardContent className="flex mt-4 bt-4 justify-between">
        <div className="flex flex-col gap-2">
          <h6 className="text-xl">{title}</h6>
          <h1 className="text-2xl font-extrabold ml-1">{number}</h1>
        </div>
        <div className="flex items-center justify-center mt-5 mr-2 bg-white rounded-md rotate-45 size-10">
          <span className="-rotate-45">{icon}</span>
        </div>
      </CardContent>
    </Card>
  );
}
