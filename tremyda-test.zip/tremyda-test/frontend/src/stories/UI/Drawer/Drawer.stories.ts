import type { Meta, StoryObj } from '@storybook/react';
import { DrawerDemo } from './DrawerDemo';

const meta = {
  title: 'UI/Drawer',
  component: DrawerDemo,
  parameters: {
    layout: 'centered'
  }
} as Meta<typeof DrawerDemo>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};
