import { Button } from '@/components/ui/button';
import type { Meta, StoryObj } from '@storybook/react';

const meta = {
  title: 'UI/Button',
  component: Button,
  parameters: {
    layout: 'centered'
  }
} as Meta<typeof Button>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Primary: Story = {
  args: {
    variant: 'default',
    children: 'Button'
  }
};

export const Secondary: Story = {
  args: {
    variant: 'secondary',
    children: 'Button'
  }
};

export const SmallDestructive: Story = {
  args: {
    variant: 'destructive',
    size: 'sm',
    children: 'Btn'
  }
};

export const LoadingPrimary: Story = {
  args: {
    children: 'Submit',
    loader: true
  }
};

export const LoadingSecondary: Story = {
  args: {
    children: 'Submit',
    variant: 'secondary',
    loader: true
  }
};
