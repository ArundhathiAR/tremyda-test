import type { Meta, StoryObj } from '@storybook/react';
import { CheckboxDemo } from './CheckboxDemo';

const meta = {
  title: 'UI/Checkbox',
  component: CheckboxDemo,
  parameters: {
    layout: 'centered'
  }
} as Meta<typeof CheckboxDemo>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};
