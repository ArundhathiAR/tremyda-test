import type { Meta, StoryObj } from '@storybook/react';
import { SkeletonDemo } from './SkeletonDemo';

const meta = {
  title: 'UI/Skeleton',
  component: SkeletonDemo,
  parameters: {
    layout: 'centered'
  }
} as Meta<typeof SkeletonDemo>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Primary: Story = {
  args: {
    variant: 'primary'
  }
};

export const Secondary: Story = {
  args: {
    variant: 'secondary'
  }
};
