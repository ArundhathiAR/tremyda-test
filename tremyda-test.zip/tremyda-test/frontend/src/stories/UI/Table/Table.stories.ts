import type { Meta, StoryObj } from '@storybook/react';
import { DataTableDemo } from './TableDemo';

const meta = {
  title: 'UI/DataTable',
  component: DataTableDemo,
  parameters: {
    layout: 'centered'
  }
} as Meta<typeof DataTableDemo>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Primary: Story = {};
