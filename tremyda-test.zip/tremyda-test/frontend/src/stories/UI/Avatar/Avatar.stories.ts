import type { Meta, StoryObj } from '@storybook/react';
import AvatarDemo from './AvatarDemo';

const meta = {
  title: 'UI/Avatar',
  component: AvatarDemo,
  parameters: {
    layout: 'centered'
  }
} as Meta<typeof AvatarDemo>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Primary: Story = {
  args: {
    src: 'https://static.vecteezy.com/system/resources/thumbnails/006/487/917/small_2x/man-avatar-icon-free-vector.jpg',
    alt: 'ASD',
    fallback: 'SK'
  }
};

export const Name: Story = {
  args: {
    src: '',
    alt: 'ASD',
    fallback: 'SK'
  }
};
