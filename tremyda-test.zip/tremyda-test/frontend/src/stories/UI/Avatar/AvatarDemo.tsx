import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

type AvatarIconProp = {
  src: string;
  fallback?: string;
  alt?: string;
  className?: string;
};

const AvatarDemo = ({
  src,
  alt = 'Avatar',
  fallback = 'AV',
  ...prop
}: AvatarIconProp) => {
  return (
    <Avatar {...prop}>
      <AvatarImage src={src} alt={alt} />
      <AvatarFallback>{fallback}</AvatarFallback>
    </Avatar>
  );
};

export default AvatarDemo;
