import './globals.css';
import type { Metadata } from 'next';
import { cn } from '@/lib/utils';
import { roboto } from '@/lib/fonts/fonts';
// import { Roboto } from 'next/font/google';
import { ToastProvier } from '@/components/molecules/ToastProvider/ToastProvider';
import { app } from '@/constants/config';

// const roboto = Roboto({
//   subsets: ['latin'],
//   weight: ['100', '300', '400', '500', '700', '900'],
//   variable: '--font-roboto'
// });

export const metadata: Metadata = {
  title: app.name,
  description: app.description
};

export default function RootLayout({
  children
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={cn(
          roboto.variable,
          'font-semibold min-h-screen bg-background antialiased tracking-wide'
        )}
      >
        {children}
        <ToastProvier />
      </body>
    </html>
  );
}
