import VerifyEmailForm from '@/components/molecules/Forms/VerifyEmail';
import { LoginIntroSection } from '@/components/molecules/LoginIntroSection/LoginIntroSection';
import { Suspense } from 'react';

export default function VerifyEmail() {
  return (
    <div className="grid grid-cols-7 h-screen">
      <LoginIntroSection />
      <div className="flex  flex-col col-span-7 md:col-span-3 justify-center items-center bg-white p-8">
        <Suspense fallback={<div>Loading...</div>}>
          <VerifyEmailForm />
        </Suspense>
      </div>
    </div>
  );
}
