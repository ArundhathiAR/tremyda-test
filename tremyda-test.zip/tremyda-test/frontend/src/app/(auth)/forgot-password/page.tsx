import ForgotPasswordForm from '@/components/molecules/Forms/ForgotPassword';
import LoginForm from '@/components/molecules/Forms/Login';
import { LoginIntroSection } from '@/components/molecules/LoginIntroSection/LoginIntroSection';

export default function ForgotPassword() {
  return (
    <div className="grid grid-cols-7 h-screen">
      <LoginIntroSection />
      <div className="flex  flex-col col-span-7 md:col-span-3 justify-center items-center bg-white p-8">
        <ForgotPasswordForm />
      </div>
    </div>
  );
}
