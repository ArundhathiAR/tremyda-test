import Link from 'next/link';
import { HomeIcon } from 'lucide-react';

export default function NotFound() {
  return (
    <div className="flex h-screen justify-center items-center bg-gray-100">
      <div className="bg-white rounded-md shadow-md flex flex-col items-center justify-center px-10 py-10 max-w-md">
        <h2 className="text-2xl font-bold mb-2">404 - Page Not Found</h2>
        <p className="text-gray-600 mb-4">Could not find requested resource</p>
        <Link href="/" legacyBehavior>
          <span className="flex items-center text-blue-600 hover:text-blue-800 cursor-pointer">
            <HomeIcon className="w-5 h-5 mr-2" />
            Return Home
          </span>
        </Link>
      </div>
    </div>
  );
}
