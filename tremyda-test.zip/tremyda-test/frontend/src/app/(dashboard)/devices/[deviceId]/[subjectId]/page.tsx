'use client';
import { Slash } from 'lucide-react';
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbList,
  BreadcrumbSeparator
} from '@/components/ui/breadcrumb';
import Image from 'next/image';
import BigCalendar from '@/components/molecules/BigCalendar/BigCalendar';
import { getLastFourDigits } from '@/lib/utils';
import { useCallback, useEffect, useState } from 'react';
import api from '@/lib/services/apiWrapper';
import { LoadingSpinner } from '@/components/ui/loader';
import Link from 'next/link';
import { bp_data } from '@/constants';

interface DevicesProps {
  params: {
    deviceId: string;
    subjectId: string;
  };
}

interface BreadcrumbProps {
  deviceId: string;
  subjectId: string;
}

interface Event {
  cohortStop: string;
  readingStop: string;
  cohortStart: string;
  eventType: string;
  readingStart: string;
}

export default function Devices({ params }: DevicesProps) {
  const { subjectId } = params;
  const deviceId = decodeURIComponent(params.deviceId);
  const [events, setEvents] = useState<Event[]>([]);
  const [loader, setLoader] = useState<boolean>(true);

  const fetchEvents = useCallback(async () => {
    try {
      const res = await api.get(
        `/subjects/${subjectId}/devices/${deviceId}/events`
      );
      if (res.status === 200) {
        const payload = [...res.data.items, ...bp_data];
        setEvents(payload);
      }
    } catch (error) {
      console.error('Failed to fetch events:', error);
    } finally {
      setLoader(false);
    }
  }, []);

  useEffect(() => {
    fetchEvents();
  }, [fetchEvents]);

  return (
    <div>
      <BreadcrumbWithCustomSeparator
        deviceId={deviceId}
        subjectId={subjectId}
      />
      <div className="mt-10">
        {loader ? (
          <div className="flex items-center justify-center mt-64">
            <LoadingSpinner />
          </div>
        ) : (
          <BigCalendar events={events} />
        )}
      </div>
    </div>
  );
}

function BreadcrumbWithCustomSeparator({
  deviceId,
  subjectId
}: BreadcrumbProps) {
  return (
    <Breadcrumb>
      <BreadcrumbList>
        <BreadcrumbItem>
          <Link href={`/devices/${deviceId}`}>
            <Image
              src="/icons/left-arrow.svg"
              width={25}
              height={25}
              alt="back"
            />
          </Link>
        </BreadcrumbItem>
        <BreadcrumbItem className="text-lg">Devices</BreadcrumbItem>
        <BreadcrumbSeparator>
          <Slash />
        </BreadcrumbSeparator>
        <BreadcrumbItem className="text-lg">
          Device #{getLastFourDigits(deviceId)}
        </BreadcrumbItem>
        <BreadcrumbSeparator>
          <Slash />
        </BreadcrumbSeparator>
        <BreadcrumbItem className="text-lg">
          Subject #{getLastFourDigits(subjectId)}
        </BreadcrumbItem>
        <BreadcrumbSeparator>
          <Slash />
        </BreadcrumbSeparator>
        <BreadcrumbItem className="text-xl font-semibold">
          Activity
        </BreadcrumbItem>
      </BreadcrumbList>
    </Breadcrumb>
  );
}
