'use client';
import { Slash } from 'lucide-react';
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbList,
  BreadcrumbSeparator
} from '@/components/ui/breadcrumb';
import Image from 'next/image';
import { DataTable } from '@/components/molecules/DataTable/DataTable';
import AddSubject from '@/components/molecules/Forms/AddSubject';
import api from '@/lib/services/apiWrapper';
import { SubjectsColumns } from '@/lib/TableColumns/subjects';
import { useRouter } from 'next/navigation';
import React, { useCallback, useEffect, useState } from 'react';
import { getLastFourDigits } from '@/lib/utils';
import Link from 'next/link';

type SubjectsProps = {
  params: {
    deviceId: string;
  };
};

interface BreadcrumbProps {
  deviceId: string;
}

export default function Subjects({ params }: SubjectsProps) {
  const deviceId = decodeURIComponent(params.deviceId);
  const router = useRouter();
  const [subjects, setSubjects] = useState([]);
  const [loader, setLoader] = useState(true);

  const fetchSubjects = useCallback(async () => {
    try {
      const res = await api.get(`/subjects?deviceid=${deviceId}`);
      if (res.status === 200) {
        setSubjects(res.data.items);
      }
    } catch (error) {
      console.error('Failed to fetch sites:', error);
    } finally {
      setLoader(false);
    }
  }, []);

  useEffect(() => {
    fetchSubjects();
  }, [fetchSubjects]);

  const handleRowClick = (row: any) => {
    router.push(`/devices/${deviceId}/${row.original.subjectId}`);
  };

  return (
    <div>
      <BreadcrumbWithCustomSeparator deviceId={deviceId} />
      <DataTable
        title=""
        columns={SubjectsColumns}
        data={subjects}
        handleRowClick={handleRowClick}
        HeaderButtonComponent={AddSubject}
        HeaderButtonComponentProps={{}}
        enableSearch={true}
        loader={loader}
      />
    </div>
  );
}

function BreadcrumbWithCustomSeparator({ deviceId }: BreadcrumbProps) {
  return (
    <Breadcrumb>
      <BreadcrumbList>
        <BreadcrumbItem>
          <Link href={`/devices`}>
            <Image
              src="/icons/left-arrow.svg"
              width={25}
              height={25}
              alt="back"
            />
          </Link>
        </BreadcrumbItem>
        <BreadcrumbItem className="text-lg">Devices</BreadcrumbItem>
        <BreadcrumbSeparator>
          <Slash />
        </BreadcrumbSeparator>
        <BreadcrumbItem className="text-lg">
          Device #{getLastFourDigits(deviceId)}
        </BreadcrumbItem>
        <BreadcrumbSeparator>
          <Slash />
        </BreadcrumbSeparator>
        <BreadcrumbItem className="text-xl">Subjects</BreadcrumbItem>
      </BreadcrumbList>
    </Breadcrumb>
  );
}
