'use client';
import { DataTable } from '@/components/molecules/DataTable/DataTable';
import api from '@/lib/services/apiWrapper';
import { DevicesColumns } from '@/lib/TableColumns/devices';
import { useRouter } from 'next/navigation';
import { useCallback, useEffect, useState } from 'react';
// import { useRouter } from 'next/navigation';

export default function Devices() {
  const router = useRouter();
  const [devices, setDevices] = useState([]);
  const [loader, setLoader] = useState(true);

  const fetchDevices = useCallback(async () => {
    try {
      const res = await api.get('/devices');
      if (res.status === 200) {
        setDevices(res.data.items);
      }
    } catch (error) {
      console.error('Failed to fetch sites:', error);
    } finally {
      setLoader(false);
    }
  }, []);

  useEffect(() => {
    fetchDevices();
  }, [fetchDevices]);

  const handleRowClick = (row: any) => {
    router.push(`/devices/${row.original.deviceId}`);
  };

  return (
    <div>
      <DataTable
        title="Devices"
        columns={DevicesColumns}
        data={devices}
        handleRowClick={handleRowClick}
        enableSearch={true}
        loader={loader}
      />
    </div>
  );
}
