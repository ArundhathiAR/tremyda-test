'use client';
import { DataTable } from '@/components/molecules/DataTable/DataTable';
import { InviteUser } from '@/components/molecules/Modals/InviteUser/InviteUser';
import api from '@/lib/services/apiWrapper';
import { UsersColumn } from '@/lib/TableColumns/users';
import { useUsersStore } from '@/store/users/users';
import { useRouter } from 'next/navigation';
import React, { useCallback, useEffect, useState } from 'react';
import toast from 'react-hot-toast';

export default function Subjects() {
  const router = useRouter();
  const [loader, setLoader] = useState(true);
  const { userStore, updateUsers } = useUsersStore((state) => state);

  const fetchUsers = useCallback(async () => {
    try {
      const res = await api.get('/users');
      console.log(res.data);

      if (res.status === 200) {
        updateUsers({ users: res.data.items });
      }
    } catch (error) {
      console.error('Failed to fetch users:', error);
    } finally {
      setLoader(false);
    }
  }, []);

  useEffect(() => {
    fetchUsers();
  }, [fetchUsers]);

  const handleRowClick = (row: any) => {};

  return (
    <div>
      <DataTable
        title="Users"
        columns={UsersColumn}
        data={userStore.users || []}
        handleRowClick={handleRowClick}
        HeaderButtonComponent={InviteUser}
        HeaderButtonComponentProps={{}}
        enableSearch={true}
        loader={loader}
      />
    </div>
  );
}
