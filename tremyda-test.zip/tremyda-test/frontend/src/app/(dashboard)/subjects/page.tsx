'use client';
import { DataTable } from '@/components/molecules/DataTable/DataTable';
import AddSubject from '@/components/molecules/Forms/AddSubject';
import api from '@/lib/services/apiWrapper';
import { SubjectsColumns } from '@/lib/TableColumns/subjects';
import { noDevicesLinkedMessage } from '@/lib/utils';
import { useSubjectsStore } from '@/store/subjects/subjects';
import { useRouter } from 'next/navigation';
import React, { useCallback, useEffect, useState } from 'react';
import toast from 'react-hot-toast';

export default function Subjects() {
  const router = useRouter();
  const [loader, setLoader] = useState(true);
  const { subjectStore, updateSubjects } = useSubjectsStore((state) => state);

  const fetchSubjects = useCallback(async () => {
    try {
      const res = await api.get('/subjects');
      if (res.status === 200) {
        // setSubjects(res.data.items);
        updateSubjects({ subjects: res.data.items });
      }
    } catch (error) {
      console.error('Failed to fetch sites:', error);
    } finally {
      setLoader(false);
    }
  }, []);

  useEffect(() => {
    fetchSubjects();
  }, [fetchSubjects]);

  const handleRowClick = (row: any) => {
    if (row.original.numberOfDevices > 0) {
      router.push('/subjects/' + row.original.subjectId);
    } else {
      noDevicesLinkedMessage();
    }
  };

  return (
    <div>
      <DataTable
        title="Subjects"
        columns={SubjectsColumns}
        data={subjectStore.subjects}
        handleRowClick={handleRowClick}
        HeaderButtonComponent={AddSubject}
        HeaderButtonComponentProps={{}}
        enableSearch={true}
        loader={loader}
      />
    </div>
  );
}
