'use client';
import { Slash } from 'lucide-react';
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbList,
  BreadcrumbSeparator
} from '@/components/ui/breadcrumb';
import { DataTable } from '@/components/molecules/DataTable/DataTable';
import { DevicesColumns } from '@/lib/TableColumns/devices';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { getLastFourDigits } from '@/lib/utils';
import { useCallback, useEffect, useState } from 'react';
import api from '@/lib/services/apiWrapper';
import Link from 'next/link';

interface DevicesProps {
  params: any;
}

interface BreadcrumbProps {
  cohortId: string;
  subjectId: string;
}

export default function Devices({ params }: DevicesProps) {
  const { cohortId, subjectId } = params;
  const router = useRouter();
  const [devices, setDevices] = useState([]);
  const [loader, setLoader] = useState(true);

  const fetchDevices = useCallback(async () => {
    try {
      const res = await api.get(`/subjects/${subjectId}/devices`);
      if (res.status === 200) {
        setDevices(res.data.items);
      }
    } catch (error) {
      console.error('Failed to fetch devices:', error);
    } finally {
      setLoader(false);
    }
  }, []);

  useEffect(() => {
    fetchDevices();
  }, [fetchDevices]);

  const handleRowClick = (row: any) => {
    router.push(`/cohorts/${cohortId}/${subjectId}/${row.original.deviceId}`);
  };

  return (
    <div>
      <BreadcrumbWithCustomSeparator
        cohortId={cohortId}
        subjectId={subjectId}
      />
      <DataTable
        title=""
        columns={DevicesColumns}
        data={devices}
        handleRowClick={handleRowClick}
        enableSearch={true}
        loader={loader}
      />
    </div>
  );
}

function BreadcrumbWithCustomSeparator({
  cohortId,
  subjectId
}: BreadcrumbProps) {
  return (
    <Breadcrumb>
      <BreadcrumbList>
        <BreadcrumbItem>
          <Link href={`/cohorts/${cohortId}`}>
            <Image
              src="/icons/left-arrow.svg"
              width={25}
              height={25}
              alt="back"
            />
          </Link>
        </BreadcrumbItem>
        <BreadcrumbItem className="text-lg">Cohorts</BreadcrumbItem>
        <BreadcrumbSeparator className="mx-0">
          <Slash />
        </BreadcrumbSeparator>
        <BreadcrumbItem className="text-lg font-semibold">
          Cohort #{getLastFourDigits(cohortId)}
        </BreadcrumbItem>
        <BreadcrumbSeparator>
          <Slash />
        </BreadcrumbSeparator>
        <BreadcrumbItem className="text-lg font-semibold">
          Subject #{getLastFourDigits(subjectId)}
        </BreadcrumbItem>
        <BreadcrumbSeparator>
          <Slash />
        </BreadcrumbSeparator>
        <BreadcrumbItem className="text-xl font-semibold">
          Devices
        </BreadcrumbItem>
      </BreadcrumbList>
    </Breadcrumb>
  );
}
