'use client';
import { Slash } from 'lucide-react';
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbList,
  BreadcrumbSeparator
} from '@/components/ui/breadcrumb';
import Image from 'next/image';
import BigCalendar from '@/components/molecules/BigCalendar/BigCalendar';
import { getLastFourDigits } from '@/lib/utils';
import { useCallback, useEffect, useState } from 'react';
import api from '@/lib/services/apiWrapper';
import { LoadingSpinner } from '@/components/ui/loader';
import Link from 'next/link';
import { bp_data } from '@/constants';

interface DevicesProps {
  params: {
    cohortId: string;
    subjectId: string;
    deviceId: string;
  };
}

interface BreadcrumbProps {
  cohortId: string;
  subjectId: string;
  deviceId: string;
}

interface Event {
  eventType: string;
  readingStart: string;
  readingStop: string;
}

export default function Devices({ params }: DevicesProps) {
  const { cohortId, subjectId } = params;
  const deviceId = decodeURIComponent(params.deviceId);
  const [events, setEvents] = useState<Event[]>([]);
  const [loader, setLoader] = useState<boolean>(true);

  // const events = [
  //   {
  //     title: 'New Activity',
  //     start: new Date(2024, 4, 27, 12, 0),
  //     end: new Date(2024, 4, 27, 12, 50),
  //     color: 'blue'
  //   },
  //   {
  //     title: 'New Activity',
  //     start: new Date(2024, 4, 28, 3, 0),
  //     end: new Date(2024, 4, 28, 3, 50),
  //     color: 'pink'
  //   },
  //   {
  //     title: 'New Activity',
  //     start: new Date(2024, 4, 29, 8, 0),
  //     end: new Date(2024, 4, 29, 8, 50),
  //     color: 'blue'
  //   }
  // ];

  // const handleRowClick = (row: any) => {
  //   console.log(row.original);
  // };

  const fetchEvents = useCallback(async () => {
    try {
      const res = await api.get(
        `/subjects/${subjectId}/devices/${deviceId}/events`
      );
      if (res.status === 200) {
        const payload = [...res.data.items, ...bp_data];
        setEvents(payload);
      }
    } catch (error) {
      console.error('Failed to fetch events:', error);
    } finally {
      setLoader(false);
    }
  }, []);

  useEffect(() => {
    fetchEvents();
  }, [fetchEvents]);

  return (
    <div>
      <BreadcrumbWithCustomSeparator
        cohortId={cohortId}
        subjectId={subjectId}
        deviceId={deviceId}
      />
      <div className="mt-10">
        {loader ? (
          <div className="flex items-center justify-center mt-64">
            <LoadingSpinner />
          </div>
        ) : (
          <BigCalendar events={events} />
        )}
      </div>
    </div>
  );
}

function BreadcrumbWithCustomSeparator({
  cohortId,
  subjectId,
  deviceId
}: BreadcrumbProps) {
  return (
    <Breadcrumb>
      <BreadcrumbList>
        <BreadcrumbItem>
          <Link href={`/cohorts/${cohortId}/${subjectId}`}>
            <Image
              src="/icons/left-arrow.svg"
              width={25}
              height={25}
              alt="back"
            />
          </Link>
        </BreadcrumbItem>
        <BreadcrumbItem className="text-lg">Cohorts</BreadcrumbItem>
        <BreadcrumbSeparator>
          <Slash />
        </BreadcrumbSeparator>
        <BreadcrumbItem className="text-lg">
          Cohort #{getLastFourDigits(cohortId)}
        </BreadcrumbItem>
        <BreadcrumbSeparator>
          <Slash />
        </BreadcrumbSeparator>
        <BreadcrumbItem className="text-lg">
          Subject #{getLastFourDigits(subjectId)}
        </BreadcrumbItem>
        <BreadcrumbSeparator>
          <Slash />
        </BreadcrumbSeparator>
        <BreadcrumbItem className="text-lg">
          Device #{getLastFourDigits(deviceId)}
        </BreadcrumbItem>
        <BreadcrumbSeparator>
          <Slash />
        </BreadcrumbSeparator>
        <BreadcrumbItem className="text-xl font-semibold">
          Activity
        </BreadcrumbItem>
      </BreadcrumbList>
    </Breadcrumb>
  );
}
