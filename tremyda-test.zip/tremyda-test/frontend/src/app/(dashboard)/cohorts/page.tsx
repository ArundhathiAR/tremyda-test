'use client';
import { DataTable } from '@/components/molecules/DataTable/DataTable';
import AddCohort from '@/components/molecules/Forms/AddCohort';
import api from '@/lib/services/apiWrapper';
import { CohortColumns } from '@/lib/TableColumns/cohorts';
import { useCohortsStore } from '@/store/cohorts/cohorts';
import { useRouter } from 'next/navigation';
import { useCallback, useEffect, useState } from 'react';

export default function Cohorts() {
  const router = useRouter();
  const [loader, setLoader] = useState<boolean>(true);
  const { cohortStore, updateCohorts } = useCohortsStore((state) => state);

  const fetchCohorts = useCallback(async () => {
    try {
      const res = await api.get('/cohorts');
      if (res.status === 200) {
        updateCohorts({ cohorts: res.data.items });
      }
    } catch (error) {
      console.error('Failed to fetch Cohorts:', error);
    } finally {
      setLoader(false);
    }
  }, []);

  useEffect(() => {
    fetchCohorts();
  }, [fetchCohorts]);

  const handleRowClick = (row: any) => {
    router.push('/cohorts/' + row.original.cohortId);
  };

  return (
    <div>
      <DataTable
        title="Cohorts"
        columns={CohortColumns}
        data={cohortStore.cohorts}
        handleRowClick={handleRowClick}
        HeaderButtonComponent={AddCohort}
        HeaderButtonComponentProps={{}}
        enableSearch={true}
        loader={loader}
      />
    </div>
  );
}
