'use client';
import { Slash } from 'lucide-react';
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbList,
  BreadcrumbSeparator
} from '@/components/ui/breadcrumb';
import Image from 'next/image';
import BigCalendar from '@/components/molecules/BigCalendar/BigCalendar';
import { getLastFourDigits } from '@/lib/utils';
import { useCallback, useEffect, useState } from 'react';
import api from '@/lib/services/apiWrapper';
import { LoadingSpinner } from '@/components/ui/loader';
import Link from 'next/link';
import { bp_data } from '@/constants';

interface DevicesProps {
  params: {
    siteId: string;
    cohortId: string;
    subjectId: string;
    deviceId: string;
  };
}

interface BreadcrumbProps {
  siteId: string;
  cohortId: string;
  subjectId: string;
  deviceId: string;
}

interface Event {
  cohortStop: string;
  readingStop: string;
  cohortStart: string;
  eventType: string;
  readingStart: string;
}

export default function Devices({ params }: DevicesProps) {
  const { siteId, cohortId, subjectId } = params;
  const deviceId = decodeURIComponent(params.deviceId);
  const [events, setEvents] = useState<Event[]>([]);
  const [loader, setLoader] = useState<boolean>(true);

  const fetchEvents = useCallback(async () => {
    try {
      const res = await api.get(
        `/subjects/${subjectId}/devices/${deviceId}/events`
      );
      if (res.status === 200) {
        const payload = [...res.data.items, ...bp_data];
        setEvents(payload);
      }
    } catch (error) {
      console.error('Failed to fetch events:', error);
    } finally {
      setLoader(false);
    }
  }, []);

  useEffect(() => {
    fetchEvents();
  }, [fetchEvents]);

  return (
    <div>
      <BreadcrumbWithCustomSeparator
        siteId={siteId}
        cohortId={cohortId}
        subjectId={subjectId}
        deviceId={deviceId}
      />
      <div className="mt-10">
        {loader ? (
          <div className="flex items-center justify-center mt-64">
            <LoadingSpinner />
          </div>
        ) : (
          <BigCalendar events={events} />
        )}
      </div>
    </div>
  );
}

function BreadcrumbWithCustomSeparator({
  siteId,
  cohortId,
  subjectId,
  deviceId
}: BreadcrumbProps) {
  return (
    <Breadcrumb>
      <BreadcrumbList>
        <BreadcrumbItem>
          <Link href={`/sites/${siteId}/${cohortId}/${subjectId}`}>
            <Image
              src="/icons/left-arrow.svg"
              width={25}
              height={25}
              alt="back"
            />
          </Link>
        </BreadcrumbItem>
        <BreadcrumbItem className="text-lg">Sites</BreadcrumbItem>
        <BreadcrumbSeparator>
          <Slash />
        </BreadcrumbSeparator>
        <BreadcrumbItem className="text-lg">
          Site #{getLastFourDigits(siteId)}
        </BreadcrumbItem>
        <BreadcrumbSeparator>
          <Slash />
        </BreadcrumbSeparator>
        <BreadcrumbItem className="text-lg">
          Cohort #{getLastFourDigits(cohortId)}
        </BreadcrumbItem>
        <BreadcrumbSeparator>
          <Slash />
        </BreadcrumbSeparator>
        <BreadcrumbItem className="text-lg">
          Subject #{getLastFourDigits(subjectId)}
        </BreadcrumbItem>
        <BreadcrumbSeparator>
          <Slash />
        </BreadcrumbSeparator>
        <BreadcrumbItem className="text-lg">
          Device #{getLastFourDigits(deviceId)}
        </BreadcrumbItem>
        <BreadcrumbSeparator>
          <Slash />
        </BreadcrumbSeparator>
        <BreadcrumbItem className="text-xl font-semibold">
          Activity
        </BreadcrumbItem>
      </BreadcrumbList>
    </Breadcrumb>
  );
}
