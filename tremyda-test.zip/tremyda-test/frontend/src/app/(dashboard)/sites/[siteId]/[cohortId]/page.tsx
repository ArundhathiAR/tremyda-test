'use client';
import { Slash } from 'lucide-react';
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbList,
  BreadcrumbSeparator
} from '@/components/ui/breadcrumb';
import { DataTable } from '@/components/molecules/DataTable/DataTable';
import Image from 'next/image';
import { SubjectsColumns } from '@/lib/TableColumns/subjects';
import AddSubject from '@/components/molecules/Forms/AddSubject';
import { getLastFourDigits, noDevicesLinkedMessage } from '@/lib/utils';
import { useCallback, useEffect, useState } from 'react';
import api from '@/lib/services/apiWrapper';
import { useSubjectsStore } from '@/store/subjects/subjects';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import toast from 'react-hot-toast';

interface DevicesProps {
  params: any;
}

interface BreadcrumbProps {
  siteId: string;
  cohortId: string;
}

export default function Subjects({ params }: DevicesProps) {
  const router = useRouter();
  const { siteId, cohortId } = params;
  const [loader, setLoader] = useState(true);
  const { subjectStore, updateSubjects } = useSubjectsStore((state) => state);

  const fetchSubjects = useCallback(async () => {
    try {
      const res = await api.get(`/cohorts/${cohortId}/subjects`);
      if (res.status === 200) {
        updateSubjects({ ...subjectStore, cohortSubjects: res.data.items });
      }
    } catch (error) {
      console.error('Failed to fetch subjects:', error);
    } finally {
      setLoader(false);
    }
  }, []);

  useEffect(() => {
    fetchSubjects();
  }, [fetchSubjects]);

  const handleRowClick = (row: any) => {
    if (row.original.numberOfDevices > 0) {
      router.push(`/sites/${siteId}/${cohortId}/` + row.original.subjectId);
    } else {
      noDevicesLinkedMessage();
    }
  };

  return (
    <div>
      <BreadcrumbWithCustomSeparator siteId={siteId} cohortId={cohortId} />
      <DataTable
        title=""
        columns={SubjectsColumns}
        data={subjectStore.cohortSubjects}
        handleRowClick={handleRowClick}
        HeaderButtonComponent={AddSubject}
        HeaderButtonComponentProps={{ cohortId: cohortId }}
        enableSearch={true}
        loader={loader}
      />
    </div>
  );
}

function BreadcrumbWithCustomSeparator({ siteId, cohortId }: BreadcrumbProps) {
  return (
    <Breadcrumb>
      <BreadcrumbList>
        <BreadcrumbItem>
          <Link href={`/sites/${siteId}`}>
            <Image
              src="/icons/left-arrow.svg"
              width={25}
              height={25}
              alt="back"
            />
          </Link>
        </BreadcrumbItem>
        <BreadcrumbItem className="text-lg">Sites</BreadcrumbItem>
        <BreadcrumbSeparator>
          <Slash />
        </BreadcrumbSeparator>
        <BreadcrumbItem className="text-lg">
          Site #{getLastFourDigits(siteId)}
        </BreadcrumbItem>
        <BreadcrumbSeparator>
          <Slash />
        </BreadcrumbSeparator>
        <BreadcrumbItem className="text-lg">
          Cohort #{getLastFourDigits(cohortId)}
        </BreadcrumbItem>
        <BreadcrumbSeparator>
          <Slash />
        </BreadcrumbSeparator>
        <BreadcrumbItem className="text-xl">Subjects</BreadcrumbItem>
      </BreadcrumbList>
    </Breadcrumb>
  );
}
