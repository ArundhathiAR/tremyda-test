'use client';
import { Slash } from 'lucide-react';
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbList,
  BreadcrumbSeparator
} from '@/components/ui/breadcrumb';
import { DataTable } from '@/components/molecules/DataTable/DataTable';
import Image from 'next/image';
import { CohortColumns } from '@/lib/TableColumns/cohorts';
import AddCohort from '@/components/molecules/Forms/AddCohort';
import { getLastFourDigits } from '@/lib/utils';
import { useCallback, useEffect, useState } from 'react';
import api from '@/lib/services/apiWrapper';
import { useCohortsStore } from '@/store/cohorts/cohorts';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

interface CohortsProps {
  params: any;
}

interface BreadcrumbProps {
  siteId: string;
}

export default function Cohorts({ params }: CohortsProps) {
  const router = useRouter();
  const { siteId } = params;
  const [loader, setLoader] = useState<boolean>(true);
  const { cohortStore, updateCohorts } = useCohortsStore((state) => state);

  const fetchCohorts = useCallback(async () => {
    try {
      const res = await api.get(`/sites/${siteId}/cohorts`);
      if (res.status === 200) {
        updateCohorts({ ...cohortStore, siteCohorts: res.data.items });
      }
    } catch (error) {
      console.error('Failed to fetch Cohorts:', error);
    } finally {
      setLoader(false);
    }
  }, []);

  useEffect(() => {
    fetchCohorts();
  }, [fetchCohorts]);

  const handleRowClick = (row: any) => {
    router.push(`/sites/${siteId}/` + row.original.cohortId);
  };

  return (
    <div>
      <BreadcrumbWithCustomSeparator siteId={siteId} />
      <DataTable
        title=""
        columns={CohortColumns}
        data={cohortStore.siteCohorts}
        handleRowClick={handleRowClick}
        HeaderButtonComponent={AddCohort}
        HeaderButtonComponentProps={{ siteId: siteId }}
        enableSearch={true}
        loader={loader}
      />
    </div>
  );
}

function BreadcrumbWithCustomSeparator({ siteId }: BreadcrumbProps) {
  return (
    <Breadcrumb>
      <BreadcrumbList>
        <BreadcrumbItem>
          <Link href={`/sites`}>
            <Image
              src="/icons/left-arrow.svg"
              width={25}
              height={25}
              alt="back"
            />
          </Link>
        </BreadcrumbItem>
        <BreadcrumbItem className="text-lg">Sites</BreadcrumbItem>
        <BreadcrumbSeparator>
          <Slash />
        </BreadcrumbSeparator>
        <BreadcrumbItem className="text-lg">
          Site #{getLastFourDigits(siteId)}
        </BreadcrumbItem>
        <BreadcrumbSeparator>
          <Slash />
        </BreadcrumbSeparator>
        <BreadcrumbItem className="text-xl ">Cohorts</BreadcrumbItem>
      </BreadcrumbList>
    </Breadcrumb>
  );
}
