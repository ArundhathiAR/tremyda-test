'use client';
import { DataTable } from '@/components/molecules/DataTable/DataTable';
import AddSite from '@/components/molecules/Forms/AddSite';
import api from '@/lib/services/apiWrapper';
import { SitesColumns } from '@/lib/TableColumns/sites';
import { useSitesStore } from '@/store/sites/sites';
import { useRouter } from 'next/navigation';
import { useCallback, useEffect, useState } from 'react';

export default function Sites() {
  const router = useRouter();
  const [loader, setLoader] = useState(true);
  const { siteStore, updateSites } = useSitesStore((state) => state);

  const fetchSites = useCallback(async () => {
    try {
      const res = await api.get('/sites');
      if (res.status === 200) {
        updateSites({ sites: res.data.items });
      }
    } catch (error) {
      console.error('Failed to fetch sites:', error);
    } finally {
      setLoader(false);
    }
  }, [updateSites]);

  useEffect(() => {
    fetchSites();
  }, [fetchSites]);

  const handleRowClick = (row: any) => {
    router.push('/sites/' + row.original.siteId);
  };

  return (
    <div>
      <DataTable
        title="Sites"
        columns={SitesColumns}
        data={siteStore.sites}
        handleRowClick={handleRowClick}
        HeaderButtonComponent={AddSite}
        HeaderButtonComponentProps={{}}
        enableSearch={true}
        loader={loader}
      />
    </div>
  );
}
