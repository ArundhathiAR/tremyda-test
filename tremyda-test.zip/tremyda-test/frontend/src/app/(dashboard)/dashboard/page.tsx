'use client';
import React, { useCallback, useEffect, useState } from 'react';
import BarGraph from '@/components/molecules/Charts/BarChart/BarChart';
import Updates from '@/components/molecules/Updates/Updates';
import Card, { CardSkeleton } from '@/components/molecules/AnalyticsCard/Card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import api from '@/lib/services/apiWrapper';
import {
  CardCountsType,
  EventRecord,
  UpdatesType
} from '@/lib/types/dashboard';
import { getUserRoleFromJWT } from '@/lib/utils';
import Alerts from '@/components/molecules/Alerts/Alerts';

function Dashboard() {
  const [loader, setLoader] = useState(true);
  const [counts, setcounts] = useState<CardCountsType>({
    numberOfCohorts: 0,
    numberOfSubjects: 0,
    numberOfDevices: 0,
    numberOfSites: 0
  });
  const [events, setEvents] = useState<EventRecord[]>([]);
  

  const fetchCounts = useCallback(async () => {
    try {
      const res = await api.get('/count');
      if (res.status === 200) {
        if (res.data.items.length !== 0) {
          setcounts({ ...counts, ...res.data.items[0] });
          setEvents(res.data.events);
        }
      }
    } catch (error) {
      console.error('Failed to counts:', error);
    } finally {
      setLoader(false);
    }
  }, []);

  useEffect(() => {
    fetchCounts();
  }, [fetchCounts]);

  return (
    <div className="h-full p-4">
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4 h-full">
        {/* Left half */}
        <div className="flex flex-col space-y-4 col-span-3 gap-4">
          {/* Top 4 cards */}
          {loader ? (
            <div className="grid grid-cols-2 gap-6">
              <CardSkeleton />
              <CardSkeleton />
              <CardSkeleton />
              <CardSkeleton />
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-6">
              <Card
                data={{ label: 'Cohorts', count: counts.numberOfCohorts }}
                color="#D6EFED"
                icon="/icons/lab-flask.svg"
                url="/cohorts"
              />
              <Card
                data={{ label: 'Subjects', count: counts.numberOfSubjects }}
                color="#F1E3DB"
                icon="/icons/book-outline.svg"
                url="/subjects"
              />
              <Card
                data={{ label: 'Sites', count: counts.numberOfSites }}
                color="#DFF3E1"
                icon="/icons/sites.svg"
                url="/sites"
              />
              <Card
                data={{ label: 'Devices', count: counts.numberOfDevices }}
                color="#D7E4F0"
                icon="/icons/device.svg"
                url="/devices"
              />
            </div>
          )}
          {/* Bottom Bar Graph */}
          <div className="bg-white p-4 rounded-lg">
            <h3 className="text-xl font-semibold">Data Events</h3>
            <BarGraph events={events} />
          </div>
        </div>

        {/* Right half */}
        <div className="p-4 bg-white shadow-md rounded-lg h-full col-span-2">
          <Tabs defaultValue="updates" className="w-full">
            <TabsList>
              <TabsTrigger
                value="updates"
                className="w-28 text-base font-medium"
              >
                Updates
              </TabsTrigger>
              <TabsTrigger
                value="alerts"
                className="w-28 text-base font-medium"
              >
                Alerts
              </TabsTrigger>
            </TabsList>
            <TabsContent value="updates">
              <Updates />
            </TabsContent>
            <TabsContent value="alerts">
              <Alerts />
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;
