import AuthProvider from '@/components/Auth/AuthProvider/AuthProvider';
import DashboardLayout from '@/components/organisms/DashboardLayout/DashboardLayout';

export default function Layout({
  children
}: Readonly<{
  children: React.ReactNode;
}>) {
  
  return (
    <AuthProvider>
      <DashboardLayout>{children}</DashboardLayout>;
    </AuthProvider>
  );
}
