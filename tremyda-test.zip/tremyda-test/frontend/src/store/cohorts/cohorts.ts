import { create } from 'zustand';

export type CohortStateType = {
  cohortStore: {
    cohorts: Array<any>;
    siteCohorts: Array<any>;
  };
  updateCohorts: (data: any) => void;
};

const initialStoreValue = {
  cohorts: [],
  siteCohorts: []
};

export const useCohortsStore = create<CohortStateType>((set) => ({
  cohortStore: initialStoreValue,

  updateCohorts: (data: any) =>
    set((state: any) => ({
      cohortStore: { ...state.global, ...data }
    }))
}));
