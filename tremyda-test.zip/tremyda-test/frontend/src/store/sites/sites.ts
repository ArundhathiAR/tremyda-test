import { create } from 'zustand';

export type SiteStateType = {
  siteStore: {
    sites: Array<any>;
  };
  updateSites: (data: any) => void;
};

const initialStoreValue = {
  sites: []
};

export const useSitesStore = create<SiteStateType>((set) => ({
  siteStore: initialStoreValue,

  updateSites: (data: any) =>
    set((state: any) => ({
      siteStore: { ...state.global, ...data }
    }))
}));
