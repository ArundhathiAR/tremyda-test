import { create } from 'zustand';

export type SubjectStateType = {
  subjectStore: {
    subjects: Array<any>;
    cohortSubjects: Array<any>;
  };
  updateSubjects: (data: any) => void;
};

const initialStoreValue = {
  subjects: [],
  cohortSubjects: []
};

export const useSubjectsStore = create<SubjectStateType>((set) => ({
  subjectStore: initialStoreValue,

  updateSubjects: (data: any) =>
    set((state: any) => ({
      subjectStore: { ...state.global, ...data }
    }))
}));
