import { create } from 'zustand';

export type UserStateType = {
  userStore: {
    users: any[];
    cohortUsers: any[];
  };
  updateUsers: (data: any) => void;
};

const initialStoreValue = {
  users: [],
  cohortUsers: []
};

export const useUsersStore = create<UserStateType>((set) => ({
  userStore: initialStoreValue,

  updateUsers: (data: any) =>
    set((state: any) => ({
      userStore: { ...state.global, ...data }
    }))
}));
