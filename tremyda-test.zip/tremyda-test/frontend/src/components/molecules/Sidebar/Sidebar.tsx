'use client';
import React, { useEffect, useRef, useState } from 'react';
import { usePathname } from 'next/navigation';
import Link from 'next/link';
import MenuItem from './menu-item';
import Image from 'next/image';
import { logoutAndRedirectToLogin } from '@/lib/services/authUtils';
import { app } from '@/constants/config';

type SidebarProps = {
  sidebarOpen: boolean;
  setSidebarOpen: Function;
};
const Sidebar = ({ sidebarOpen, setSidebarOpen }: SidebarProps) => {
  const [disabled, setDisabled] = useState(false);
  const pathname = usePathname();

  const trigger = useRef(null);
  const sidebar = useRef(null);

  let storedSidebarExpanded = 'true';

  const [sidebarExpanded, setSidebarExpanded] = useState(
    storedSidebarExpanded === null ? false : storedSidebarExpanded === 'true'
  );

  //   useEffect(() => {
  //     setDisabled(!user?.isActive || false);
  //   }, []);

  // close on click outside
  useEffect(() => {
    const clickHandler = ({ target }: any) => {
      if (!sidebar.current || !trigger.current) return;
      if (
        !sidebarOpen ||
        (sidebar.current as HTMLElement | null)?.contains(target) ||
        (trigger.current as HTMLElement | null)?.contains(target)
      )
        return;
      setSidebarOpen(false);
    };
    document.addEventListener('click', clickHandler);
    return () => document.removeEventListener('click', clickHandler);
  });

  // close if the esc key is pressed
  useEffect(() => {
    const keyHandler = ({ key }: any) => {
      if (!sidebarOpen || key !== 'Escape') return;
      setSidebarOpen(false);
    };
    document.addEventListener('keydown', keyHandler);
    return () => document.removeEventListener('keydown', keyHandler);
  });

  useEffect(() => {
    localStorage.setItem('sidebar-expanded', sidebarExpanded.toString());
    if (sidebarExpanded) {
      document.querySelector('body')?.classList.add('sidebar-expanded');
    } else {
      document.querySelector('body')?.classList.remove('sidebar-expanded');
    }
  }, [sidebarExpanded]);

  const sideBarMenu = [
    {
      name: 'Dashboard',
      path: '/dashboard',
      icon: '/icons/dashboard.svg',
      activeIcon: '/icons/dashboard-white.svg'
    },
    {
      name: 'Sites',
      path: '/sites',
      icon: '/icons/sites.svg',
      activeIcon: '/icons/site-white.svg'
    },
    {
      name: 'Cohorts',
      path: '/cohorts',
      icon: '/icons/lab-flask.svg',
      activeIcon: '/icons/lab-flask-white.svg'
    },
    {
      name: 'Subjects',
      path: '/subjects',
      icon: '/icons/book-outline.svg',
      activeIcon: '/icons/book-white.svg'
    },

    {
      name: 'Devices',
      path: '/devices',
      icon: '/icons/device.svg',
      activeIcon: '/icons/device-white.svg'
    },
    {
      name: 'Users',
      path: '/users',
      icon: '/icons/team-management.png',
      activeIcon: '/icons/team-management.png'
    }
  ];

  return (
    <aside
      ref={sidebar}
      className={`z-50 pt-5 absolute left-0 top-0 z-9999 flex h-screen w-72.5 flex-col overflow-y-hidden bg-secondary-white bottom-1 border-secondary duration-300 ease-linear lg:static lg:translate-x-0 ${
        sidebarOpen ? 'translate-x-0' : '-translate-x-full'
      } ${disabled ? 'pointer-events-none opacity-50' : ''} `}
    >
      {/* <!-- SIDEBAR HEADER --> */}
      <div className="flex flex-row items-center justify-center gap-2 px-6 py-5.5 lg:py-6.5 mr-10">
        <Link
          href="/dashboard"
          className="flex flex-col items-start justify-start text-xl font-semibold"
        >
          <Image
            src={app.icon || `/logo/default-app-icon.svg`}
            width={app.iconWidth || 60}
            height={app.iconHeight || 60}
            alt="logo"
          />
        </Link>

        <button
          ref={trigger}
          onClick={() => setSidebarOpen(!sidebarOpen)}
          aria-controls="sidebar"
          aria-expanded={sidebarOpen}
          className="block lg:hidden  text-[#216BB9]"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
            stroke-linecap="round"
            stroke-linejoin="round"
            className="lucide lucide-arrow-left"
          >
            <path d="m12 19-7-7 7-7" />
            <path d="M19 12H5" />
          </svg>
        </button>
      </div>
      {/* <!-- SIDEBAR HEADER --> */}

      <div className="no-scrollbar flex flex-col overflow-y-auto duration-300 ease-linear ">
        {/* <!-- Sidebar Menu --> */}
        <nav className="mt-5 px-2 lg:mt-9 w-56 h-screen">
          {/* <!-- Menu Group --> */}
          <div className="flex flex-col justify-between h-full">
            <ul className="mb-6 flex flex-col gap-1.5">
              {sideBarMenu &&
                sideBarMenu.map((menu, index) => {
                  return (
                    <MenuItem
                      key={index}
                      menu={menu}
                      pathname={pathname}
                      sidebarOpen={sidebarOpen}
                      setSidebarOpen={setSidebarOpen}
                    >
                      {/* <Image
                        src={menu.icon}
                        width={20}
                        height={20}
                        className="hover:text-secondary-white"
                        alt="icon"
                      />
                      {menu.name} */}
                    </MenuItem>
                  );
                })}
            </ul>

            <ul className="mb-10">
              <div
                className="w-full group relative flex items-center gap-2.5 rounded-sm px-4 py-2 font-medium text-secondary duration-300 ease-in-out hover:bg-primary-gradient hover:text-secondary-white cursor-pointer"
                onClick={logoutAndRedirectToLogin}
              >
                <Image
                  src={'/icons/logout.svg'}
                  width={20}
                  height={20}
                  className="hover:text-secondary-white"
                  alt="icon"
                />
                <span>Logout</span>
              </div>
            </ul>
          </div>
        </nav>
        {/* <!-- Sidebar Menu --> */}
      </div>
    </aside>
  );
};

export default Sidebar;
