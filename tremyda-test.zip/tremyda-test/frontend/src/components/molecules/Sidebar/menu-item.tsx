import React from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { getUserRoleFromJWT } from '@/lib/utils';

type MenuItemProp = {
  pathname: string;
  sidebarOpen: boolean;
  setSidebarOpen: Function;
  menu: any;
};

function MenuItem({
  pathname,
  sidebarOpen,
  setSidebarOpen,
  menu
}: MenuItemProp) {
  const active = menu.path != '/' && pathname.includes(menu.path);
  const role = getUserRoleFromJWT();

  if (role == 'SiteViewer' && menu.path == '/users') return <li></li>;
  return (
    <li>
      <Link
        href={menu.path}
        className={`w-full group relative flex items-center gap-2.5 rounded-sm px-4 py-2 font-medium text-secondary duration-300 ease-in-out hover:bg-primary-gradient hover:text-secondary-white ${
          active && 'bg-primary-gradient text-secondary-white'
        }`}
        onClick={() => sidebarOpen && setSidebarOpen(!sidebarOpen)}
      >
        <Image
          src={active ? menu.activeIcon : menu.icon}
          width={20}
          height={20}
          className="hover:text-secondary-white"
          alt="icon"
        />
        {menu.name}
      </Link>
    </li>
  );
}

export default MenuItem;
