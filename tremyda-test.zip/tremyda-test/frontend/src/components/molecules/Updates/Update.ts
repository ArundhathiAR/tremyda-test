import { UpdatesType } from '@/lib/types/dashboard';
import { getLastFourDigits } from '@/lib/utils';

export function getUpdateData(update: UpdatesType) {
  let link: string;
  let title: string;

  switch (update.type) {
    case 'site':
      link = `/sites/${update.siteId}`;
      title = `New Site Created - ${update.name}`;
      break;

    case 'cohort':
      link = `/cohorts/${update.cohortId}`;
      title = `New Cohort Created - ${update.name}`;
      break;

    case 'subject':
      link = `/subjects/${update.subjectId}`;
      title = `New Subject Created for cohort ${update.cohortName}`;
      break;

    case 'device':
      link = `/devices/${update.deviceId}`;
      title = `Device Connect to ${update.subjectName}`;
      break;

    case 'event':
      link = `/subjects/${update.subjectId}/${update.deviceId}`;
      title = `New Event Created on Device #${getLastFourDigits(update.deviceId || '')}`;
      break;
    default:
      link = '/dashboard';
      title = 'Update';
  }

  return { link, title };
}
