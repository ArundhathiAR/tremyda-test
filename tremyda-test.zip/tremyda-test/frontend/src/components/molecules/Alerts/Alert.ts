import { AlertsType } from '@/lib/types/dashboard';
import { getLastFourDigits } from '@/lib/utils';

export function getAlertData(alerts: AlertsType) {
  let link: string;
  let title: string;

  switch (alerts.type) {
    case 'site':
      link = `/sites/${alerts.siteId}`;
      title = `New Site Created - ${alerts.name}`;
      break;

    case 'cohort':
      link = `/cohorts/${alerts.cohortId}`;
      title = `New Cohort Created - ${alerts.name}`;
      break;

    case 'subject':
      link = `/subjects/${alerts.subjectId}`;
      title = `New Subject Created for cohort ${alerts.cohortName}`;
      break;

    case 'device':
      link = `/devices/${alerts.deviceId}`;
      title = `Device Connect to ${alerts.subjectName}`;
      break;

    case 'event':
      link = `/subjects/${alerts.subjectId}/${alerts.deviceId}`;
      title = `New Event Created on Device #${getLastFourDigits(alerts.deviceId || '')}`;
      break;
    default:
      link = '/dashboard';
      title = 'Update';
  }

  return { link, title };
}
