import { formatDateTime } from '@/lib/utils';
import React, { useCallback, useEffect, useState } from 'react';
import { getAlertData } from './Alert';
import { AlertsType } from '@/lib/types/dashboard';
import Link from 'next/link';
import { Skeleton } from '@/components/ui/skeleton';
import api from '@/lib/services/apiWrapper';

export default function Alerts() {
  const [alerts, setAlerts] = useState<AlertsType[]>([]);
  const [loader, setLoader] = useState(true);

  const fetchAlerts = useCallback(async () => {
    try {
      const res = await api.get('/alerts');
      if (res.status === 200) {
        if (res.data.items.length !== 0) {
          setAlerts(res.data.items);
        }
      }
    } catch (error) {
      console.error('Failed to counts:', error);
    } finally {
      setLoader(false);
    }
  }, []);

  useEffect(() => {
    fetchAlerts();
  }, [fetchAlerts]);

  return (
    <div className="p-2">
      <div className="relative pl-4 overflow-hidden hover:overflow-y-auto h-screen scrollbar-thin scrollbar-thumb-blue-400 scrollbar-track-gray-100">
        {alerts.length != 0 && (
          <div className="absolute h-full border-l-2 border-gray-300 left-2"></div>
        )}
        {loader && <LoadingSkeleton />}

        {!loader && alerts.length == 0 && (
          <div className="mt-4 text-base text-center text-gray-400">
            No results
          </div>
        )}
        {alerts.map((update: AlertsType, index) => {
          const { link, title } = getAlertData(update);
          return (
            <Link
              key={index}
              href={link}
              className="mb-2 relative flex items-start py-1 rounded-sm hover:bg-gray-100"
            >
              <div
                className={`absolute left-[-0.8rem] w-3 h-3 rounded-full ${index === 0 ? 'bg-red-500' : 'bg-gray-700'}`}
              ></div>
              <div className="ml-4">
                <h3
                  className={`text-sm font-semibold lowercase ${index === 0 ? 'text-black' : 'text-gray-800'}`}
                >
                  {title}
                </h3>
                <p className="text-xs text-gray-500">
                  {formatDateTime(update.createdAt)}
                </p>
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}

function LoadingSkeleton() {
  return (
    <div className="flex flex-col space-y-5 mt-2">
      <Skeleton className="h-10 w-full rounded-sm bg-gray-200" />
      <Skeleton className="h-10 w-full rounded-sm bg-gray-200" />
      <Skeleton className="h-10 w-full rounded-sm bg-gray-200" />
    </div>
  );
}
