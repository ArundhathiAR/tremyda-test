// components/Calendar.js
import 'react-big-calendar/lib/css/react-big-calendar.css';
import { Calendar, momentLocalizer } from 'react-big-calendar';
import moment from 'moment';
import { DeviceDetailsDrawer } from '../DeviceDetailsDrawer/DeviceDetailsDrawer';
import React, { useCallback } from 'react';
import 'moment-timezone';
import api from '@/lib/services/apiWrapper';
import { useParams } from 'next/navigation';
import { formatEToNumber } from '@/lib/utils';

// moment.tz.setDefault('UTC');

const localizer = momentLocalizer(moment);

interface BigCalendarProps {
  events?: Array<any>;
  defaultView?: any;
  height?: number;
}

type TransformedEvent = {
  id: number;
  title: string;
  allDay?: boolean;
  start: Date;
  end: Date;
  startDateString: string;
  endDateString: string;
};

type Event = {
  eventType: string;
  readingStart: string;
  readingStop: string;
};

const transformEventsData = (items: Event[]): TransformedEvent[] => {
  return items.map((item, index) => ({
    id: index,
    title: 'New Activity',
    start: moment(item.readingStart).toDate(),
    end: moment(item.readingStop).toDate(),
    startDateString: item.readingStart,
    endDateString: item.readingStop,
    eventType: item.eventType
  }));
};

function mostRecentReadingStart(data: any) {
  return data.length
    ? data.reduce((latest: any, item: any) => {
        return new Date(item.readingStart) > new Date(latest.readingStart)
          ? item
          : latest;
      }).readingStart
    : new Date().toISOString();
}

const transformReadingsData = (items: any) => {
  // const data = items.length > 0 ? items.slice(-100) : [];
  interface Item {
    deviceCreated: string;
  }
  items.sort(
    (a: Item, b: Item) =>
      new Date(a.deviceCreated).getTime() - new Date(b.deviceCreated).getTime()
  );

  const data = items;
  return data.map((item: any) => ({
    current: formatEToNumber(item.values[0].m_value),
    // current: parseFloat(item.values[0].m_value).toFixed(2),
    voltage: parseFloat(item.values[1].n_value).toFixed(2)
  }));
};

export interface DeviceType {
  deviceDescription: string;
  deviceId: string;
  deviceType: string;
  subjectId: string;
  updatedAt: string;
  createdAt: string;
  updatedBy: string;
  createdBy: string;
}

const BigCalendar = ({
  events = [],
  defaultView = 'week',
  height = 700,
  ...props
}: BigCalendarProps) => {
  const [openDrawer, setOpenDrawer] = React.useState<boolean>(false);
  const [readings, setReadings] = React.useState([]);
  const [deviceData, setDeviceData] = React.useState<DeviceType[]>([]);
  const [loader, setLoader] = React.useState<boolean>(false);
  const [eventType, setEventType] = React.useState<string>('dataset');
  const { subjectId, deviceId } = useParams();

  const deviceIdDecoded = Array.isArray(deviceId)
    ? deviceId.map(decodeURIComponent).join(',')
    : decodeURIComponent(deviceId);

  const tEvents = transformEventsData(events);
  const tReadings = transformReadingsData(readings);
  const recentStartDate = mostRecentReadingStart(events);
  const defaultDate = new Date(recentStartDate);

  console.log(tEvents, 'readfsfsfsd');

  const CustomEvent = ({ event }: any) => {
    return (
      <div
        className={`${event.eventType == 'dataset' ? 'bg-[#92bcf3]' : 'bg-[#f48e8e]'} ml-[-140px] mt-[-4px] text-secondary font-normal text-xs p-1 pl-4 border-l-8 border-[#CD539F] rounded-sm cursor-pointer ${event?.color == 'blue' ? 'bg-[#B3D7F2]' : ''}`}
        onClick={() => {
          getReadings(event.startDateString, event.endDateString);
          getDeviceData();
          setEventType(event.eventType);
          setOpenDrawer(true);
        }}
      >
        {event.title}
      </div>
    );
  };

  const getReadings = useCallback(
    async (startDate: string, endDate: string) => {
      setLoader(true);
      try {
        const res = await api.get(
          `/subjects/${subjectId}/devices/${deviceIdDecoded}/readings?start=${startDate}&end=${endDate}`
        );
        if (res.status === 200) {
          setReadings(res.data.items);
        }
      } catch (error) {
        console.error('Failed to fetch readings:', error);
      } finally {
        setLoader(false);
      }
    },
    []
  );

  const getDeviceData = useCallback(async () => {
    try {
      const res = await api.get(`/devices/${deviceIdDecoded}`);
      if (res.status === 200) {
        setDeviceData(res.data.items);
      }
    } catch (error) {
      console.error('Failed to fetch device Details:', error);
    }
  }, []);

  return (
    <div className="">
      {events?.length > 0 ? (
        <div className="bg-white  p-2 rounded-md">
          <Calendar
            views={['month', 'week', 'day']}
            step={15}
            localizer={localizer}
            events={tEvents}
            defaultView={defaultView}
            defaultDate={defaultDate}
            startAccessor="start"
            endAccessor="end"
            style={{ minHeight: height }}
            components={{
              // eventWrapper: CustomEvent
              event: CustomEvent
            }}
            min={new Date(0, 0, 0, 8, 0, 0)} // Set the start time to 8 AM
            max={new Date(0, 0, 0, 23, 59, 59)} // Set the end time to 11:59 PM
            {...props}
          />

          <DeviceDetailsDrawer
            header="Device Activity"
            isOpen={openDrawer}
            setIsOpen={setOpenDrawer}
            data={tReadings}
            deviceData={deviceData}
            eventType={eventType}
            loader={loader}
          />
        </div>
      ) : (
        <div className="w-full flex items-center justify-center text-gray-600 mt-20">
          No Activity Recored for this device
        </div>
      )}
    </div>
  );
};

export default BigCalendar;
