import DropdownUser from './dropdown-user';
import { Menu } from 'lucide-react';
import useUserDetails from '@/lib/services/useUserDetails';
// import { useRouter } from 'next/navigation';

const Header = (props: any) => {
  const userDetails: any = useUserDetails();

  return (
    <header className={`flex  drop-shadow-1 rounded-md`}>
      <div className="flex flex-grow items-center justify-between px-4 pt-4 shadow-2 md:px-6 2xl:px-11">
        <div className="flex items-center gap-2 sm:gap-4 lg:hidden">
          {/* <!-- Hamburger Toggle BTN --> */}
          <button
            aria-controls="sidebar"
            onClick={(e) => {
              // e.stopPropagation();
              props.setSidebarOpen(!props.sidebarOpen);
            }}
            className="z-99999 block rounded-sm border border-stroke  p-1.5 shadow-sm lg:hidden"
          >
            <Menu />
          </button>
          {/* <!-- Hamburger Toggle BTN --> */}
        </div>

        <div className="hidden sm:block text-xl font-normal text-secondary capitalize">
          {userDetails?.email && (
            <div>
              Welcome <strong>{userDetails?.email.split('@')[0]}</strong>{' '}
              {' 👋'}
            </div>
          )}
        </div>

        {/* {!user?.isAuth && <Skeleton variant="text" sx={{ fontSize: '1rem' }} />} */}

        <div className="flex items-center gap-3 2xsm:gap-7">
          <DropdownUser />
        </div>
      </div>
    </header>
  );
};

export default Header;
