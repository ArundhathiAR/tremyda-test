'use client';
import { useEffect, useRef, useState } from 'react';
import Link from 'next/link';
import AvatarDemo from '@/stories/UI/Avatar/AvatarDemo';
import Image from 'next/image';
import useUserDetails from '@/lib/services/useUserDetails';
import { Button } from '@/components/ui/button';
import { logoutAndRedirectToLogin } from '@/lib/services/authUtils';

const DropdownUser = () => {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const userDetails: any = useUserDetails();
  const disabled = false;

  const trigger = useRef(null);
  const dropdown = useRef(null);

  // close on click outside
  useEffect(() => {
    const clickHandler = ({ target }: any) => {
      if (!dropdown.current) return;
      if (
        !dropdownOpen ||
        (dropdown.current as HTMLElement | null)?.contains(target) ||
        (trigger.current as HTMLElement | null)?.contains(target)
      )
        return;
      setDropdownOpen(false);
    };
    document.addEventListener('click', clickHandler);
    return () => document.removeEventListener('click', clickHandler);
  });

  // close if the esc key is pressed
  useEffect(() => {
    const keyHandler = ({ keyCode }: any) => {
      if (!dropdownOpen || keyCode !== 27) return;
      setDropdownOpen(false);
    };
    document.addEventListener('keydown', keyHandler);
    return () => document.removeEventListener('keydown', keyHandler);
  });

  const logOut = async () => {};

  return (
    <>
      {true && (
        <div className="relative ">
          <Link
            ref={trigger}
            onClick={() => setDropdownOpen(!dropdownOpen)}
            className="flex items-center gap-3"
            href="#"
          >
            <span>
              <AvatarDemo
                src="/icons/avatar.svg"
                alt="Avatar"
                fallback=""
                className="size-8"
              />
            </span>

            <span className="text-secondary font-bold text-xl flex">
              <div className="capitalize">
                {userDetails?.email && userDetails?.email.split('@')[0]}
              </div>
              <Image
                src="/icons/down-arrow.svg"
                width={20}
                height={20}
                alt="down arrow"
                className={`${dropdownOpen ? 'rotate-180' : ''}`}
              />
            </span>
          </Link>

          <div
            ref={dropdown}
            onFocus={() => setDropdownOpen(true)}
            onBlur={() => setDropdownOpen(false)}
            className={`absolute right-0 mt-4 flex w-62.5 flex-col rounded-sm border border-stroke bg-white shadow-default z-10 ${
              dropdownOpen === true ? 'block' : 'hidden'
            }`}
          >
            <div
              className={`flex flex-col gap-2 border-b border-stroke px-6 py-4 ${disabled ? 'pointer-events-none opacity-50' : ''}`}
            >
              <Button
                variant={'ghost'}
                className="flex items-center  text-sm font-medium duration-300 ease-in-out hover:text-brand lg:text-base"
              >
                Settings
              </Button>
            </div>
            <div
              className={`flex flex-col gap-2 border-b border-stroke px-6 py-4 ${disabled ? 'pointer-events-none opacity-50' : ''}`}
            >
              <Button
                variant={'ghost'}
                onClick={logoutAndRedirectToLogin}
                className="flex items-center  text-sm font-medium duration-300 ease-in-out hover:text-brand lg:text-base"
              >
                Logout
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default DropdownUser;
