import { Button } from '@/components/ui/button';
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger
} from '@/components/ui/sheet';

interface DrawerProps {
  title?: string;
  header?: string;
  description?: string;
  open: boolean;
  onChange: (open: boolean) => void;
  Component: React.FC<any>;
  componentProps?: any;
}

export function Drawer({
  title = 'Drawer',
  header,
  description,
  open = false,
  onChange = () => {},
  Component,
  componentProps = {}
}: DrawerProps) {
  return (
    <Sheet open={open} onOpenChange={() => onChange(open)}>
      <SheetTrigger asChild>
        <Button variant="default" onChange={() => onChange(open)}>
          {title}
        </Button>
      </SheetTrigger>
      <SheetContent>
        <SheetHeader className="">
          <SheetTitle className="font-semibold">{header}</SheetTitle>
          <SheetDescription>{description}</SheetDescription>
        </SheetHeader>

        <div className="border-b border-gray-400 mt-2"></div>

        <Component {...componentProps} />
      </SheetContent>
    </Sheet>
  );
}
