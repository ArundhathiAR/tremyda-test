// Card.js
import { Skeleton } from '@/components/ui/skeleton';
import Image from 'next/image';
import Link from 'next/link';
import React, { useEffect } from 'react';
import { motion, useMotionValue, useTransform, animate } from 'framer-motion';

export default function Card({
  data = { label: 'Title', count: 0 },
  color = '#D6EFED',
  icon = '/icons/lab-flask.svg',
  url = '/'
}: any) {
  const count = useMotionValue(0);
  const rounded = useTransform(count, (latest: any) => Math.round(latest));

  useEffect(() => {
    const animation = animate(count, data.count, { duration: 0.8 });
    return animation.stop;
  }, [count, data.count]);

  return (
    <Link href={url}>
      <div
        className={`max-w-sm rounded-xl overflow-hidden shadow-lg p-4 relative h-32`}
        style={{
          background: `linear-gradient(78.23deg, ${color} 4.53%, rgba(255, 255, 255, 1) 80.44%)`
        }}
      >
        <div className="flex items-center justify-between">
          <motion.div className="text-4xl font-bold text-gray-800 ml-1">
            {rounded}
          </motion.div>
          <div>
            <Image
              src={icon}
              alt="Lab Icon"
              width={24}
              height={24}
              className="text-gray-600"
            />
          </div>
        </div>
        <div className="text-secondary font-medium mt-7 text-lg">
          {data.label}
        </div>
        <div className="absolute bottom-4 right-4 flex items-center justify-center h-10 w-10 rounded-full bg-white shadow-lg">
          <Image
            src={'/icons/diagonal-arrow.svg'}
            alt="Arrow Icon"
            width={40}
            height={40}
            className="text-gray-600"
          />
        </div>
      </div>
    </Link>
  );
}

export function CardSkeleton() {
  return <Skeleton className="h-32 max-w-sm rounded-xl bg-gray-300" />;
}
