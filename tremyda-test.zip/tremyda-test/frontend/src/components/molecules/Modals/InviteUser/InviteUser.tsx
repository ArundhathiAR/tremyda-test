import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from '@/components/ui/dialog';
import api from '@/lib/services/apiWrapper';
import { DialogTrigger } from '@radix-ui/react-dialog';
import { useCallback, useState } from 'react';
import InviteUserForm from '../../Forms/InviteUser';

export function InviteUser() {
  const [open, setOpen] = useState<boolean>(false);

  return (
    <Dialog open={open} onOpenChange={() => setOpen(!open)}>
      <DialogTrigger className="">
        <Button variant="default" onChange={() => setOpen(!open)}>
          Invite User
        </Button>
      </DialogTrigger>
      <DialogContent
        className="py-4 sm:max-w-md"
        onClick={(e) => {
          e.stopPropagation();
        }}
      >
        <DialogHeader className="flex flex-col text-secondary tracking-wide">
          <DialogTitle className="text-2xl font-bold">Invite User</DialogTitle>
          <DialogDescription className="text-base font-medium">
            {''}
          </DialogDescription>
        </DialogHeader>

        <InviteUserForm open={open} modalToggle={setOpen} />
      </DialogContent>
    </Dialog>
  );
}
