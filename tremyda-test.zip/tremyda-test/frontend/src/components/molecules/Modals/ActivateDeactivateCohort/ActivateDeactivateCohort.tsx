import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from '@/components/ui/dialog';
import api from '@/lib/services/apiWrapper';
import { ActivateDeactivateCohortProp } from '@/lib/types/cohort';
import { useCohortsStore } from '@/store/cohorts/cohorts';
import { DialogTrigger } from '@radix-ui/react-dialog';
import { useCallback, useState } from 'react';
import toast from 'react-hot-toast';

export function ActivateDeactivateCohort({
  siteId,
  cohortId,
  status
}: ActivateDeactivateCohortProp) {
  const [open, setOpen] = useState<boolean>(false);
  const [loader, setLoader] = useState<boolean>(false);
  const { cohortStore, updateCohorts } = useCohortsStore((state) => state);
  const isActive = status == 'activate-open';

  const onSubmit = async () => {
    setLoader(true);
    try {
      const res = await api.put(
        `/sites/${siteId}/cohorts/${cohortId}?action=${isActive ? 'activate-close' : 'activate-open'}`,
        {
          createdBy: 'admin',
          updatedBy: 'admin'
        }
      );
      if (res.status == 200) {
        fetchCohorts();
        setOpen(false);
        toast.success(`Cohort  ${isActive ? 'Deactivated' : 'Activated'} !`);
      }
    } catch (error) {
      toast.error('Something went wrong');
    } finally {
      setLoader(false);
    }
  };

  const fetchCohorts = useCallback(async () => {
    try {
      const res = await api.get('/cohorts');
      if (res.status === 200) {
        updateCohorts({ ...cohortStore, cohorts: res.data.items });
      }
    } catch (error) {
      console.error('Failed to fetch Cohorts:', error);
    }
  }, []);

  return (
    <Dialog open={open} onOpenChange={() => setOpen(!open)}>
      <DialogTrigger
        onClick={(e) => {
          e.stopPropagation();
        }}
        className="text-left w-full"
        // asChild
      >
        {isActive ? 'De-activate' : 'Activate'}
      </DialogTrigger>
      <DialogContent
        className="py-4 sm:max-w-md"
        onClick={(e) => {
          e.stopPropagation();
        }}
      >
        <DialogHeader className="flex flex-col gap-2 text-secondary mt-4">
          <DialogTitle className="text-2xl font-bold">
            Do you want to {isActive ? 'Deactivate' : 'Activate'} this cohort ?
          </DialogTitle>
          <DialogDescription className="text-base font-medium">
            {`You can always ${isActive ? 'deactivate' : 'activate'} the cohort by following the same pattern as now.`}
          </DialogDescription>
        </DialogHeader>
        <DialogFooter className="mt-4 sm:justify-end">
          <DialogClose asChild>
            <Button type="button" variant="outline">
              Cancel
            </Button>
          </DialogClose>
          <Button
            type="button"
            variant={isActive ? 'destructive' : 'secondary'}
            onClick={onSubmit}
            loader={loader}
          >
            {isActive ? 'Deactivate' : 'Activate'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
