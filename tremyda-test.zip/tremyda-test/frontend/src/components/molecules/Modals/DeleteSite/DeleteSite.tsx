import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from '@/components/ui/dialog';
import api from '@/lib/services/apiWrapper';
import { DeleteSiteProp } from '@/lib/types/site';
import { useSitesStore } from '@/store/sites/sites';
import { DialogTrigger } from '@radix-ui/react-dialog';
import { useCallback, useState } from 'react';
import toast from 'react-hot-toast';

export function DeleteSite({ siteId }: DeleteSiteProp) {
  const [open, setOpen] = useState<boolean>(false);
  const [loader, setLoader] = useState<boolean>(false);
  const { updateSites } = useSitesStore((state) => state);

  const onSubmit = async () => {
    setLoader(true);
    try {
      const res = await api.delete(`/sites/${siteId}`);
      if (res.status == 200) {
        fetchSites();
        setOpen(false);
        toast.success('Site Deleted !');
      }
    } catch (error) {
      toast.error('Something went wrong');
    } finally {
      setLoader(false);
    }
  };

  const fetchSites = useCallback(async () => {
    try {
      const res = await api.get('/sites');
      if (res.status === 200) {
        updateSites({ sites: res.data.items });
      }
    } catch (error) {
      console.error('Failed to fetch sites:', error);
    }
  }, [updateSites]);

  return (
    <Dialog open={open} onOpenChange={() => setOpen(!open)}>
      <DialogTrigger
        onClick={(e) => {
          e.stopPropagation();
        }}
        className="text-left w-full"
        // asChild
      >
        Delete
      </DialogTrigger>
      <DialogContent
        className="py-4 sm:max-w-md"
        onClick={(e) => {
          e.stopPropagation();
        }}
      >
        <DialogHeader className="flex flex-col gap-2 text-secondary tracking-wide">
          <DialogTitle className="text-2xl font-bold">
            Do you want to delete this site ?
          </DialogTitle>
          <DialogDescription className="text-base font-medium">
            {
              "Deleting this records will not be saved anywhere or can't be reverted."
            }
          </DialogDescription>
        </DialogHeader>
        <DialogFooter className="mt-4 sm:justify-end">
          <DialogClose asChild>
            <Button type="button" variant="outline">
              Cancel
            </Button>
          </DialogClose>
          <Button
            type="button"
            variant="destructive"
            onClick={onSubmit}
            loader={loader}
          >
            Delete
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
