import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from '@/components/ui/dialog';
import api from '@/lib/services/apiWrapper';
import { DeleteSubjectProp } from '@/lib/types/subject';
import { useSubjectsStore } from '@/store/subjects/subjects';
import { DialogTrigger } from '@radix-ui/react-dialog';
import { useCallback, useState } from 'react';
import toast from 'react-hot-toast';

export function DeleteSubject({ cohortId, subjectId }: DeleteSubjectProp) {
  const [open, setOpen] = useState<boolean>(false);
  const [loader, setLoader] = useState<boolean>(false);
  const { subjectStore, updateSubjects } = useSubjectsStore((state) => state);

  const onSubmit = async () => {
    setLoader(true);
    try {
      const res = await api.delete(
        `/cohorts/${cohortId}/subjects/${subjectId}`
      );
      if (res.status == 200) {
        fetchSubjects();
        setOpen(false);
        toast.success('Subject Deleted !');
      }
    } catch (error) {
      toast.error('Something went wrong');
    } finally {
      setLoader(false);
    }
  };

  const fetchSubjects = useCallback(async () => {
    try {
      const res = await api.get('/subjects');
      if (res.status === 200) {
        updateSubjects({ subjects: res.data.items });
      }
    } catch (error) {
      console.error('Failed to fetch sites:', error);
    }
  }, []);

  return (
    <Dialog open={open} onOpenChange={() => setOpen(!open)}>
      <DialogTrigger
        onClick={(e) => {
          e.stopPropagation();
        }}
        className="text-left w-full"
        // asChild
      >
        Delete
      </DialogTrigger>
      <DialogContent
        className="py-4 sm:max-w-md"
        onClick={(e) => {
          e.stopPropagation();
        }}
      >
        <DialogHeader className="flex flex-col gap-2 text-secondary">
          <DialogTitle className="text-2xl font-bold">
            Do you want to delete this Subject ?
          </DialogTitle>
          <DialogDescription className="text-base font-medium">
            {
              "Deleting this records will not be saved anywhere or can't be reverted."
            }
          </DialogDescription>
        </DialogHeader>
        <DialogFooter className="mt-4 sm:justify-end">
          <DialogClose asChild>
            <Button type="button" variant="outline">
              Cancel
            </Button>
          </DialogClose>
          <Button
            type="button"
            variant="destructive"
            onClick={onSubmit}
            loader={loader}
          >
            Delete
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
