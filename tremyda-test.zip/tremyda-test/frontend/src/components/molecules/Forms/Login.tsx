'use client';
import {
  CognitoUser,
  AuthenticationDetails,
  CognitoUserAttribute
} from 'amazon-cognito-identity-js';
import { Button } from '@/components/ui/button';
import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormMessage
} from '@/components/ui/form';
import toast from 'react-hot-toast';
import UserPool from '@/components/Auth/UserPool/UserPool';
import { saveTokensToLocalStorage } from '@/lib/utils';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import Image from 'next/image';
import { app } from '@/constants/config';

const loginFormSchema = z.object({
  email: z.string().email(),
  password: z
    .string()
    .min(8, { message: 'Password must be at least 8 characters long' })
    .regex(/[A-Z]/, {
      message: 'Password must contain at least one uppercase letter'
    })
    .regex(/[a-z]/, {
      message: 'Password must contain at least one lowercase letter'
    })
    .regex(/[0-9]/, { message: 'Password must contain at least one number' })
    .regex(/[^A-Za-z0-9]/, {
      message: 'Password must contain at least one special character'
    })
});

const invitedUserSignupSchema = z.object({
  firstName: z.string().min(2, {
    message: 'First Name must be at least 2 characters'
  }),
  lastName: z.string().min(2, {
    message: 'Last Name must be at least 2 characters'
  }),
  newPassword: z
    .string()
    .min(8, { message: 'Password must be at least 8 characters long' })
    .regex(/[A-Z]/, {
      message: 'Password must contain at least one uppercase letter'
    })
    .regex(/[a-z]/, {
      message: 'Password must contain at least one lowercase letter'
    })
    .regex(/[0-9]/, { message: 'Password must contain at least one number' })
    .regex(/[^A-Za-z0-9]/, {
      message: 'Password must contain at least one special character'
    })
});

export default function LoginForm() {
  const [loader, setLoader] = useState<boolean>(false);
  const [requiresNewPassword, setRequiresNewPassword] =
    useState<boolean>(false);
  const [user, setUser] = useState<CognitoUser | null>(null);
  const router = useRouter();

  const form = useForm<z.infer<typeof loginFormSchema>>({
    resolver: zodResolver(loginFormSchema),
    defaultValues: {
      email: '',
      password: ''
    }
  });

  const form2 = useForm<z.infer<typeof invitedUserSignupSchema>>({
    resolver: zodResolver(invitedUserSignupSchema),
    defaultValues: {
      firstName: '',
      lastName: '',
      newPassword: ''
    }
  });

  async function onSubmit(values: z.infer<typeof loginFormSchema>) {
    setLoader(true);
    const cognitoUser = new CognitoUser({
      Username: values.email,
      Pool: UserPool
    });
    const authDetails = new AuthenticationDetails({
      Username: values.email,
      Password: values.password
    });

    cognitoUser.authenticateUser(authDetails, {
      onSuccess: (data) => {
        const idToken = data.getIdToken().getJwtToken();
        const refreshToken = data.getRefreshToken().getToken();
        saveTokensToLocalStorage(idToken, refreshToken);
        cognitoUser.getUserAttributes(function (err, result: any) {
          let attributesObject: { [key: string]: any } = {};
          for (let i = 0; i < result.length; i++) {
            attributesObject[result[i].getName()] = result[i].getValue();
          }
          if ('email' in attributesObject) {
            localStorage.setItem(
              'userAttributes-profile',
              JSON.stringify(attributesObject)
            );
            toast.success('Logged In');
            router.push('/dashboard');
          } else {
            toast.error('No email attribute found in the response.');
          }
          setLoader(false);
        });
      },
      onFailure: (err: any) => {
        toast.error('Invalid Username or Password');
        setLoader(false);
      },
      newPasswordRequired: (data) => {
        setUser(cognitoUser);
        setRequiresNewPassword(true);
        setLoader(false);
      }
    });
  }

  // Function to handle new password submission
  async function handleNewPasswordSubmit(
    values: z.infer<typeof invitedUserSignupSchema>
  ) {
    if (user) {
      setLoader(true);
      user.completeNewPasswordChallenge(
        values.newPassword,
        {},
        {
          onSuccess: (data) => {
            const idToken = data.getIdToken().getJwtToken();
            const refreshToken = data.getRefreshToken().getToken();
            saveTokensToLocalStorage(idToken, refreshToken);

            // Now, add the custom attribute
            const attributeFirstName = new CognitoUserAttribute({
              Name: 'custom:firstName',
              Value: values.firstName
            });

            const attributeLastName = new CognitoUserAttribute({
              Name: 'custom:lastName',
              Value: values.lastName
            });

            user.updateAttributes(
              [attributeFirstName, attributeLastName],
              (err, result) => {
                if (err) {
                  toast.error(`Failed to update attribute: ${err.message}`);
                }
              }
            );
            toast.success(
              'Password updated successfully, Please login with new password'
            );
            setTimeout(() => {
              router.refresh();
            }, 1000);

            setLoader(false);
          },
          onFailure: (err: any) => {
            toast.error(`Failed to update password: ${err.message}`);
            setLoader(false);
          }
        }
      );
    }
  }

  return (
    <div className="w-full max-w-md">
      <div className='flex justify-center mb-20 mr-10'>
        <Link
          href="/dashboard"
          className="flex flex-col items-start justify-start text-xl font-semibold"
        >
          <Image
            src={app.icon || `/logo/default-app-icon.svg`}
            width={160}
            height={100}
            alt="logo"
          />
        </Link>
      </div>
      <h2 className="text-2xl font-bold mb-8 text-secondary">
        {!requiresNewPassword ? 'Login In' : 'Update User Details'}
      </h2>
      {!requiresNewPassword ? (
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="">
            <div className="flex flex-col gap-6">
              <div className="flex flex-col gap-6">
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormControl>
                        <Input type="email" placeholder="Email" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormControl>
                        <Input
                          type="password"
                          placeholder="Password"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <Link
                href="/forgot-password"
                className="text-sm font-medium text-indigo-600 hover:underline"
              >
                Forgot Password?
              </Link>

              <Button
                type="submit"
                variant={'ghost'}
                className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-lg font-bold text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 hover:text-white hover:scale-105"
                style={{
                  background:
                    'linear-gradient(92.02deg, #277FDC 0.35%, #154476 149.04%)'
                }}
                loader={loader}
                // onClick={() => {
                //   if (requiresNewPassword) {
                //     form.handleSubmit(({ newPassword, firstName, lastName }) =>
                //       handleNewPasswordSubmit(
                //         firstName || '',
                //         lastName || '',
                //         newPassword || ''
                //       )
                //     )();
                //   } else {
                //     form.handleSubmit(onSubmit)();
                //   }
                // }}
              >
                {requiresNewPassword ? 'Set New Password' : 'Login'}
              </Button>

              <Link
                href="/signup"
                className="text-base font-medium text-indigo-600 hover:underline text-center"
              >
                {"Don't have an account ? Sign up"}
              </Link>
            </div>
          </form>
        </Form>
      ) : (
        <Form {...form2}>
          <form
            onSubmit={form2.handleSubmit(handleNewPasswordSubmit)}
            className=""
          >
            <div className="flex flex-col gap-6">
              <FormField
                control={form2.control}
                name="firstName"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <Input type="text" placeholder="First Name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form2.control}
                name="lastName"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <Input type="text" placeholder="Last Name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form2.control}
                name="newPassword"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <Input
                        type="password"
                        placeholder="New Password"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <Button
              type="submit"
              variant={'ghost'}
              className="mt-6 w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-lg font-bold text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 hover:text-white hover:scale-105"
              style={{
                background:
                  'linear-gradient(92.02deg, #277FDC 0.35%, #154476 149.04%)'
              }}
              loader={loader}
            >
              Submit
            </Button>
          </form>
        </Form>
      )}
    </div>
  );
}

// (<Form {...form2}>
//   <form onSubmit={form2.handleSubmit(handleNewPasswordSubmit)} className="">

//         <div className="flex flex-col gap-6">
//           <FormField
//             control={form.control}
//             name="firstName"
//             render={({ field }) => (
//               <FormItem>
//                 <FormControl>
//                   <Input
//                     type="text"
//                     placeholder="First Name"
//                     {...field}
//                   />
//                 </FormControl>
//                 <FormMessage />
//               </FormItem>
//             )}
//           />

//           <FormField
//             control={form.control}
//             name="lastName"
//             render={({ field }) => (
//               <FormItem>
//                 <FormControl>
//                   <Input type="text" placeholder="Last Name" {...field} />
//                 </FormControl>
//                 <FormMessage />
//               </FormItem>
//             )}
//           />
//           <FormField
//             control={form.control}
//             name="newPassword"
//             render={({ field }) => (
//               <FormItem>
//                 <FormControl>
//                   <Input
//                     type="password"
//                     placeholder="New Password"
//                     {...field}
//                   />
//                 </FormControl>
//                 <FormMessage />
//               </FormItem>
//             )}
//           />
//         </div>

//       <Link
//         href="/forgot-password"
//         className="text-sm font-medium text-indigo-600 hover:underline"
//       >
//         Forgot Password?
//       </Link>

//       <Button
//         type="submit"
//         variant={'ghost'}
//         className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-lg font-bold text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 hover:text-white hover:scale-105"
//         style={{
//           background:
//             'linear-gradient(92.02deg, #277FDC 0.35%, #154476 149.04%)'
//         }}
//         loader={loader}
//         onClick={() => {
//           if (requiresNewPassword) {
//             form.handleSubmit(({ newPassword, firstName, lastName }) =>
//               handleNewPasswordSubmit(
//                 firstName || '',
//                 lastName || '',
//                 newPassword || ''
//               )
//             )();
//           } else {
//             form.handleSubmit(onSubmit)();
//           }
//         }}
//       >
//         {requiresNewPassword ? 'Set New Password' : 'Login'}
//       </Button>

//       <Link
//         href="/signup"
//         className="text-base font-medium text-indigo-600 hover:underline text-center"
//       >
//         {"Don't have an account ? Sign up"}
//       </Link>
//     </div>
//   </form>
// </Form>)}
