'use client';
import { CognitoUser } from 'amazon-cognito-identity-js';
import UserPool from '@/components/Auth/UserPool/UserPool';
import { Button } from '@/components/ui/button';
import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormMessage
} from '@/components/ui/form';
import toast from 'react-hot-toast';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { validateMaskEmail } from '@/lib/utils';

const formSchema = z.object({
  code: z.string().min(6, {
    message: 'Code must be at least 6 characters'
  })
});

export default function VerifyEmailForm() {
  const [loader, setLoader] = useState<boolean>(false);
  const [resentLoader, setResendLoader] = useState<boolean>(false);
  const router = useRouter();
  const searchParams = useSearchParams();
  const email: string = searchParams.get('email') || '';
  const maskedEmail = validateMaskEmail(email);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      code: ''
    }
  });

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setLoader(true);

    try {
      const cognitoUser = new CognitoUser({
        Username: email,
        Pool: UserPool
      });

      cognitoUser.confirmRegistration(values.code, true, (err, result) => {
        setLoader(false);
        if (err) {
          if (err?.message) toast.error(err.message);

          return;
        }

        toast.success('Email verified successfully !');
        router.push('/login');
      });
    } catch (err) {
      // console.log('catch');
    } finally {
      // console.log('finally');
    }
  }

  const resendConfirmationCode = () => {
    setResendLoader(true);

    const userData = {
      Username: email,
      Pool: UserPool
    };

    const cognitoUser = new CognitoUser(userData);

    cognitoUser.resendConfirmationCode(function (err, result) {
      setResendLoader(false);
      if (err) {
        toast.error(
          err.message || 'An error occurred while resending confirmation code'
        );
      } else {
        toast.success('Confirmation code resent successfully');
      }
    });
  };

  return (
    <div className="w-full max-w-md">
      <h2 className="text-2xl font-bold mb-8 text-secondary">Verify Email</h2>
      {maskedEmail ? (
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="">
            <div className="text-sm font-normal text-gray-700 text-right mb-4">
              Email sent to {maskedEmail}
            </div>
            <div className="flex flex-col gap-2">
              <FormField
                control={form.control}
                name="code"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <Input type="number" placeholder="Code" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="self-end">
                <Button
                  variant={'ghost'}
                  type="button"
                  onClick={resendConfirmationCode}
                  loader={resentLoader}
                  className="text-indigo-600 hover:bg-transparent hover:underline hover:text-indigo-600"
                >
                  Resend Email
                </Button>
              </div>

              <Button
                type="submit"
                variant={'ghost'}
                className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-lg font-bold text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 hover:text-white hover:scale-105"
                style={{
                  background:
                    'linear-gradient(92.02deg, #277FDC 0.35%, #154476 149.04%)'
                }}
                loader={loader}
              >
                Verify
              </Button>

              <Link
                href="/login"
                className="text-base font-medium text-indigo-600 hover:underline text-center mt-4"
              >
                Sign In
              </Link>
            </div>
          </form>
        </Form>
      ) : (
        <p className="text-red-400 text-center">
          Invalid Email, Invalid Request
        </p>
      )}
    </div>
  );
}
