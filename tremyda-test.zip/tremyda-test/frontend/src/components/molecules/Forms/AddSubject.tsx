import { Button } from '@/components/ui/button';
import React, { useCallback, useEffect, useState } from 'react';
import { Drawer } from '../Drawer/Drawer';
import { SheetClose, SheetFooter } from '@/components/ui/sheet';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage
} from '@/components/ui/form';
import api from '@/lib/services/apiWrapper';
import toast from 'react-hot-toast';
import { Skeleton } from '@/components/ui/skeleton';
import { useSubjectsStore } from '@/store/subjects/subjects';
import AccessControl from '@/components/Auth/AccessControl/AccessControl';

export default function AddSubject({ cohortId = '' }) {
  const [open, setOpen] = useState<boolean>(false);

  const drawerToggle = (open: boolean) => {
    setOpen(!open);
  };

  return (
    <AccessControl feature="createSubject">
      <Drawer
        title="Create Subject"
        header="Create Subject"
        Component={AddSubjectForm}
        open={open}
        onChange={drawerToggle}
        componentProps={{
          open: open,
          drawerToggle: drawerToggle,
          cohortId: cohortId
        }}
      />
    </AccessControl>
  );
}

const formSchema = z.object({
  cohortId: z.string().nonempty({
    message: 'Select Cohort'
  }),
  subjectDescription: z.string().min(2, {
    message: 'Subject description must be at least 3 characters.'
  }),
  cohortName: z.string().optional(),
  createdBy: z.string()
});

type AddSubjectFormProp = {
  open: boolean;
  drawerToggle: (open: boolean) => void;
  cohortId: string;
};

type Cohort = {
  cohortId: string;
  cohortName: string;
};

const AddSubjectForm = ({
  open,
  drawerToggle = () => {},
  cohortId = ''
}: AddSubjectFormProp) => {
  const [cohorts, setCohorts] = useState<Cohort[]>([]);
  const [loader, setLoader] = useState<boolean>(false);
  const [cohortLoader, setCohortLoader] = useState<boolean>(true);
  const { subjectStore, updateSubjects } = useSubjectsStore((state) => state);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      cohortId: '',
      subjectDescription: '',
      cohortName: '',
      createdBy: 'admin'
    }
  });

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setLoader(true);
    try {
      const res = await api.post(
        `/cohorts/${values.cohortId}/subjects`,
        values
      );
      if (res.status == 200) {
        toast.success('Subject Created Successfully !');
        form.reset();
        cohortId ? fetchCohortSubjects() : fetchSubjects();
        drawerToggle(open);
      }
    } catch (error) {
      toast.error('Something went wrong');
    } finally {
      setLoader(false);
    }
  }

  const fetchCohorts = useCallback(async () => {
    try {
      const res = await api.get('/cohorts?action=names');
      if (res.status === 200) {
        setCohorts(res.data.items);
      }
    } catch (error) {
      console.error('Failed to fetch Cohorts:', error);
    } finally {
      setCohortLoader(false);
    }
  }, []);

  const fetchSubjects = useCallback(async () => {
    try {
      const res = await api.get('/subjects');
      if (res.status === 200) {
        updateSubjects({ subjects: res.data.items });
      }
    } catch (error) {
      console.error('Failed to fetch sites:', error);
    }
  }, []);

  const fetchCohortSubjects = useCallback(async () => {
    try {
      const res = await api.get(`/cohorts/${cohortId}/subjects`);
      if (res.status === 200) {
        updateSubjects({ ...subjectStore, cohortSubjects: res.data.items });
      }
    } catch (error) {
      console.error('Failed to fetch subjects:', error);
    }
  }, []);

  useEffect(() => {
    fetchCohorts();
  }, [fetchCohorts]);

  return (
    <div className="h-full flex flex-col justify-between">
      {cohortLoader ? (
        <AddSubjectSkeleton />
      ) : (
        <Form {...form}>
          <form
            onSubmit={form.handleSubmit(onSubmit)}
            className="space-y-8 gap-4 my-8 mx-4 h-full flex flex-col justify-between"
          >
            <div className="flex flex-col gap-4">
              <FormField
                control={form.control}
                name="cohortId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="font-semibold">Cohorts</FormLabel>
                    <FormControl>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <SelectTrigger className="w-full">
                          <SelectValue placeholder="Select Cohort" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectGroup>
                            <SelectLabel>Cohorts</SelectLabel>
                            {cohorts.map((cohort) => (
                              <SelectItem
                                value={cohort.cohortId}
                                className="cursor-pointer"
                                key={cohort.cohortId}
                              >
                                {cohort.cohortName}
                              </SelectItem>
                            ))}
                          </SelectGroup>
                        </SelectContent>
                      </Select>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="subjectDescription"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="font-semibold">
                      Subject Description
                    </FormLabel>
                    <FormControl>
                      <Input type="text" placeholder="xyz" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <SheetFooter className="mb-10">
              <SheetClose asChild>
                <Button type="reset" variant={'outline'}>
                  Cancel
                </Button>
              </SheetClose>
              <Button type="submit" loader={loader}>
                Done
              </Button>
            </SheetFooter>
          </form>
        </Form>
      )}
    </div>
  );
};

const AddSubjectSkeleton = () => {
  return (
    <div className="flex flex-col space-y-5 mt-10">
      <Skeleton className="h-10 w-full rounded-xl bg-gray-200" />
      <Skeleton className="h-10 w-full rounded-xl bg-gray-200" />
    </div>
  );
};
