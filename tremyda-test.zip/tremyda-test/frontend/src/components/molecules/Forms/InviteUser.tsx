import { Button } from '@/components/ui/button';
import React, { useCallback, useEffect, useState } from 'react';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage
} from '@/components/ui/form';
import api from '@/lib/services/apiWrapper';
import toast from 'react-hot-toast';
import { Skeleton } from '@/components/ui/skeleton';
import { DialogClose, DialogFooter } from '@/components/ui/dialog';
import { useUsersStore } from '@/store/users/users';
import { getInviteRoles } from '@/lib/utils';

const formSchema = z.object({
  siteId: z.string().nonempty({
    message: 'Select Site'
  }),
  email: z.string().email(),
  role: z.string().nonempty({
    message: 'Select User Role'
  })
});

type InviteUserProp = {
  open: boolean;
  modalToggle: (open: boolean) => void;
};

type Site = {
  siteId: string;
  siteName: string;
};

const InviteUserForm = ({ open, modalToggle = () => {} }: InviteUserProp) => {
  const [sites, setSites] = useState<Site[]>([]);
  const [loader, setLoader] = useState<boolean>(false);
  const [siteLoader, setSiteLoader] = useState<boolean>(true);
  const { userStore, updateUsers } = useUsersStore((state) => state);
  const USER_ROLES = getInviteRoles();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      siteId: '',
      email: '',
      role: ''
    }
  });

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setLoader(true);
    try {
      const res = await api.post(`/users/invite`, values);
      console.log(res, 'response--');

      if (res.status == 200) {
        toast.success('User Invited Successfully !');
        fetchUsers();
        form.reset();
        modalToggle(!open);
      }
    } catch (error: any) {
      console.log(error?.response?.data?.message);

      toast.error(error?.response?.data?.message || 'Something went wrong');
    } finally {
      setLoader(false);
    }
  }

  const fetchSites = useCallback(async () => {
    try {
      const res = await api.get('/sites?action=names');
      if (res.status === 200) {
        setSites(res.data.items);
      }
    } catch (error) {
      console.error('Failed to fetch sites:', error);
    } finally {
      setSiteLoader(false);
    }
  }, []);

  const fetchUsers = useCallback(async () => {
    try {
      const res = await api.get('/users');
      console.log(res.data);

      if (res.status === 200) {
        updateUsers({ users: res.data.items });
      }
    } catch (error) {
      console.error('Failed to fetch users:', error);
    } finally {
      setLoader(false);
    }
  }, []);

  useEffect(() => {
    fetchSites();
  }, [fetchSites]);

  return (
    <div className="h-full flex flex-col justify-between">
      {siteLoader ? (
        <InviteUserSkeleton />
      ) : (
        <Form {...form}>
          <form
            onSubmit={form.handleSubmit(onSubmit)}
            className="space-y-2 gap-2 my-2 mx-4 h-full flex flex-col justify-between"
          >
            <div className="flex flex-col gap-2">
              <FormField
                control={form.control}
                name="siteId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="font-semibold">Sites</FormLabel>
                    <FormControl>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <SelectTrigger className="w-full">
                          <SelectValue placeholder="Select Site" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectGroup>
                            {/* <SelectLabel>Sites</SelectLabel> */}
                            {sites.map((site) => (
                              <SelectItem
                                value={site.siteId}
                                className="cursor-pointer"
                                key={site.siteId}
                              >
                                {site.siteName}
                              </SelectItem>
                            ))}
                          </SelectGroup>
                        </SelectContent>
                      </Select>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="font-semibold">Email</FormLabel>
                    <FormControl>
                      <Input
                        type="email"
                        placeholder="abc@gmail.com"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="role"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="font-semibold">User Role</FormLabel>
                    <FormControl>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <SelectTrigger className="w-full">
                          <SelectValue placeholder="Select Role" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectGroup>
                            {/* <SelectLabel>Roles</SelectLabel> */}
                            {USER_ROLES.map((role: string) => (
                              <SelectItem
                                value={role}
                                className="cursor-pointer"
                                key={role}
                              >
                                {role}
                              </SelectItem>
                            ))}
                          </SelectGroup>
                        </SelectContent>
                      </Select>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <DialogFooter className="mt-4 sm:justify-end">
              <DialogClose asChild>
                <Button type="button" variant="outline">
                  Cancel
                </Button>
              </DialogClose>
              <Button type="submit" variant="default" loader={loader}>
                Invite User
              </Button>
            </DialogFooter>
          </form>
        </Form>
      )}
    </div>
  );
};

const InviteUserSkeleton = () => {
  return (
    <div className="flex flex-col space-y-6 my-12">
      <Skeleton className="h-10 w-full rounded-xl bg-gray-200" />
      <Skeleton className="h-10 w-full rounded-xl bg-gray-200" />
      <Skeleton className="h-10 w-full rounded-xl bg-gray-200" />
    </div>
  );
};

export default InviteUserForm;
