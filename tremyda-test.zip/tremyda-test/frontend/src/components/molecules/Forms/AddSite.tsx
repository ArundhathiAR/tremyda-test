'use client';
import { Button } from '@/components/ui/button';
import React, { useCallback, useState } from 'react';
import { Drawer } from '../Drawer/Drawer';
import { SheetClose, SheetFooter } from '@/components/ui/sheet';
import { Input } from '@/components/ui/input';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage
} from '@/components/ui/form';
import api from '@/lib/services/apiWrapper';
import toast from 'react-hot-toast';
import { useSitesStore } from '@/store/sites/sites';
import AccessControl from '@/components/Auth/AccessControl/AccessControl';

export default function AddSite() {
  const [open, setOpen] = useState<boolean>(false);

  const drawerToggle = (open: boolean) => {
    setOpen(!open);
  };

  return (
    <AccessControl feature="createSite">
      <Drawer
        title="Create Site"
        header="Create Site"
        Component={AddSiteForm}
        open={open}
        onChange={drawerToggle}
        componentProps={{
          open: open,
          drawerToggle: drawerToggle
        }}
      />
    </AccessControl>
  );
}

const formSchema = z.object({
  siteName: z.string().min(2, {
    message: 'Site name must be at least 2 characters.'
  }),
  siteAddress: z.string().min(2, {
    message: 'Site address must be at least 3 characters.'
  }),
  contactName: z.string().min(2, {
    message: 'Contact name must be at least 2 characters.'
  }),
  contactEmail: z.string().email(),
  createdBy: z.string()
});

type AddSiteFormProp = {
  open: boolean;
  drawerToggle: (open: boolean) => void;
};

const AddSiteForm = ({
  open,
  drawerToggle = (open = false) => {}
}: AddSiteFormProp) => {
  const [loader, setLoader] = useState<boolean>(false);
  const { siteStore, updateSites } = useSitesStore((state) => state);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      siteName: '',
      siteAddress: '',
      contactName: '',
      contactEmail: '',
      createdBy: 'admin'
    }
  });

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setLoader(true);
    try {
      const res = await api.post('/sites', values);
      if (res.status == 200) {
        toast.success('Site Created Successfully !');
        form.reset();
        fetchSites();
        drawerToggle(open);
      }
    } catch (error) {
      toast.error('Something went wrong');
    } finally {
      setLoader(false);
    }
  }

  const fetchSites = useCallback(async () => {
    try {
      const res = await api.get('/sites');
      if (res.status === 200) {
        updateSites({ sites: res.data.items });
      }
    } catch (error) {
      console.error('Failed to fetch sites:', error);
    }
  }, [updateSites]);

  return (
    <div className="">
      <Form {...form}>
        <form
          onSubmit={form.handleSubmit(onSubmit)}
          className="space-y-8 gap-4 my-8 mx-4 h-full flex flex-col justify-between"
        >
          <div className="flex flex-col gap-4">
            <FormField
              control={form.control}
              name="siteName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="font-semibold">Site Name</FormLabel>
                  <FormControl>
                    <Input type="text" placeholder="Site 1" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="siteAddress"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="font-semibold">Site Address</FormLabel>
                  <FormControl>
                    <Input type="text" placeholder="street 2" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="contactName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="font-semibold">Contact Name</FormLabel>
                  <FormControl>
                    <Input type="text" placeholder="John Doe" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="contactEmail"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="font-semibold">Contact Email</FormLabel>
                  <FormControl>
                    <Input type="text" placeholder="abc@gmail.com" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <SheetFooter className="mb-10">
            <SheetClose asChild>
              <Button type="reset" variant={'outline'}>
                Cancel
              </Button>
            </SheetClose>
            <Button type="submit" loader={loader}>
              Done
            </Button>
          </SheetFooter>
        </form>
      </Form>
    </div>
  );
};
