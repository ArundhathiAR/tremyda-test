'use client';
import {
  CognitoUser,
  AuthenticationDetails,
  CognitoUserAttribute
} from 'amazon-cognito-identity-js';
import UserPool from '@/components/Auth/UserPool/UserPool';
import { Button } from '@/components/ui/button';
import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormMessage
} from '@/components/ui/form';
import toast from 'react-hot-toast';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

const formSchema = z.object({
  email: z.string().email()
});

const form2Schema = z.object({
  code: z
    .string()
    .min(2, {
      message: 'Code must be 6 digit'
    })
    .max(6, {
      message: 'Code must be 6 digit'
    }),
  password: z
    .string()
    .min(8, { message: 'Password must be at least 8 characters long' })
    .regex(/[A-Z]/, {
      message: 'Password must contain at least one uppercase letter'
    })
    .regex(/[a-z]/, {
      message: 'Password must contain at least one lowercase letter'
    })
    .regex(/[0-9]/, { message: 'Password must contain at least one number' })
    .regex(/[^A-Za-z0-9]/, {
      message: 'Password must contain at least one special character'
    })
});

export default function ForgotPasswordForm() {
  const [loader, setLoader] = useState<boolean>(false);
  const [updateLoader, setUpdateLoader] = useState<boolean>(false);
  const [verifyCode, setVerifyCode] = useState<boolean>(false);
  const [user, setUser] = useState<any>({});
  const [maskEmail, setMaskEmail] = useState<string>('');

  const router = useRouter();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      email: ''
    }
  });

  const form2 = useForm<z.infer<typeof form2Schema>>({
    resolver: zodResolver(form2Schema),
    defaultValues: {
      code: '',
      password: ''
    }
  });

  async function getVerificationCode(values: z.infer<typeof formSchema>) {
    setLoader(true);
    const userObj = new CognitoUser({
      Username: values.email.toLowerCase(),
      Pool: UserPool
    });
    setUser(userObj);

    userObj.forgotPassword({
      onSuccess: function (data: any) {
        setMaskEmail(data.CodeDeliveryDetails.Destination);
        setLoader(false);
        setVerifyCode(true);
      },
      onFailure: function (err: any) {
        toast.error('Email does not exist, please enter the correct email id');
        setLoader(false);
      }
    });
  }

  async function changePassword(values: z.infer<typeof form2Schema>) {
    setUpdateLoader(true);

    user.confirmPassword(values.code, values.password, {
      onSuccess() {
        toast.success('Password changed successfully.');
        setTimeout(() => {
          router.push('/login');
          setUpdateLoader(false);
        }, 1000);
      },
      onFailure(err: any) {
        toast.error(err?.message || 'Something went wrong');
        setUpdateLoader(false);
      }
    });
  }

  return (
    <div className="w-full max-w-md">
      {!verifyCode ? (
        <div>
          <h2 className="text-2xl font-bold mb-8 text-secondary">
            Forgot Password
          </h2>

          <Form {...form}>
            <form
              onSubmit={form.handleSubmit(getVerificationCode)}
              className=""
            >
              <div className="flex flex-col gap-6">
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormControl>
                        <Input type="email" placeholder="Email" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button
                  type="submit"
                  variant={'ghost'}
                  className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-lg font-bold text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 hover:text-white hover:scale-105"
                  style={{
                    background:
                      'linear-gradient(92.02deg, #277FDC 0.35%, #154476 149.04%)'
                  }}
                  loader={loader}
                >
                  Send Email
                </Button>

                <Link
                  href="/login"
                  className="text-base font-medium text-indigo-600 hover:underline text-center"
                >
                  Remember password ? Sign In
                </Link>
              </div>
            </form>
          </Form>
        </div>
      ) : (
        <div>
          <h2 className="text-2xl font-bold mb-8 text-secondary">
            Update Password
          </h2>
          <p className="text-right pb-4 text-sm">
            We have sent a password reset code by email to {maskEmail}.
          </p>
          <Form {...form2}>
            <form onSubmit={form2.handleSubmit(changePassword)} className="">
              <div className="flex flex-col gap-6">
                <FormField
                  control={form2.control}
                  name="code"
                  render={({ field }) => (
                    <FormItem>
                      <FormControl>
                        <Input type="text" placeholder="Code" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form2.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormControl>
                        <Input
                          type="password"
                          placeholder="New password"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button
                  type="submit"
                  variant={'ghost'}
                  className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-lg font-bold text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 hover:text-white hover:scale-105"
                  style={{
                    background:
                      'linear-gradient(92.02deg, #277FDC 0.35%, #154476 149.04%)'
                  }}
                  loader={updateLoader}
                >
                  Update Password
                </Button>

                <Link
                  href="/login"
                  className="text-base font-medium text-indigo-600 hover:underline text-center"
                >
                  Remember password ? Sign In
                </Link>
              </div>
            </form>
          </Form>
        </div>
      )}
    </div>
  );
}
