'use client';
import { CognitoUserAttribute } from 'amazon-cognito-identity-js';
import UserPool from '@/components/Auth/UserPool/UserPool';
import { Button } from '@/components/ui/button';
import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormMessage
} from '@/components/ui/form';
import toast from 'react-hot-toast';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

const formSchema = z.object({
  firstName: z.string().min(2, {
    message: 'First Name must be at least 2 characters'
  }),
  lastName: z.string().min(2, {
    message: 'Last Name must be at least 2 characters'
  }),
  email: z.string().email(),
  password: z
    .string()
    .min(8, { message: 'Password must be at least 8 characters long' })
    .regex(/[A-Z]/, {
      message: 'Password must contain at least one uppercase letter'
    })
    .regex(/[a-z]/, {
      message: 'Password must contain at least one lowercase letter'
    })
    .regex(/[0-9]/, { message: 'Password must contain at least one number' })
    .regex(/[^A-Za-z0-9]/, {
      message: 'Password must contain at least one special character'
    })
});

export default function SignUpForm() {
  const [loader, setLoader] = useState<boolean>(false);
  const router = useRouter();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      firstName: '',
      lastName: '',
      email: '',
      password: ''
    }
  });

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setLoader(true);

    const firstName = new CognitoUserAttribute({
      Name: 'custom:firstName',
      Value: values.firstName
    });

    const lastName = new CognitoUserAttribute({
      Name: 'custom:lastName',
      Value: values.lastName
    });

    const role = new CognitoUserAttribute({
      Name: 'custom:role',
      Value: 'SiteViewer'
    });

    try {
      UserPool.signUp(
        values.email,
        values.password,
        [firstName, lastName, role],
        [],
        (err, result) => {
          setLoader(false);
          if (err) {
            console.error(err.message || JSON.stringify(err));
            toast.error(err?.message || 'Something went wrong');
            return;
          }
          toast.success('Signed up successfully !');
          router.push('/verify-email?email=' + values.email);
        }
      );
    } catch (err) {
      // console.log(err);
    } finally {
      // console.log('finally');
    }
  }

  return (
    <div className="w-full max-w-md">
      <h2 className="text-2xl font-bold mb-8 text-secondary">Sign Up</h2>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="">
          <div className="flex flex-col gap-6">
            <FormField
              control={form.control}
              name="firstName"
              render={({ field }) => (
                <FormItem>
                  <FormControl>
                    <Input type="text" placeholder="First Name" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="lastName"
              render={({ field }) => (
                <FormItem>
                  <FormControl>
                    <Input type="text" placeholder="Last Name" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormControl>
                    <Input type="email" placeholder="Email" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <FormControl>
                    <Input type="password" placeholder="Password" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <Button
              type="submit"
              variant={'ghost'}
              className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-lg font-bold text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 hover:text-white hover:scale-105"
              style={{
                background:
                  'linear-gradient(92.02deg, #277FDC 0.35%, #154476 149.04%)'
              }}
              loader={loader}
            >
              Sign Up
            </Button>

            <Link
              href="/login"
              className="text-base font-medium text-indigo-600 hover:underline text-center"
            >
              Already have an account ? Sign In
            </Link>
          </div>
        </form>
      </Form>
    </div>
  );
}
