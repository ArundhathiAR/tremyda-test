import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle
} from '@/components/ui/sheet';
import LineGraph from '../Charts/LineChart/LineChart';
import { LoadingSpinner } from '@/components/ui/loader';
import { DeviceType } from '@/components/molecules/BigCalendar/BigCalendar';
import { formatDate, getLastFourDigits } from '@/lib/utils';
import BloodPressureGraph from '@/components/molecules/Charts/LineChart/BloodPressure';

const bpSample = [
  { date: '07-01', systolic: 120, diastolic: 80 },
  { date: '07-02', systolic: 140, diastolic: 90 },
  { date: '07-03', systolic: 115, diastolic: 75 },
  { date: '07-04', systolic: 130, diastolic: 85 },
  { date: '07-05', systolic: 125, diastolic: 82 },
  { date: '07-06', systolic: 135, diastolic: 88 },
  { date: '07-07', systolic: 110, diastolic: 70 },
  { date: '07-08', systolic: 145, diastolic: 95 },
  { date: '07-09', systolic: 125, diastolic: 80 },
  { date: '07-10', systolic: 135, diastolic: 90 }
];

interface DeviceDetailsDrawerProps {
  title?: string;
  header?: string;
  description?: string;
  isOpen: boolean;
  setIsOpen: (open: boolean) => void;
  data?: any;
  deviceData: DeviceType[];
  eventType: string;
  loader: boolean;
  
}

export function DeviceDetailsDrawer({
  header,
  description,
  isOpen = false,
  setIsOpen,
  data = [],
  deviceData,
  eventType,
  loader = true
}: DeviceDetailsDrawerProps) {

  return (
    <Sheet open={isOpen} onOpenChange={setIsOpen}>
      <SheetContent className="xl:w-[1270px] xl:max-w-screen md:w-[1000px] md:max-w-screen sm:w-full sm:max-w-screen h-full">
        <SheetHeader className="">
          <SheetTitle className="text-2xl font-semibold">{header}</SheetTitle>
          <SheetDescription>{description}</SheetDescription>
        </SheetHeader>

        {loader || deviceData?.length == 0 ? (
          <div className="flex justify-center items-center h-full">
            <LoadingSpinner />
          </div>
        ) : (
          <div>
            <div className="border-b border-gray-400 mt-2 mx-[-20px]"></div>

            <div className="flex flex-row justify-between items-center mt-5 mb-4 bg-[#F3F3F3] px-2 md:px-4 lg:px-8 py-4 mx-4 rounded-xl">
              <div className="flex gap-2 ">
                <div className="flex flex-col gap-1">
                  <h3 className="text-lg font-medium text-secondary">
                    Device ID
                  </h3>
                  <h2 className="text-2xl font-normal">
                    # {getLastFourDigits(deviceData[0].deviceId)}
                  </h2>
                </div>
              </div>

              <div className="flex gap-2 ">
                <div className="flex flex-col gap-1">
                  <h3 className="text-lg font-medium text-secondary">
                    Device Type
                  </h3>
                  <h2 className="text-lg font-normal">
                    {deviceData[0].deviceType}
                  </h2>
                </div>
              </div>

              <div className="flex gap-2 ">
                <div className="flex flex-col gap-1">
                  <h3 className="text-lg font-medium">Description</h3>
                  <h2 className="text-lg font-normal">
                    {deviceData[0].deviceDescription}
                  </h2>
                </div>
              </div>

              <div className="flex gap-2 ">
                <div className="flex flex-col gap-1">
                  <h3 className="text-lg font-medium">Date Assigned</h3>
                  <h2 className="text-lg font-normal">
                    {formatDate(deviceData[0].createdAt)}
                  </h2>
                </div>
              </div>

              <div className="flex gap-2 ">
                <div className="flex flex-col gap-1">
                  <h3 className="text-lg font-medium">Date Created</h3>
                  <h2 className="text-lg font-normal">
                    {formatDate(deviceData[0].updatedAt)}
                  </h2>
                </div>
              </div>
            </div>

            <div className="mt-2 overflow-x-auto">
            {eventType == 'dataset' ? (
                <LineGraph data={data} />
              ) : (
                <BloodPressureGraph data={bpSample} />
              )}
            </div>
          </div>
        )}
      </SheetContent>
    </Sheet>
  );
}
