'use client';
import React from 'react';
import {
  BarChart,
  Bar,
  ResponsiveContainer,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid
} from 'recharts';

import './styles.css';
import { fillMissingDates } from '@/lib/utils';
import { EventRecord } from '@/lib/types/dashboard';

type BarGraphProp = {
  events: EventRecord[];
};

export default function BarGraph({ events }: BarGraphProp) {
  console.log(events);
  
  const eventRecords = fillMissingDates(events);

  console.log(eventRecords);

  // Sort eventRecords by createdDate

  // console.log(eventRecords);

  return (
    <div className="bg-white p-6 rounded-lg w-full">
      <div className="h-96">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart
            data={eventRecords}
            margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
          >
            {/* <CartesianGrid strokeDasharray="3 3" /> */}
            <XAxis
              dataKey="dayOfTheWeek"
              // label={{
              //   value: 'Day of Week',
              //   position: 'insideBottomRight',
              //   offset: -10
              // }}
            />
            {/* <YAxis
              label={{
                value: 'Events',
                angle: -90,
                position: 'insideLeft'
              }}
            /> */}
            {/* <Tooltip /> */}
            <Legend />
            <Bar
              dataKey="numberOfEvents"
              fill="#277FDB"
              shape={<CustomBar />}
              className="custom-bar"
              label={{ value: 'Events', position: 'top' }}
            />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

const CustomBar = (props: any) => {
  const { fill, x, y, width, height } = props;
  return (
    <rect
      x={x}
      y={y}
      width={width}
      height={height}
      fill={fill}
      rx={8} // Adjust this value to change the roundness of the corners
    />
  );
};
