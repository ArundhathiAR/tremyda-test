'use client';
import React from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ReferenceLine
} from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

type LineGraphProps = {
  data?: Array<any>;
};

const BloodPressureGraph = ({ data = [] }: LineGraphProps) => {
  const systolicValues = data.map((item) => item['systolic']);
  const minSystolic = Math.min(...systolicValues);
  const maxSystolic = Math.max(...systolicValues);

  const diastolicValues = data.map((item) => item['diastolic']);
  const minDiastolic = Math.min(...diastolicValues);
  const maxDiastolic = Math.max(...diastolicValues);

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-xl font-semibold text-gray-800">
          Blood Pressure Readings
        </CardTitle>
        <Badge variant="secondary" className="ml-auto">
          Total Records: {data.length}
        </Badge>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={400}>
          <LineChart
            data={data}
            margin={{
              top: 20,
              right: 30,
              left: 20,
              bottom: 10
            }}
          >
            <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
            <XAxis
              dataKey="date"
              stroke="#888888"
              tick={{ fill: '#888888' }}
              tickLine={{ stroke: '#888888' }}
            />
            <YAxis
              stroke="#888888"
              tick={{ fill: '#888888' }}
              tickLine={{ stroke: '#888888' }}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: 'rgba(255, 255, 255, 0.8)',
                border: 'none',
                borderRadius: '4px',
                boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
              }}
            />
            <Legend verticalAlign="top" height={36} iconType="circle" />
            <ReferenceLine
              y={minSystolic}
              label={{ value: 'Min Systolic', fill: '#4a90e2', fontSize: 12 }}
              stroke="#4a90e2"
              strokeDasharray="3 3"
            />
            <ReferenceLine
              y={maxSystolic}
              label={{ value: 'Max Systolic', fill: '#e74c3c', fontSize: 12 }}
              stroke="#e74c3c"
              strokeDasharray="3 3"
            />
            <Line
              type="monotone"
              dataKey="systolic"
              stroke="#4a90e2"
              strokeWidth={2}
              dot={{ fill: '#4a90e2', strokeWidth: 2 }}
              activeDot={{ r: 8 }}
            />
            <ReferenceLine
              y={minDiastolic}
              label={{ value: 'Min Diastolic', fill: '#2ecc71', fontSize: 12 }}
              stroke="#2ecc71"
              strokeDasharray="3 3"
            />
            <ReferenceLine
              y={maxDiastolic}
              label={{ value: 'Max Diastolic', fill: '#e67e22', fontSize: 12 }}
              stroke="#e67e22"
              strokeDasharray="3 3"
            />
            <Line
              type="monotone"
              dataKey="diastolic"
              stroke="#e74c3c"
              strokeWidth={2}
              dot={{ fill: '#e74c3c', strokeWidth: 2 }}
              activeDot={{ r: 8 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
};

export default BloodPressureGraph;
