'use client';
import React, { useMemo } from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';
import { Download } from 'lucide-react';
import jsonToCsvExport from 'json-to-csv-export';
import { UniversalTooltip } from '../../Tooltip/Tooltip';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

type LineGraphProps = {
  data?: Array<any>;
};

export default function LineGraph({ data = [] }: LineGraphProps) {
  const xDomain = useMemo(() => {
    const voltages = data.map((d) => d.voltage);
    const min = Math.min(...voltages);
    const max = Math.max(...voltages);
    const padding = (max - min) * 0.1; // 10% padding
    return [min - padding, max + padding];
  }, [data]);

  const yDomain = useMemo(() => {
    const currents = data.map((d) => d.current);
    const min = Math.min(...currents);
    const max = Math.max(...currents);
    const padding = (max - min) * 0.1; // 10% padding
    return [min - padding, max + padding];
  }, [data]);

  const dataToConvert = {
    data: data,
    filename: 'VoltageCurrentData',
    delimiter: ',',
    headers: ['voltage', 'current']
  };

  return (
    <Card className="w-full">
      <CardHeader className="flex flex-row items-center justify-between pt-2">
        <CardTitle className="text-lg font-semibold text-gray-800">
          {/* Voltage-Current Characteristics */}
        </CardTitle>
        <div className="flex items-center gap-4">
          <Badge variant="secondary">Total Records: {data.length}</Badge>
          <UniversalTooltip
            trigger={
              <Button
                variant="outline"
                size="sm"
                onClick={() => jsonToCsvExport(dataToConvert)}
              >
                <Download className="h-4 w-4 mr-2" />
                CSV
              </Button>
            }
            content={<p>Download CSV</p>}
          />
        </div>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={500}>
          <LineChart
            data={data}
            margin={{
              top: 20,
              right: 30,
              left: 20,
              bottom: 10
            }}
          >
            <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
            <XAxis
              dataKey="voltage"
              type="number"
              domain={xDomain}
              allowDataOverflow
              stroke="#888888"
              tick={{ fill: '#888888' }}
              tickLine={{ stroke: '#888888' }}
              tickFormatter={(value) => value.toFixed(2)}
              label={{
                value: 'Voltage (mV)',
                position: 'insideBottom',
                offset: -10
              }}
            />
            <YAxis
              dataKey="current"
              type="number"
              domain={yDomain}
              allowDataOverflow
              stroke="#888888"
              tick={{ fill: '#888888' }}
              tickLine={{ stroke: '#888888' }}
              tickFormatter={(value) => value.toFixed(2)}
              label={{
                value: 'Current (μA)',
                angle: -90,
                position: 'insideLeft'
              }}
            />
            <Tooltip content={CustomTooltip} />
            <Legend verticalAlign="top" height={36} iconType="circle" />
            <Line
              type="monotone"
              dataKey="current"
              stroke="#18A0FB"
              strokeWidth={2}
              dot={false}
              activeDot={{ r: 8 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}

const CustomTooltip = ({ active, payload }: any) => {
  if (active && payload?.length) {
    return (
      <div className="bg-white p-2 shadow-md rounded-md border border-gray-200">
        {payload.map((entry: any, index: number) => (
          <div key={index} className="text-sm">
            <p className="font-semibold text-gray-700">
              Voltage:{' '}
              {typeof entry.payload.voltage === 'number'
                ? entry.payload.voltage.toFixed(2)
                : entry.payload.voltage}{' '}
              mV
            </p>
            <p className="font-semibold text-[#18A0FB]">
              Current:{' '}
              {typeof entry.payload.current === 'number'
                ? entry.payload.current.toFixed(2)
                : entry.payload.current}{' '}
              μA
            </p>
          </div>
        ))}
      </div>
    );
  }
  return null;
};
