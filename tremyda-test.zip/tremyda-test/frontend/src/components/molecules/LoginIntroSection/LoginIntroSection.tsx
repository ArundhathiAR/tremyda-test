import Image from 'next/image';

export function LoginIntroSection() {
  return (
    <div className="relative  col-span-4  flex-col justify-center items-center text-white p-4 hidden md:flex">
      <div className="absolute inset-0">
        <Image
          src="/images/login-frame.svg"
          alt="Background Gradient"
          fill
          style={{ objectFit: 'cover' }}
          className="w-full h-full"
        />
      </div>
      <div className="relative z-10">
        <Image
          src="/images/login-icon.svg"
          alt="Dashboard Icon"
          width={422}
          height={282}
        />
      </div>
      <h1 className="relative z-10 mt-6 text-4xl font-bold">
        Easy to use Dashboard
      </h1>
      <p className="relative z-10 mt-4 text-lg text-center font-light">
        The best Dashboard to manage all your daily activities hassle-free.
      </p>
    </div>
  );
}
