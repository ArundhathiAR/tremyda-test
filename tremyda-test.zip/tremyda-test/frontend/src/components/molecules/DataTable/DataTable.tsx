'use client';
import * as React from 'react';
import {
  ColumnFiltersState,
  SortingState,
  VisibilityState,
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable
} from '@tanstack/react-table';
import { SearchInput } from '@/components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from '@/components/ui/table';

interface DataTableProps {
  title?: string;
  data?: Array<any>;
  columns?: Array<any>;
  handleRowClick?: Function;
  HeaderButtonComponent?: React.FC<any>;
  HeaderButtonComponentProps?: any;
  enableSearch?: boolean;
  loader?: boolean;
}

export function DataTable({
  title = 'Table',
  data = [],
  columns = [],
  handleRowClick,
  HeaderButtonComponent,
  HeaderButtonComponentProps = {},
  enableSearch = false,
  loader = false
}: DataTableProps) {
  const [sorting, setSorting] = React.useState<SortingState>([]);
  // const [columnFilters, setColumnFilters] = React.useState<ColumnFiltersState>(
  //   []
  // );
  // const [search, setSearch] = React.useState<string>('');
  const [globalFilter, setGlobalFilter] = React.useState('');
  const [columnVisibility, setColumnVisibility] =
    React.useState<VisibilityState>({});
  const [rowSelection, setRowSelection] = React.useState({});

  const customFilter = (rows: any, filterValue: any) => {
    if (!filterValue) return rows;
    const value = filterValue.toLowerCase();
    return rows.filter((row: any) =>
      Object.values(row.original).some((cell) =>
        String(cell).toLowerCase().includes(value)
      )
    );
  };

  const table = useReactTable({
    data,
    columns,
    state: {
      sorting,
      globalFilter,
      columnVisibility,
      rowSelection
    },
    onSortingChange: setSorting,
    onGlobalFilterChange: setGlobalFilter,
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    onColumnVisibilityChange: setColumnVisibility,
    onRowSelectionChange: setRowSelection,
    filterFns: {
      customFilter
    }
  });

  const onRowClick = (row: any) => {
    if (handleRowClick) handleRowClick(row);
  };

  return (
    <div className="w-full h-96">
      <div className="flex items-center justify-between pb-5">
        <div>
          <h3 className="text-2xl font-medium font-sans">{title}</h3>
        </div>
        <div className="flex items-center gap-8">
          {enableSearch && (
            <SearchInput
              placeholder="Search..."
              value={globalFilter}
              onChange={(e) => setGlobalFilter(e.target.value)}
              className="max-w-sm"
            />
          )}
          {HeaderButtonComponent && (
            <HeaderButtonComponent {...HeaderButtonComponentProps} />
          )}
        </div>
      </div>
      <div className="rounded-lg border bg-white p-2">
        <Table>
          <TableHeader>
            {table.getHeaderGroups().map((headerGroup) => (
              <TableRow
                key={headerGroup.id}
                className="border-b-0 border-secondary text-base"
              >
                {headerGroup.headers.map((header) => {
                  return (
                    <TableHead key={header.id} className="font-semibold">
                      {header.isPlaceholder
                        ? null
                        : flexRender(
                            header.column.columnDef.header,
                            header.getContext()
                          )}
                    </TableHead>
                  );
                })}
              </TableRow>
            ))}
          </TableHeader>
          <TableBody>
            {loader && (
              <TableRow>
                <TableCell
                  colSpan={columns.length}
                  className="h-24 justify-center text-center text-lg text-gray-500"
                >
                  {/* <LoadingSpinner /> */}
                  {'Loading...'}
                </TableCell>
              </TableRow>
            )}

            {table.getRowModel().rows?.length > 0 &&
              table.getRowModel().rows.map((row) => (
                <TableRow
                  key={row.id}
                  data-state={row.getIsSelected() && 'selected'}
                  onClick={() => onRowClick(row)}
                  className="cursor-pointer"
                >
                  {row.getVisibleCells().map((cell) => (
                    <TableCell key={cell.id}>
                      {flexRender(
                        cell.column.columnDef.cell,
                        cell.getContext()
                      )}
                    </TableCell>
                  ))}
                </TableRow>
              ))}

            {!loader && table.getRowModel().rows?.length == 0 && (
              <TableRow>
                <TableCell
                  colSpan={columns.length}
                  className="h-24 text-center"
                >
                  No results.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
      {/* <div className="flex items-center justify-end space-x-2 py-4">
        <div className="flex-1 text-sm text-muted-foreground">
          {table.getFilteredSelectedRowModel().rows.length} of{' '}
          {table.getFilteredRowModel().rows.length} row(s) selected.
        </div>
        <div className="space-x-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => table.previousPage()}
            disabled={!table.getCanPreviousPage()}
          >
            Previous
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => table.nextPage()}
            disabled={!table.getCanNextPage()}
          >
            Next
          </Button>
        </div>
      </div> */}
    </div>
  );
}
