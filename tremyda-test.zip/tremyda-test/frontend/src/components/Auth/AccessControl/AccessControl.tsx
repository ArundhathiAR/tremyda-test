import { USER_PERMISSIONS } from '@/constants';
import { getUserRoleFromJWT } from '@/lib/utils';
import { ReactNode } from 'react';

interface AccessControlProps {
  children: ReactNode;
  feature: string;
}

const AccessControl = (props: AccessControlProps) => {
  const role = getUserRoleFromJWT();
  const feature_access = USER_PERMISSIONS[role];
  const access = feature_access[props.feature];

  if (access) {
    return props.children;
  } else {
    return null;
  }
};

export default AccessControl;
