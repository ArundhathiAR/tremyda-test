'use client';
import { useEffect, useState } from 'react';
import { redirect } from 'next/navigation';
import { isLoggedIn } from '@/lib/services/authUtils';
import { checkSession } from '@/components/Auth/Session/session';

export default function AuthProvider({ children }: any) {
  const [isLoggedInState, setIsLoggedInState] = useState<boolean | null>(null);
  const [redirected, setRedirected] = useState<boolean>(false); // Track if redirection has occurred
  const sessionInterval = parseInt(
    process.env.NEXT_PUBLIC_SESSION_CHECK_INTERVAL || '3'
  );

  useEffect(() => {
    const intervalId = setInterval(
      () => {
        checkSession();
      },
      sessionInterval * 60 * 1000
    );

    return () => clearInterval(intervalId);
  }, []);

  useEffect(() => {
    const onStorage = (event: StorageEvent) => {
      if (event.key === 'logout') {
        window.location.href = '/login';
      }
    };
    window.addEventListener('storage', onStorage);

    return () => window.removeEventListener('storage', onStorage);
  }, []);

  useEffect(() => {
    const auth = isLoggedIn();
    setIsLoggedInState(auth);

    if (auth === false && !redirected) {
      setRedirected(true);
      redirect('/login');
      // Set redirected to true to prevent multiple redirections
    }
  }, [redirected]); // Add redirected to dependencies to trigger effect on redirection

  if (isLoggedInState === null || (isLoggedInState === false && !redirected)) {
    return null; // Return null if still loading or if redirection hasn't occurred yet
  }

  return <>{children}</>;
}
