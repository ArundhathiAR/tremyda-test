import { CognitoUserSession } from 'amazon-cognito-identity-js';
import UserPool from '@/components/Auth/UserPool/UserPool';
import { logoutAndRedirectToLogin } from '@/lib/services/authUtils';

export const checkSession = () => {
  const cognitoUser = UserPool.getCurrentUser();

  if (!cognitoUser) {
    window.location.href = '/login';
    return;
  }

  cognitoUser.getSession(
    (err: Error | null, session: CognitoUserSession | null) => {
      if (err || !session?.isValid()) {
        logoutUser();
      }
    }
  );
};

export const logoutUser = () => {
  const cognitoUser = UserPool.getCurrentUser();
  if (cognitoUser) {
    cognitoUser.signOut();
  }

  logoutAndRedirectToLogin();
};
