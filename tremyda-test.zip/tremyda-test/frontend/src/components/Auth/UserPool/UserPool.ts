import { CognitoUserPool } from 'amazon-cognito-identity-js';

const poolData: any = {
  UserPoolId: process.env.NEXT_PUBLIC_USER_POOL_ID?.toString(),
  ClientId: process.env.NEXT_PUBLIC_CLIENT_ID?.toString()
};

// eslint-disable-next-line import/no-anonymous-default-export
export default new CognitoUserPool(poolData);
