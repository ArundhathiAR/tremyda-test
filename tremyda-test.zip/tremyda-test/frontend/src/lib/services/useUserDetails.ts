import { useState, useEffect } from 'react';
import { getUserAttributesFromLocalStorage } from './authUtils';

const useUserDetails = () => {
  const [details, setDetails] = useState({});

  useEffect(() => {
    const userAttributes = getUserAttributesFromLocalStorage();
    if (userAttributes) {
      setDetails({ ...userAttributes });
    }
  }, []);

  return details;
};

export default useUserDetails;
