interface AttributesObject {
  [key: string]: any;
}

export function getUserAttributesFromLocalStorage(): AttributesObject | null {
  if (typeof window !== 'undefined') {
    // Check if running in a browser environment
    // Retrieve the stored JSON string from localStorage
    const storedAttributesJSON = localStorage.getItem('userAttributes-profile');

    if (storedAttributesJSON !== null) {
      // Parse the JSON string back to an object
      return JSON.parse(storedAttributesJSON);
    }
  }
  return null;
}

export function isLoggedIn(): boolean {
  // Check if user attributes exist in localStorage
  const userAttributes = getUserAttributesFromLocalStorage();
  return userAttributes !== null;
}

export function logoutAndRedirectToLogin(): void {
  if (typeof window !== 'undefined') {
    // Check if running in a browser environment
    // Clear user attributes from localStorage
    localStorage.removeItem('userAttributes-profile');
    localStorage.removeItem('accessToken-profile');
    localStorage.setItem('logout', Date.now().toString());

    // Redirect to login screen
    window.location.href = '/login';
  }
}
