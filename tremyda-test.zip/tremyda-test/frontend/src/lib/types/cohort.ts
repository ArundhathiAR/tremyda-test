export type DeleteCohortProp = {
  siteId: string;
  cohortId: string;
  siteCohort?: boolean;
};

export type ActivateDeactivateCohortProp = {
  siteId: string;
  cohortId: string;
  status: string;
};
