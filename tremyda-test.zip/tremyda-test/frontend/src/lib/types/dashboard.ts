export type CardCountsType = {
  numberOfCohorts: number;
  numberOfSubjects: number;
  numberOfDevices: number;
  numberOfSites: number;
};

export type EventRecord = {
  createdDate: string;
  numberOfEvents: number | string;
  dayOfTheWeek?: string;
};

export type UpdatesType = {
  siteId?: string;
  siteName?: string;
  cohortId?: string;
  cohortName?: string;
  subjectId?: string;
  subjectName?: string;
  deviceId?: string;
  name?: string;
  type: string;
  action?: string;
  createdAt: string;
};

export type AlertsType = {
  siteId?: string;
  siteName?: string;
  cohortId?: string;
  cohortName?: string;
  subjectId?: string;
  subjectName?: string;
  deviceId?: string;
  name?: string;
  type: string;
  action?: string;
  createdAt: string;
};
