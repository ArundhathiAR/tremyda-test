export type DeleteSubjectProp = {
  cohortId: string;
  subjectId: string;
};
