export type DeleteSiteProp = {
  siteId: string;
};
