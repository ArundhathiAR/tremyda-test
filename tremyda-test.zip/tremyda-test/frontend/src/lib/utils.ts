import { type ClassValue, clsx } from 'clsx';
import moment from 'moment';
import toast from 'react-hot-toast';
import { twMerge } from 'tailwind-merge';
import { EventRecord } from './types/dashboard';
import { jwtDecode } from 'jwt-decode';
import { redirect } from 'next/navigation';
import jsonToCsvExport from 'json-to-csv-export';
import { USER_PERMISSIONS } from '@/constants';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function getLastFourDigits(uuid: string): string {
  try {
    return uuid.slice(-4);
  } catch {
    return '';
  }
}

export function formatDate(date: string): string {
  try {
    return moment(date).format('MM/DD/YYYY');
  } catch {
    return '';
  }
}

export function formatDateTime(date: string): string {
  try {
    return moment(date).format('MM/DD/YYYY HH:mm:ss');
  } catch {
    return '';
  }
}

export function saveTokensToLocalStorage(
  accessToken: string,
  refreshToken: string
) {
  localStorage.setItem('accessToken-profile', accessToken);
  localStorage.setItem('refreshToken-profile', refreshToken);
}

export function formatEToNumber(num: number): string {
  return (num * 1e6).toFixed(2);
}

export function validateMaskEmail(email: string) {
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailPattern.test(email)) {
    return '';
  }

  const [username, domain] = email.split('@');
  if (username.length <= 2) {
    return email; // If username is too short, don't mask it.
  }

  const maskedUsername =
    username[0] +
    '*'.repeat(username.length - 2) +
    username[username.length - 1];
  return `${maskedUsername}@${domain}`;
}

export function noDevicesLinkedMessage() {
  toast('⚠️ There is no active device linked to the subject');
}

export function fillMissingDates(records: EventRecord[]): EventRecord[] {
  const last7Days = Array.from({ length: 7 }, (_, index) => {
    const currentDate = new Date();
    currentDate.setDate(currentDate.getDate() - index);
    const formattedDate = currentDate.toISOString().split('T')[0];
    const dayOfTheWeek = currentDate.toLocaleString('en-US', {
      weekday: 'short'
    });
    return { createdDate: formattedDate, dayOfTheWeek };
  });

  const recordMap = new Map<string, EventRecord>();
  records.forEach((record) => {
    const recordDate = new Date(record.createdDate);
    record.dayOfTheWeek = recordDate.toLocaleString('en-US', {
      weekday: 'short'
    });
    record.numberOfEvents = parseInt(record.numberOfEvents as string, 10);
    recordMap.set(record.createdDate, record);
  });

  const filledRecords = last7Days.map(({ createdDate, dayOfTheWeek }) => {
    return (
      recordMap.get(createdDate) || {
        createdDate,
        numberOfEvents: 0,
        dayOfTheWeek
      }
    );
  });

  filledRecords.sort(
    (a, b) =>
      new Date(a.createdDate).getTime() - new Date(b.createdDate).getTime()
  );

  return filledRecords;
}

interface DecodedToken {
  'cognito:groups'?: string;
  [key: string]: any;
}

export function getUserRoleFromJWT() {
  if (typeof window !== 'undefined') {
    const accessToken = localStorage.getItem('accessToken-profile');
    if (accessToken) {
      const decoded: DecodedToken = jwtDecode<DecodedToken>(accessToken);
      const role = decoded['cognito:groups']
        ? decoded['cognito:groups'][0]
        : 'SiteViewer';
      return role;
    } else {
      localStorage.clear();
      redirect('/login');
    }
  } else return 'SiteViewer';
}

export function getInviteRoles() {
  const role = getUserRoleFromJWT();
  const userRoles = USER_PERMISSIONS[role]?.inviteRoles || [];
  return userRoles;
}

export const exportDataToCsv = () => {
  // Convert and trigger download
  const ipAddressesData = [
    {
      id: '1',
      name: 'Sarajane Wheatman',
      ip: '40.98.252.240'
    },
    {
      id: '2',
      name: 'Linell Humpherston',
      ip: '82.225.151.150'
    }
  ];

  const dataToConvert = {
    data: ipAddressesData,
    filename: 'ip_addresses_report',
    delimiter: ',',
    headers: ['IP', 'Full Name', 'IP Address']
  };
  jsonToCsvExport(dataToConvert);
};
