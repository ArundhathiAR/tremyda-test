import { ColumnDef } from '@tanstack/react-table';
import { EllipsisVertical } from 'lucide-react';
import { formatDate, getLastFourDigits } from '../utils';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { DeleteSite } from '@/components/molecules/Modals/DeleteSite/DeleteSite';

export type SiteType = {
  siteId: string;
  name: string;
  address: string;
  cohorts: number;
  subjects: number;
  createdAt: string;
};

export const SitesColumns: ColumnDef<SiteType>[] = [
  {
    accessorKey: 'siteId',
    header: 'Site ID',
    cell: ({ row }) => (
      <div className="capitalize">
        {getLastFourDigits(row.getValue('siteId'))}
      </div>
    )
  },
  {
    accessorKey: 'siteName',
    header: 'Site Name',
    cell: ({ row }) => {
      return <div className="capitalize">{row.getValue('siteName')}</div>;
    }
  },
  {
    accessorKey: 'siteAddress',
    header: 'Address',
    cell: ({ row }) => (
      <div className="capitalize">{row.getValue('siteAddress')}</div>
    )
  },
  {
    accessorKey: 'numberOfCohorts',
    header: 'Cohorts',
    cell: ({ row }) => (
      <div className="capitalize pl-4">{row.getValue('numberOfCohorts')}</div>
    )
  },
  {
    accessorKey: 'numberOfSubjects',
    header: 'Subjects',
    cell: ({ row }) => (
      <div className="capitalize pl-4">{row.getValue('numberOfSubjects')}</div>
    )
  },
  {
    accessorKey: 'createdAt',
    header: 'Date Created',
    cell: ({ row }) => (
      <div className="capitalize">{formatDate(row.getValue('createdAt'))}</div>
    )
  },
  {
    id: 'actions',
    enableHiding: false,
    cell: ({ row }) => {
      return (
        <>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="h-8 w-8 p-0">
                <span className="sr-only">Open menu</span>
                <EllipsisVertical className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="cursor-pointer">
              <DropdownMenuItem
                onClick={(e) => {
                  e.stopPropagation();
                  console.log(row.original.siteId);
                }}
              >
                <DeleteSite siteId={row.original.siteId} />
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </>
      );
    }
  }
];
