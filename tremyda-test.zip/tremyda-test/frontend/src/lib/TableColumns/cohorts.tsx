import { Badge } from '@/components/ui/badge';
import { ColumnDef } from '@tanstack/react-table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { formatDate } from '../utils';
import { EllipsisVertical } from 'lucide-react';
import { DeleteCohort } from '@/components/molecules/Modals/DeleteCohort/DeleteCohort';
import { ActivateDeactivateCohort } from '@/components/molecules/Modals/ActivateDeactivateCohort/ActivateDeactivateCohort';

export type CohortType = {
  cohortId: string;
  siteId: string;
  name: string;
  description: string;
  subjects: number;
  sites: number;
  cohortStatus: string;
  createdAt: string;
};

export const CohortColumns: ColumnDef<CohortType>[] = [
  //   {
  //     accessorKey: 'id',
  //     header: 'Cohort ID',
  //     cell: ({ row }) => <div className="capitalize">#{row.getValue('id')}</div>
  //   },
  {
    accessorKey: 'cohortName',
    header: 'Cohort Name',
    cell: ({ row }) => (
      <div className="capitalize">{row.getValue('cohortName')}</div>
    )
  },
  {
    accessorKey: 'cohortDescription',
    header: 'Description',
    cell: ({ row }) => (
      <div className="capitalize">{row.getValue('cohortDescription')}</div>
    )
  },
  {
    accessorKey: 'numberOfSubjects',
    header: 'Subjects',
    cell: ({ row }) => (
      <div className="capitalize pl-4">{row.getValue('numberOfSubjects')}</div>
    )
  },
  {
    accessorKey: 'cohortStatus',
    header: 'Status',
    cell: ({ row }) => (
      <div className="capitalize">
        <Badge variant={row.getValue('cohortStatus')}>
          {row.getValue('cohortStatus')}
        </Badge>
      </div>
    )
  },
  {
    accessorKey: 'createdAt',
    header: 'Date Created',
    cell: ({ row }) => (
      <div className="capitalize">{formatDate(row.getValue('createdAt'))}</div>
    )
  },
  {
    id: 'actions',
    enableHiding: false,
    size: 20,
    cell: ({ row }) => {
      return (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="h-8 w-8 p-0">
              <span className="sr-only">Open menu</span>
              <EllipsisVertical className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem
              onClick={(e) => {
                e.stopPropagation();
                // console.log(row.original.cohortId);
              }}
            >
              <ActivateDeactivateCohort
                siteId={row.original.siteId}
                cohortId={row.original.cohortId}
                status={row.original.cohortStatus}
              />
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              onClick={(e) => {
                e.stopPropagation();
                // console.log(row.original.id);
              }}
            >
              <DeleteCohort
                siteId={row.original.siteId}
                cohortId={row.original.cohortId}
                siteCohort={true}
              />
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      );
    }
  }
];
