import { ColumnDef } from '@tanstack/react-table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { formatDate, getLastFourDigits } from '../utils';
import { EllipsisVertical } from 'lucide-react';

export type UsersType = {
  email: string;
  role: string;
};

export const UsersColumn: ColumnDef<UsersType>[] = [
  {
    accessorKey: 'username',
    header: 'User ID',
    cell: ({ row }) => (
      <div className="capitalize">
        {getLastFourDigits(row.getValue('username'))}
      </div>
    )
  },
  {
    accessorKey: 'email',
    header: 'Email',                                                
    cell: ({ row }) => <div className="lowercase">{row.getValue('email')}</div>
  },
  {
    accessorKey: 'role',
    header: 'Role',
    cell: ({ row }) => <div className="capitalize ">{row.getValue('role')}</div>
  },
  {
    accessorKey: 'userStatus',
    header: 'Status',
    cell: ({ row }) => {
      const status = row.getValue('userStatus');
      return (
        <div className='flex justify-center'>
        <span
          className={`text-center capitalize text-white px-2 rounded-md ${status == 'CONFIRMED' ? 'bg-green-500 ' : 'bg-red-400'}`}
        >
          {row.getValue('userStatus')}
        </span>
        </div>
      );
    }
  },
  {
    accessorKey: 'userCreatedDate',
    header: 'Date Created',
    cell: ({ row }) => (
      <div className="capitalize">
        {formatDate(row.getValue('userCreatedDate'))}
      </div>
    )
  },
  {
    id: 'actions',
    enableHiding: false,
    cell: ({ row }) => {
      return (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="h-8 w-8 p-0">
              <span className="sr-only">Open menu</span>
              <EllipsisVertical className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="cursor-pointer">
            <DropdownMenuItem>Delete</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      );
    }
  }
];
