import { ColumnDef } from '@tanstack/react-table';
import { formatDate, getLastFourDigits } from '../utils';

export type DeviceType = {
  id: number;
  type: string;
  description: string;
  assignedAt: string;
  createdAt: string;
};

export const DevicesColumns: ColumnDef<DeviceType>[] = [
  {
    accessorKey: 'deviceId',
    header: 'Device ID',
    cell: ({ row }) => (
      <div className="capitalize">
        {getLastFourDigits(row.getValue('deviceId'))}
      </div>
    )
  },
  {
    accessorKey: 'deviceType',
    header: 'Device Type',
    cell: ({ row }) => (
      <div className="capitalize">{row.getValue('deviceType')}</div>
    )
  },
  {
    accessorKey: 'deviceDescription',
    header: 'Device Description',
    cell: ({ row }) => (
      <div className="capitalize">{row.getValue('deviceDescription')}</div>
    )
  },
  // {
  //   accessorKey: 'assignedAt',
  //   header: 'Date Assigned',
  //   cell: ({ row }) => (
  //     <div className="capitalize">{row.getValue('assignedAt')}</div>
  //   )
  // },
  {
    accessorKey: 'createdAt',
    header: 'Date Created',
    cell: ({ row }) => (
      <div className="capitalize">{formatDate(row.getValue('createdAt'))}</div>
    )
  }
];
