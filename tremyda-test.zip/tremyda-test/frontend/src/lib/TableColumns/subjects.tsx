import { ColumnDef } from '@tanstack/react-table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { formatDate, getLastFourDigits } from '../utils';
import { EllipsisVertical } from 'lucide-react';
import { DeleteSubject } from '@/components/molecules/Modals/DeleteSubject/DeleteSubject';

export type SubjectsType = {
  subjectId: string;
  cohortId: string;
  description: string;
  devices: number;
  sites: number;
  createdAt: string;
};

export const SubjectsColumns: ColumnDef<SubjectsType>[] = [
  {
    accessorKey: 'subjectId',
    header: 'Subject ID',
    cell: ({ row }) => (
      <div className="capitalize">
        {getLastFourDigits(row.getValue('subjectId'))}
      </div>
    )
  },
  {
    accessorKey: 'subjectName',
    header: 'Subject Name',
    cell: ({ row }) => (
      <div className="capitalize">
        {getLastFourDigits(row.getValue('subjectName'))}
      </div>
    )
  },
  {
    accessorKey: 'cohortId',
    header: 'Cohort ID',
    cell: ({ row }) => (
      <div className="capitalize">
        {getLastFourDigits(row.getValue('cohortId'))}
      </div>
    )
  },
  {
    accessorKey: 'subjectDescription',
    header: 'Description',
    cell: ({ row }) => (
      <div className="capitalize">{row.getValue('subjectDescription')}</div>
    )
  },
  {
    accessorKey: 'numberOfDevices',
    header: 'Devices',
    cell: ({ row }) => (
      <div className="capitalize pl-4">{row.getValue('numberOfDevices')}</div>
    )
  },
  {
    accessorKey: 'createdAt',
    header: 'Date Created',
    cell: ({ row }) => (
      <div className="capitalize">{formatDate(row.getValue('createdAt'))}</div>
    )
  },
  {
    id: 'actions',
    enableHiding: false,
    cell: ({ row }) => {
      return (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="h-8 w-8 p-0">
              <span className="sr-only">Open menu</span>
              <EllipsisVertical className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="cursor-pointer">
            <DropdownMenuItem
              onClick={(e) => {
                e.stopPropagation();
                // console.log(row.original.id);
              }}
            >
              <DeleteSubject
                subjectId={row.original.subjectId}
                cohortId={row.original.cohortId}
              />
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      );
    }
  }
];
