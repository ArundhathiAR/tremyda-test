type Permissions = {
  [key: string]: any;
};

type UserPermissions = {
  [key: string]: Permissions;
};

export const appName = 'Tremyda';

export const APP_ADMIN_ROLES = [
  'AppAdmin',
  'SiteAdmin',
  'SiteViewer',
  'SiteOperator'
];

export const USER_PERMISSIONS: UserPermissions = {
  AppAdmin: {
    createSite: true,
    createCohort: true,
    createSubject: true,
    inviteUser: true,
    inviteRoles: ['AppAdmin', 'SiteAdmin', 'SiteViewer', 'SiteOperator']
  },
  SiteAdmin: {
    createSite: false,
    createCohort: true,
    createSubject: true,
    inviteUser: true,
    inviteRoles: ['SiteViewer', 'SiteOperator']
  },
  SiteViewer: {
    createSite: false,
    createCohort: false,
    createSubject: false,
    inviteUser: false
  },
  SiteOperator: {
    dashboardAccess: false
  }
};

export const bp_data = [
  {
    readingStop: 'October 14, 2024 11:15:00 AM',
    siteId: 'a5326a6c-7711-42b7-9d05-43150765d22f',
    deviceId: 'palmsens',
    subjectId: 'ebacbb5f-33e4-4e00-a341-56a4e3fbd466',
    cohortId: 'c445106e-862d-4ab7-a341-b97e19e95bda',
    eventType: 'bp',
    readingStart: 'October 14, 2024 11:00:00 AM'
  },
  {
    readingStop: 'October 15, 2024 10:45:00 AM',
    siteId: 'a5326a6c-7711-42b7-9d05-43150765d22f',
    deviceId: 'palmsens',
    subjectId: 'ebacbb5f-33e4-4e00-a341-56a4e3fbd466',
    cohortId: 'c445106e-862d-4ab7-a341-b97e19e95bda',
    eventType: 'bp',
    readingStart: 'October 15, 2024 10:30:00 AM'
  },
  {
    readingStop: 'October 16, 2024 10:15:00 AM',
    siteId: 'a5326a6c-7711-42b7-9d05-43150765d22f',
    deviceId: 'palmsens',
    subjectId: 'ebacbb5f-33e4-4e00-a341-56a4e3fbd466',
    cohortId: 'c445106e-862d-4ab7-a341-b97e19e95bda',
    eventType: 'bp',
    readingStart: 'October 16, 2024 10:00:00 AM'
  },
  {
    readingStop: 'October 17, 2024 11:15:00 AM',
    siteId: 'a5326a6c-7711-42b7-9d05-43150765d22f',
    deviceId: 'palmsens',
    subjectId: 'ebacbb5f-33e4-4e00-a341-56a4e3fbd466',
    cohortId: 'c445106e-862d-4ab7-a341-b97e19e95bda',
    eventType: 'bp',
    readingStart: 'October 17, 2024 11:00:00 AM'
  },
  {
    readingStop: 'October 18, 2024 12:45:00 PM',
    siteId: 'a5326a6c-7711-42b7-9d05-43150765d22f',
    deviceId: 'palmsens',
    subjectId: 'ebacbb5f-33e4-4e00-a341-56a4e3fbd466',
    cohortId: 'c445106e-862d-4ab7-a341-b97e19e95bda',
    eventType: 'bp',
    readingStart: 'October 18, 2024 12:30:00 PM'
  }
];
