export const app = {
  name: 'Tremyda',
  description: 'Tremyda',
  icon: '/logo/tremyda/tremyda-1.png',
  // icon: '/logo/tremyda/tremyda-2.png',
  // icon: '/logo/tremyda/tremyda-3.png',
  iconWidth: 120,
  iconHeight: 80
};
