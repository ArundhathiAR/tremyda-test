import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, QueryCommand } from "@aws-sdk/lib-dynamodb";
import { SSMClient, GetParameterCommand } from "@aws-sdk/client-ssm";
const ssmClient = new SSMClient();
const ddb = DynamoDBDocumentClient.from(new DynamoDBClient({}));

export const handler = async (event) => {
  var dynamodbTableName = await ssmClient.send(
    new GetParameterCommand({
      Name: process.env.dynamodbTableName,
    })
  );
  dynamodbTableName = dynamodbTableName.Parameter.Value;

  const params = {
    TableName: dynamodbTableName,
    KeyConditionExpression: "pk = :pk",
    ExpressionAttributeValues: {
      ":pk": "updates",
    },
    Limit: 50,
    ScanIndexForward: false,
  };

  try {
    const data = await ddb.send(new QueryCommand(params));
    const results = data.Items.map((item) => {
      const { pk, sk, ...filteredItem } = item;
      return filteredItem;
    });
    return {
      statusCode: 200,
      body: JSON.stringify({
        items: results,
        count: data.Count,
      }),
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
    };
  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: "Internal Server Error",
        details: err.message,
      }),
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
    };
  }
};
