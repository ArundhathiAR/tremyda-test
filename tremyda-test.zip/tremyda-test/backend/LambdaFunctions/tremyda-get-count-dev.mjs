import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, QueryCommand } from "@aws-sdk/lib-dynamodb";
import { SSMClient, GetParameterCommand } from "@aws-sdk/client-ssm";
const ssmClient = new SSMClient();
const ddb = DynamoDBDocumentClient.from(new DynamoDBClient({}));

export const handler = async (event, context) => {
  var dynamodbTableName = await ssmClient.send(
    new GetParameterCommand({
      Name: process.env.dynamodbTableName,
    })
  );
  dynamodbTableName = dynamodbTableName.Parameter.Value;
  const currentDateString = new Date().toISOString().split("T")[0];
  const date7DaysAgo = new Date();
  date7DaysAgo.setDate(date7DaysAgo.getDate() - 7);
  const date7DaysAgoString = date7DaysAgo.toISOString().split("T")[0];

  try {
    let params = {
      TableName: dynamodbTableName,
      KeyConditionExpression: "pk = :pk and begins_with(sk, :sk)",
      ExpressionAttributeValues: {
        ":pk": "counter",
        ":sk": "count",
      },
    };

    const data = await ddb.send(new QueryCommand(params));
    const results = data.Items.map((item) => {
      const { pk, sk, ...filteredItem } = item;
      return filteredItem;
    });

    params = {
      TableName: dynamodbTableName,
      KeyConditionExpression: "pk = :pk and sk BETWEEN :skStart AND :skEnd",
      ExpressionAttributeValues: {
        ":pk": "counter",
        ":skStart": `event#createdDate#${date7DaysAgoString}`,
        ":skEnd": `event#createdDate#${currentDateString}`,
      },
    };

    const eventsCounter = await ddb.send(new QueryCommand(params));
    const events = eventsCounter.Items.map((item) => {
      const { pk, sk, ...filteredItem } = item;
      return filteredItem;
    });

    return {
      statusCode: 200,
      body: JSON.stringify({
        items: results,
        events: events,
      }),
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
    };
  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: "Internal Server Error",
        details: err.message,
      }),
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
    };
  }
};
