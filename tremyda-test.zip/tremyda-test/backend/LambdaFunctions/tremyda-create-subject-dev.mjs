import {
  DynamoDBDocumentClient,
  TransactWriteCommand,
  QueryCommand,
} from "@aws-sdk/lib-dynamodb";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { v4 as uuidv4 } from "uuid";
import { SSMClient, GetParameterCommand } from "@aws-sdk/client-ssm";
import { faker } from "@faker-js/faker";
const ddb = DynamoDBDocumentClient.from(new DynamoDBClient());
const ssmClient = new SSMClient();

export const handler = async (event) => {
  const cohortid = event.pathParameters.cohortid;
  if (
    cohortid === ":cohortid" ||
    cohortid === "%20" ||
    cohortid === ":%7Bcohortid%7D"
  ) {
    return {
      statusCode: 400,
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({ error: "Missing parameters" }),
    };
  }

  var dynamodbTableName = await ssmClient.send(
    new GetParameterCommand({
      Name: process.env.dynamodbTableName,
    })
  );
  dynamodbTableName = dynamodbTableName.Parameter.Value;

  const date = new Date().toISOString();
  const uuid = uuidv4();
  var requestBody = JSON.parse(event.body);

  try {
    const params = {
      TableName: dynamodbTableName,
      KeyConditionExpression: "pk = :pkVal and sk = :skVal",
      ExpressionAttributeValues: {
        ":pkVal": "cohorts",
        ":skVal": "cohort#" + cohortid,
      },
    };
    var cohortData = await ddb.send(new QueryCommand(params));
  } catch (err) {
    console.log(err);
  }
  // const subjectName = `${faker.person.firstName()} ${faker.person.lastName()}`;
  const subjectName = faker.internet.userName();

  try {
    const params = {
      TransactItems: [
        {
          Put: {
            TableName: dynamodbTableName,
            Item: {
              pk: "subjects",
              sk: "subject#" + uuid,
              createdAt: date,
              createdBy: requestBody.createdBy,
              updatedAt: date,
              updatedBy: requestBody.createdBy,
              subjectDescription: requestBody.subjectDescription,
              subjectStatus: "active",
              subjectId: uuid,
              cohortId: cohortid,
              subjectName: subjectName,
              numberOfDevices: 0,
            },
          },
        },
        {
          Put: {
            TableName: dynamodbTableName,
            Item: {
              pk: "cohorts",
              sk: "subject-cohort#cohort#" + cohortid + "#subject#" + uuid,
              createdAt: date,
              createdBy: requestBody.createdBy,
              updatedAt: date,
              updatedBy: requestBody.createdBy,
              subjectDescription: requestBody.subjectDescription,
              subjectStatus: "active",
              subjectName: subjectName,
              subjectId: uuid,
              cohortId: cohortid,
              numberOfDevices: 0,
            },
          },
        },
        {
          Update: {
            TableName: dynamodbTableName,
            Key: {
              pk: "sites",
              sk: "site#" + cohortData.Items[0].siteId,
            },
            UpdateExpression:
              "SET numberOfSubjects = if_not_exists(numberOfSubjects, :start) + :inc",
            ExpressionAttributeValues: {
              ":inc": 1,
              ":start": 0,
            },
          },
        },
        {
          Update: {
            TableName: dynamodbTableName,
            Key: {
              pk: "cohorts",
              sk: "cohort#" + cohortid,
            },
            UpdateExpression:
              "SET numberOfSubjects = if_not_exists(numberOfSubjects, :start) + :inc",
            ExpressionAttributeValues: {
              ":inc": 1,
              ":start": 0,
            },
          },
        },
        {
          Update: {
            TableName: dynamodbTableName,
            Key: {
              pk: "sites",
              sk:
                "cohort-site#site#" +
                cohortData.Items[0].siteId +
                "#cohort#" +
                cohortid,
            },
            UpdateExpression:
              "SET numberOfSubjects = if_not_exists(numberOfSubjects, :start) + :inc",
            ExpressionAttributeValues: {
              ":inc": 1,
              ":start": 0,
            },
          },
        },
        {
          Update: {
            TableName: dynamodbTableName,
            Key: {
              pk: "counter",
              sk: "count",
            },
            UpdateExpression:
              "SET numberOfSubjects = if_not_exists(numberOfSubjects, :start) + :inc",
            ExpressionAttributeValues: {
              ":inc": 1,
              ":start": 0,
            },
          },
        },
        {
          Put: {
            TableName: dynamodbTableName,
            Item: {
              pk: "updates",
              sk: date,
              subjectId: uuid,
              cohortId: cohortid,
              cohortName: cohortData.Items[0].cohortName,
              name: "subjectName",
              type: "subject",
              action: "create",
              createdAt: date,
            },
          },
        },
      ],
    };

    await ddb.send(new TransactWriteCommand(params));

    return {
      statusCode: 200,
      body: JSON.stringify({
        "Subject Created": uuid,
      }),
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
    };
  } catch (err) {
    console.log(err);
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: "Internal Server Error",
        details: err.message,
      }),
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
    };
  }
};
