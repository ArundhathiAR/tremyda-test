import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import {
  DynamoDBDocumentClient,
  TransactWriteCommand,
  QueryCommand,
} from "@aws-sdk/lib-dynamodb";
import { v4 as uuidv4 } from "uuid";
import { SSMClient, GetParameterCommand } from "@aws-sdk/client-ssm";
const ddbDocClient = DynamoDBDocumentClient.from(new DynamoDBClient());
const ssmClient = new SSMClient();

export const handler = async (event) => {
  const siteid = event.pathParameters.siteid;
  if (siteid === ":siteid" || siteid === "%20" || siteid === ":%7Bsiteid%7D") {
    return {
      statusCode: 400,
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({ error: "Missing parameters" }),
    };
  }

  const date = new Date().toISOString();
  const uuid = uuidv4();
  let dynamodbTableName = await ssmClient.send(
    new GetParameterCommand({
      Name: process.env.dynamodbTableName,
    })
  );
  dynamodbTableName = dynamodbTableName.Parameter.Value;

  try {
    const siteParams = {
      TableName: dynamodbTableName,
      KeyConditionExpression: "pk = :pkVal and sk = :skVal",
      ExpressionAttributeValues: {
        ":pkVal": "sites",
        ":skVal": `site#${siteid}`,
      },
    };
    const siteData = await ddbDocClient.send(new QueryCommand(siteParams));

    if (siteData.Items.Count == 0) {
      return {
        statusCode: 400,
        headers: {
          "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify({ error: "Invalid Site Id" }),
      };
    }

    const siteName = siteData.Items[0].siteName;

    const requestBody = JSON.parse(event.body);
    const params = {
      TransactItems: [
        {
          Put: {
            TableName: dynamodbTableName,
            Item: {
              pk: "cohorts",
              sk: "cohort#" + uuid,
              cohortName: requestBody.cohortName,
              createdAt: date,
              createdBy: requestBody.createdBy,
              updatedAt: date,
              updatedBy: requestBody.createdBy,
              cohortDescription: requestBody.cohortDescription,
              cohortStatus: "active",
              cohortId: uuid,
              numberOfSubjects: 0,
              siteId: siteid,
              siteName: siteName,
            },
          },
        },
        {
          Put: {
            TableName: dynamodbTableName,
            Item: {
              pk: "sites",
              sk: "cohort-site#site#" + siteid + "#cohort#" + uuid,
              cohortName: requestBody.cohortName,
              createdAt: date,
              createdBy: requestBody.createdBy,
              updatedAt: date,
              updatedBy: requestBody.createdBy,
              cohortDescription: requestBody.cohortDescription,
              cohortStatus: "active",
              cohortId: uuid,
              numberOfSubjects: 0,
              siteId: siteid,
              siteName: siteName,
            },
          },
        },
        {
          Update: {
            TableName: dynamodbTableName,
            Key: {
              pk: "sites",
              sk: "site#" + siteid,
            },
            UpdateExpression:
              "SET numberOfCohorts = if_not_exists(numberOfCohorts, :start) + :inc",
            ExpressionAttributeValues: {
              ":inc": 1,
              ":start": 0,
            },
          },
        },
        {
          Update: {
            TableName: dynamodbTableName,
            Key: {
              pk: "counter",
              sk: "count",
            },
            UpdateExpression:
              "SET numberOfCohorts = if_not_exists(numberOfCohorts, :start) + :inc",
            ExpressionAttributeValues: {
              ":inc": 1,
              ":start": 0,
            },
          },
        },
        {
          Put: {
            TableName: dynamodbTableName,
            Item: {
              pk: "updates",
              sk: date,
              cohortId: uuid,
              siteId: siteid,
              siteName: siteName,
              name: requestBody.cohortName,
              type: "cohort",
              action: "create",
              createdAt: date,
            },
          },
        },
      ],
    };

    await ddbDocClient.send(new TransactWriteCommand(params));

    return {
      statusCode: 200,
      body: JSON.stringify({ "Cohort Created": uuid }),
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
    };
  } catch (err) {
    console.log(err);
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: "Internal Server Error",
        details: err.message,
      }),
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
    };
  }
};
