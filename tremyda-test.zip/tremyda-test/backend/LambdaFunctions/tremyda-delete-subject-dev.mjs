import { DynamoDBDocumentClient, TransactWriteCommand, QueryCommand } from "@aws-sdk/lib-dynamodb";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { SSMClient, GetParametersCommand } from '@aws-sdk/client-ssm';
const ddbDocClient = DynamoDBDocumentClient.from(new DynamoDBClient());
const ssmClient = new SSMClient();

export const handler = async (event) => {
    let cohortid, subjectid;
    
    try{
        
        if (event.pathParameters) {  
            cohortid = event.pathParameters.cohortid;
            subjectid = event.pathParameters.subjectid;
            if (cohortid === ":cohortid" || cohortid === "%20" || cohortid === ":%7Bcohortid%7D" || subjectid === ":subjectid" || subjectid === "%20" || subjectid === ":%7Bsubjectid%7D") {
                return {
                    statusCode: 400,
                    headers: {
                        'Access-Control-Allow-Origin': '*'
                    },
                    body: JSON.stringify({ error: "Missing parameters" }),
                };
            }
        }
        else if(event.Records && event.Records[0].eventSource === "aws:sqs"){
            const messageBody = JSON.parse(event.Records[0].body);
            cohortid = messageBody.cohortid;
            subjectid = messageBody.subjectid;
        }
        else {
            return {
                statusCode: 400,
                headers: {
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({ error: "Invalid event format" }),
            };
        }
        
        const parameterNames = [
          process.env.dynamodbTableName
          ];
          
        let parameters = {};
        
        try {
            
            const ssmParams = await ssmClient.send(new GetParametersCommand({ Names: parameterNames }));
            ssmParams.Parameters.forEach(param => parameters[param.Name] = param.Value);
        } catch (err) {
            return {
                statusCode: 500,
                body: JSON.stringify({ message: 'Failed to fetch parameters from SSM', details: err.message }),
                headers: { 'Access-Control-Allow-Origin': '*' }
            };
        }

    
        const dynamodbTableName = parameters[process.env.dynamodbTableName];
    
        const getParams = {
            TableName: dynamodbTableName,
            KeyConditionExpression: 'pk = :pk and sk = :sk',
            ExpressionAttributeValues: {
                ':pk': `subjects`,
                ':sk': `subject#${subjectid}`
            },
        };
        const data = await ddbDocClient.send(new QueryCommand(getParams));
    
        if (data.Items[0].subjectStatus === "inactive") {
            return {
                statusCode: 200,
                body: JSON.stringify({
                    msg: "Already deleted"
                }),
                headers: {
                    'Access-Control-Allow-Origin': '*',
                }
            };
        }
        
        try {
            const params = {
                TableName: dynamodbTableName,
                KeyConditionExpression: "pk = :pkVal",
                ExpressionAttributeValues: {
                    ":pkVal": "sites",
                    ":cohortId": cohortid
                },
                FilterExpression: "cohortId = :cohortId",
            };
            var siteIdData = await ddbDocClient.send(new QueryCommand(params));
        } catch (err) {
            return {
                statusCode: 500,
                body: JSON.stringify({ error: "Something Went Wrong", details: err.message }),
                headers: {
                    'Access-Control-Allow-Origin': '*',
                }
            };
        }
    
        const transactWriteParams = {
            TransactItems: [
                {
                    Update: {
                        TableName: dynamodbTableName,
                        Key: {
                            pk: "subjects",
                            sk: "subject#" + subjectid
                        },
                        UpdateExpression: "SET subjectStatus = :subjectStatus, numberOfSubjects = if_not_exists(numberOfSubjects, :start) - :dec",
                        ConditionExpression: "numberOfSubjects >= :dec OR attribute_not_exists(numberOfSubjects)",
                        ExpressionAttributeValues: {
                            ':subjectStatus': "inactive",
                            ':dec': 1,
                            ':start': 0
                        },
                    }
                },
                {
                    Update: {
                        TableName: dynamodbTableName,
                        Key: {
                            pk: "cohorts",
                            sk: "cohort#" + cohortid
                        },
                        UpdateExpression: "SET numberOfSubjects = if_not_exists(numberOfSubjects, :start) - :dec",
                        ConditionExpression: "numberOfSubjects >= :dec OR attribute_not_exists(numberOfSubjects)",
                        ExpressionAttributeValues: {
                            ':dec': 1,
                            ':start': 0
                        },
                    }
                },
                {
                    Update: {
                        TableName: dynamodbTableName,
                        Key: {
                            pk: "cohorts",
                            sk: "subject-cohort#cohort#" + cohortid + "#subject#" + subjectid
                        },
                        UpdateExpression: "SET subjectStatus = :subjectStatus",
                        ExpressionAttributeValues: {
                            ':subjectStatus': "inactive",
                        },
                    }
                },
                {
                    Update: {
                        TableName: dynamodbTableName,
                        Key: {
                            pk: "counter",
                            sk: "count"
                        },
                        UpdateExpression: "SET numberOfSubjects = if_not_exists(numberOfSubjects, :start) - :dec",
                        ConditionExpression: "numberOfSubjects >= :dec OR attribute_not_exists(numberOfSubjects)",
                        ExpressionAttributeValues: {
                            ':dec': 1,
                            ':start': 0
                        },
                    }
                },
                {
                    Update: {
                        TableName: dynamodbTableName,
                        Key: {
                            pk: "sites",
                            sk: "site#" + siteIdData.Items[0].siteId
                        },
                        UpdateExpression: "SET numberOfSubjects = if_not_exists(numberOfSubjects, :start) - :dec",
                        ConditionExpression: "numberOfSubjects >= :dec OR attribute_not_exists(numberOfSubjects)",
                        ExpressionAttributeValues: {
                            ':dec': 1,
                            ':start': 0
                        },
                    }
                },
                {
                    Update: {
                        TableName: dynamodbTableName,
                        Key: {
                            pk: "sites",
                            sk: "cohort-site#site#" + siteIdData.Items[0].siteId + "#cohort#" + cohortid
                        },
                        UpdateExpression: "SET numberOfSubjects = if_not_exists(numberOfSubjects, :start) - :dec",
                        ConditionExpression: "numberOfSubjects >= :dec OR attribute_not_exists(numberOfSubjects)",
                        ExpressionAttributeValues: {
                            ':dec': 1,
                            ':start': 0
                        },
                    }
                }
            ]
        };
    
       
        await ddbDocClient.send(new TransactWriteCommand(transactWriteParams));
        
        
        return {
            statusCode: 200,
            body: JSON.stringify({
                msg: "deleted"
            }),
            headers: {
                'Access-Control-Allow-Origin': '*',
            }
        };
    } catch (err) {
        let errorMsg = "Internal Server Error";
        if (err.name === 'ConditionalCheckFailedException') {
            errorMsg = "Cannot decrement to a negative number";
        }
        return {
            statusCode: 500,
            body: JSON.stringify({ error: errorMsg, details: err.message }),
            headers: {
                'Access-Control-Allow-Origin': '*',
            }
        };
    }
};