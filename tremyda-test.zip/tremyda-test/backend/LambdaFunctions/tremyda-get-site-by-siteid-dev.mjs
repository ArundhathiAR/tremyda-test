import { DynamoDBDocumentClient, QueryCommand } from "@aws-sdk/lib-dynamodb";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { SSMClient, GetParameterCommand } from '@aws-sdk/client-ssm';
const ddbDocClient = DynamoDBDocumentClient.from(new DynamoDBClient());
const ssmClient = new SSMClient();

export const handler = async (event) => {
    const siteid = event.pathParameters.siteid;
    if (siteid === ":siteid" || siteid === "%20" || siteid === ":%7Bsiteid%7D") {
        return {
            statusCode: 400,
            headers: {
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({ error: "Missing parameters" }),
        };
    }

    var dynamodbTableName = await ssmClient.send(new GetParameterCommand({
        Name: process.env.dynamodbTableName
    }));
    dynamodbTableName = dynamodbTableName.Parameter.Value;

    const params = {
        TableName: dynamodbTableName,
        KeyConditionExpression: "pk = :pkVal and sk = :skVal",
        ExpressionAttributeValues: {
            ":pkVal": "sites",
            ":skVal": `site#${siteid}`
        }
    };

    try {
        const data = await ddbDocClient.send(new QueryCommand(params));

        const results = data.Items.map(item => {
            const { pk, sk, ...filteredItem } = item;
            return filteredItem;
        });

        return {
            statusCode: 200,
            body: JSON.stringify({
                items: results
            }),
            headers: {
                'Access-Control-Allow-Origin': '*',
            }
        };
    } catch (err) {
        return {
            statusCode: 500,
            body: JSON.stringify({ error: "Internal Server Error", details: err.message }),
            headers: {
                'Access-Control-Allow-Origin': '*',
            }
        };
    }
};