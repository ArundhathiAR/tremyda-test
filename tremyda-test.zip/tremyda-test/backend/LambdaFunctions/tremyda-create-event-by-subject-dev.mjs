import { DynamoDBDocumentClient, PutCommand } from "@aws-sdk/lib-dynamodb";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { v4 as uuidv4 } from 'uuid';
import { SSMClient, GetParameterCommand } from '@aws-sdk/client-ssm';
const ddbDocClient = DynamoDBDocumentClient.from(new DynamoDBClient());
const ssmClient = new SSMClient();

export const handler = async (event) => {
    const subjectid = event.pathParameters.subjectid;
    if (subjectid === ":subjectid" || subjectid === "%20" || subjectid === ":%7Bsubjectid%7D" ) {
        return {
            statusCode: 400,
            headers: {
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({ error: "Missing parameters" }),
        };
    }
    var dynamodbTableName = await ssmClient.send(new GetParameterCommand({
        Name: process.env.dynamodbTableName
    }));
    dynamodbTableName = dynamodbTableName.Parameter.Value;

    const uuid = uuidv4();

    try {
        const requestBody = JSON.parse(event.body);
        const sk = `event-subject#subject#${subjectid}#event#${uuid}`;
        const params = {
            TableName: dynamodbTableName,
            Item: {
                pk: "events",
                sk: sk,
                subjectId: subjectid,
                eventType: requestBody.eventType,
                eventId: uuid,
                eventDescription: requestBody.eventDescription? requestBody.eventDescription : undefined,
                createdAt: new Date().toISOString()
            },
        };
        await ddbDocClient.send(new PutCommand(params));

        return {
            statusCode: 200,
            headers: {
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                "Event Created": uuid
            }),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: 500,
            headers: {
                'Access-Control-Allow-Origin': '*',
            },
            body: JSON.stringify({ error: "Internal Server Error", details: err.message }),
        };
    }
};