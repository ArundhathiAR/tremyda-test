import { DynamoDBDocumentClient, UpdateCommand } from "@aws-sdk/lib-dynamodb";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { SSMClient, GetParameterCommand } from '@aws-sdk/client-ssm';
const ddbDocClient = DynamoDBDocumentClient.from(new DynamoDBClient());
const ssmClient = new SSMClient();

export const handler = async (event) => {
    const subjectid = event.pathParameters.subjectid;
    const deviceid = event.pathParameters.deviceid;
    const eventid = event.pathParameters.eventid;
    if (subjectid === ":subjectid" || subjectid === "%20" || subjectid === ":%7Bsubjectid%7D" || deviceid === ":deviceid" || deviceid === "%20" || deviceid === ":%7Bdeviceid%7D" || eventid === ":eventid" || eventid === "%20" || eventid === ":%7Beventid%7D") {
        return {
            statusCode: 400,
            headers: {
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({ error: "Missing parameters" }),
        };
    }
    var dynamodbTableName = await ssmClient.send(new GetParameterCommand({
        Name: process.env.dynamodbTableName
    }));
    dynamodbTableName = dynamodbTableName.Parameter.Value;

    try {
      const requestBody = JSON.parse(event.body);
        const updateEventParams = {
            TableName: dynamodbTableName,
            Key: {
                pk: "events",
                sk: `event-device-subject#subject#${subjectid}#device#${deviceid}#event#${eventid}`
            },
            UpdateExpression: "SET cohortStop = :cohortStop, readingStop = :readingStop",
            ExpressionAttributeValues: {
                ':cohortStop': requestBody.cohortStop,
                ':readingStop': requestBody.cohortStop
            },
        };
        await ddbDocClient.send(new UpdateCommand(updateEventParams));

        return {
            statusCode: 200,
            headers: {
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                "msg": "Updated"
            }),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: 500,
            headers: {
                'Access-Control-Allow-Origin': '*',
            },
            body: JSON.stringify({ error: "Internal Server Error", details: err.message }),
        };
    }
};