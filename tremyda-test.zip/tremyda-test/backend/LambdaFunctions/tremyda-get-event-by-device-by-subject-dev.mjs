import { DynamoDBDocumentClient, QueryCommand } from "@aws-sdk/lib-dynamodb";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { SSMClient, GetParameterCommand } from '@aws-sdk/client-ssm';
const ddb = DynamoDBDocumentClient.from(new DynamoDBClient());
const ssmClient = new SSMClient();

export const handler = async (event, context) => {
    const subjectid = event.pathParameters.subjectid;
    const deviceid = event.pathParameters.deviceid;
    if (subjectid === ":subjectid" || subjectid === "%20" || subjectid === ":%7Bsubjectid%7D" || deviceid === ":deviceid" || deviceid === "%20" || deviceid === ":%7Bdeviceid%7D") {
        return {
            statusCode: 400,
            headers: {
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({ error: "Missing parameters" }),
        };
    }

    var dynamodbTableName = await ssmClient.send(new GetParameterCommand({
        Name: process.env.dynamodbTableName
    }));
    dynamodbTableName = dynamodbTableName.Parameter.Value;
    
    // const { pageSize = 10, pageToken } = event.queryStringParameters || {};
    // const lastEvaluatedKey = pageToken ? JSON.parse(Buffer.from(pageToken, 'base64').toString('utf-8')) : undefined;

    const params = {
        TableName: dynamodbTableName,
        KeyConditionExpression: 'pk = :pk and begins_with(sk, :sk)',
        ExpressionAttributeValues: {
            ':pk': 'events',
            ':sk': `event-device-subject#subject#${subjectid}#device#${deviceid}#event`
        },
        // Limit: parseInt(pageSize, 10),
        // ExclusiveStartKey: lastEvaluatedKey,
    };

    try {
        const data = await ddb.send(new QueryCommand(params));

        const results = data.Items.map(item => {
            const { pk, sk, ...filteredItem } = item;
            return filteredItem;
        });

        return {
            statusCode: 200,
            body: JSON.stringify({
                items: results,
                count: data.Count,
                // nextPageToken: data.LastEvaluatedKey ? Buffer.from(JSON.stringify(data.LastEvaluatedKey)).toString('base64') : null,
            }),
            headers: {
                'Access-Control-Allow-Origin': '*',
            }
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: "Internal Server Error", details: err.message }),
            headers: {
                'Access-Control-Allow-Origin': '*',
            }
        };
    }
};