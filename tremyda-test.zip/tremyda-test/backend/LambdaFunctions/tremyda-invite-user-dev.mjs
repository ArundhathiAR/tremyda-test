import { 
    CognitoIdentityProviderClient, 
    AdminCreateUserCommand, 
    AdminAddUserToGroupCommand 
  } from '@aws-sdk/client-cognito-identity-provider';
  
  export const handler = async (event) => {
    const client = new CognitoIdentityProviderClient();
    
    const { email, role, siteId } = JSON.parse(event.body);
    
    console.log(email, role, 'in the sky');
    const userPoolId = process.env.COGNITO_USER_POOL_ID;
  
    try {
      
      const createUserParams = {
        UserPoolId: userPoolId,
        Username: email,
        UserAttributes: [
          {
            Name: 'email',
            Value: email,
          },
          {
            Name: "custom:siteId",
            Value: siteId
          },
           {
            Name: "custom:role",
            Value: role
          }
        ],
      };
  
      const userRes = await client.send(new AdminCreateUserCommand(createUserParams));
      console.log(userRes, 'user res');
  
    } catch (error) {
      if (error.name === 'UsernameExistsException') {
        
        console.log(`User ${email} already exists.`);
        return {
              statusCode: 500,
              body: JSON.stringify({ error: "Internal Server Error", message: `User ${email} already exists.` }),
              headers: {
                  'Access-Control-Allow-Origin': '*',
              }
          };
      } else {
        
        console.error('Error creating user:', error);
        return {
              statusCode: 500,
              body: JSON.stringify({ error: "Internal Server Error", message: error.message }),
              headers: {
                  'Access-Control-Allow-Origin': '*',
              }
          };
      }
    }
  
    try {
      
      const addUserToGroupParams = {
        GroupName: role,
        UserPoolId: userPoolId,
        Username: email,
      };
  
      const groupRes = await client.send(new AdminAddUserToGroupCommand(addUserToGroupParams));
      console.log(groupRes, 'group res');
  
      return {
              statusCode: 200,
              body: JSON.stringify({ message: 'User invited successfully.' }),
              headers: {
                  'Access-Control-Allow-Origin': '*',
              }
          };
          
  
    } catch (error) {
      console.error('Error adding user to group:', error);
      return {
        statusCode: 500,
        body: JSON.stringify({ message: 'Error adding user to group', error: error.message }),
        headers: {
                  'Access-Control-Allow-Origin': '*',
              }
      };
    }
  };
  