import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, QueryCommand } from "@aws-sdk/lib-dynamodb";
import { SSMClient, GetParameterCommand } from '@aws-sdk/client-ssm';
const ssmClient = new SSMClient();
const ddb = DynamoDBDocumentClient.from(new DynamoDBClient({}));

export const handler = async (event, context) => {
    let dynamodbTableName = await ssmClient.send(new GetParameterCommand({
        Name: process.env.dynamodbTableName
    }));
    dynamodbTableName = dynamodbTableName.Parameter.Value;

    const deviceid = event.queryStringParameters?.deviceid;
    const { pageSize = 10, pageToken, status = 'active' } = event.queryStringParameters || {};
    const pageSizeInt = parseInt(pageSize, 10);

    let params = {
        TableName: dynamodbTableName,
        KeyConditionExpression: 'pk = :pk ',
        ExpressionAttributeValues: {
            ':pk': `subjects`,
            ':deviceid': deviceid
        },
        FilterExpression: 'deviceId = :deviceid',
    };

    if (!deviceid) {
        params = {
            TableName: dynamodbTableName,
            KeyConditionExpression: 'pk = :pk and begins_with(sk, :sk)',
            ExpressionAttributeValues: {
                ':pk': `subjects`,
                ':sk': `subject#`,
                ':subjectStatus': status
            },
            FilterExpression: "subjectStatus = :subjectStatus"
        };
    }

    try {
        const data = await ddb.send(new QueryCommand(params));

        const allItems = data.Items.map(item => {
            const { pk, ...filteredItem } = item;
            return filteredItem;
        }).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

        const startIndex = pageToken ? parseInt(Buffer.from(pageToken, 'base64').toString('utf-8').slice(8), 10) : 0;
        const paginatedItems = allItems.slice(startIndex, startIndex + pageSizeInt);
        const nextPageToken = startIndex + pageSizeInt < allItems.length 
            ? Buffer.from(`pageidx:${startIndex + pageSizeInt}`).toString('base64') 
            : null;

        return {
            statusCode: 200,
            body: JSON.stringify({
                items: paginatedItems,
                count: paginatedItems.length,
                nextPageToken,
            }),
            headers: {
                'Access-Control-Allow-Origin': '*',
            }
        };
    } catch (err) {
        return {
            statusCode: 500,
            body: JSON.stringify({ error: "Internal Server Error", details: err.message }),
            headers: {
                'Access-Control-Allow-Origin': '*',
            }
        };
    }
};