import { 
    CognitoIdentityProviderClient, 
    ListUsersCommand 
  } from '@aws-sdk/client-cognito-identity-provider';
  
  export const handler = async (event) => {
    const client = new CognitoIdentityProviderClient();
    
    // const { siteId } = event.queryStringParameters;
    const userPoolId = process.env.COGNITO_USER_POOL_ID;
  
    try {
      
      // const filter = `custom:siteId = "${siteId}"`;
  
      const listUsersParams = {
        UserPoolId: userPoolId,
        // Filter: filter,
        Limit: 60 
      };
  
      const { Users } = await client.send(new ListUsersCommand(listUsersParams));
  
      
      const formattedUsers = Users.map(({ Attributes, UserStatus, UserCreateDate, Username, Enabled }) => {
        const attributeMap = Object.fromEntries(Attributes.map(({ Name, Value }) => [Name, Value]));
  
        return {
          email: attributeMap.email,
          userStatus: UserStatus,
          userCreatedDate: UserCreateDate,
          emailVerified: attributeMap.email_verified || 'false',
          role: attributeMap['custom:role'] || '',
          siteId: attributeMap['custom:siteId'],
          username: Username,
          name: attributeMap.name,
          enabled: Enabled
        };
      });
      
      return {
            items:formattedUsers
      }  
      
  
      // return {
      //         statusCode: 200,
      //         body: JSON.stringify({
      //           items:formattedUsers
      //         }),
      //         headers: {
      //             'Access-Control-Allow-Origin': '*',
      //         }
      //     };
  
    } catch (error) {
      console.error('Error listing users:', error);
      return {
              statusCode: 500,
              body: JSON.stringify({ error: "Internal Server Error", details: error.message }),
              headers: {
                  'Access-Control-Allow-Origin': '*',
              }
          };
    }
  };
  