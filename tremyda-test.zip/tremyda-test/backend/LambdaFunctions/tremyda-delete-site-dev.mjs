import { DynamoDBDocumentClient, TransactWriteCommand, QueryCommand } from "@aws-sdk/lib-dynamodb";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { SSMClient, GetParametersCommand } from '@aws-sdk/client-ssm';
import { SQSClient, SendMessageBatchCommand } from "@aws-sdk/client-sqs";
const ddbDocClient = DynamoDBDocumentClient.from(new DynamoDBClient());
const ssmClient = new SSMClient();
const sqsClient = new SQSClient();

export const handler = async (event) => {
    const siteid = event.pathParameters.siteid;
    if (siteid === ":siteid" || siteid === "%20" || siteid === ":%7Bsiteid%7D") {
        return {
            statusCode: 400,
            headers: {
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({ error: "Missing parameters" }),
        };
    }
    
    const parameterNames = [
      process.env.dynamodbTableName,
      process.env.sqsDeleteCohortUrl,
      ];
      
    let parameters = {};
    
    try {
        
        const ssmParams = await ssmClient.send(new GetParametersCommand({ Names: parameterNames }));
        ssmParams.Parameters.forEach(param => parameters[param.Name] = param.Value);
    } catch (err) {
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Failed to fetch parameters from SSM', details: err.message }),
            headers: { 'Access-Control-Allow-Origin': '*' }
        };
    }

    try {
        const dynamodbTableName = parameters[process.env.dynamodbTableName];
    
        const getParams = {
            TableName: dynamodbTableName,
            KeyConditionExpression: 'pk = :pk and sk = :sk',
            ExpressionAttributeValues: {
                ':pk': `sites`,
                ':sk': `site#${siteid}`
            },
        };
        const data = await ddbDocClient.send(new QueryCommand(getParams));
    
        if (data.Items[0].siteStatus === "inactive") {
            return {
                statusCode: 200,
                body: JSON.stringify({
                    msg: "Already deleted"
                }),
                headers: {
                    'Access-Control-Allow-Origin': '*',
                }
            };
        }
    
        const updateSiteParams = {
            Update: {
                TableName: dynamodbTableName,
                Key: {
                    pk: "sites",
                    sk: "site#" + siteid
                },
                UpdateExpression: "SET siteStatus = :siteStatus",
                ExpressionAttributeValues: {
                    ':siteStatus': "inactive",
                },
            }
        };
    
        const updateCountParams = {
            Update: {
                TableName: dynamodbTableName,
                Key: {
                    pk: "counter",
                    sk: "count"
                },
                UpdateExpression: "SET numberOfSites = if_not_exists(numberOfSites, :start) - :dec",
                ConditionExpression: "numberOfSites >= :dec OR attribute_not_exists(numberOfSites)",
                ExpressionAttributeValues: {
                    ':dec': 1,
                    ':start': 0
                },
            }
        };
    
        const transactWriteParams = {
            TransactItems: [updateSiteParams, updateCountParams]
        };

    
        await ddbDocClient.send(new TransactWriteCommand(transactWriteParams));
        

        try {
            const getSiteCohortParams = {
                TableName: dynamodbTableName,
                KeyConditionExpression: 'pk = :pk and begins_with(sk, :sk)',
                ExpressionAttributeValues: {
                    ':pk': `sites`,
                    ':sk': `cohort-site#site#${siteid}`
                },
            };
        
            // Query the DynamoDB table to get the cohorts
            const cohorts = await ddbDocClient.send(new QueryCommand(getSiteCohortParams));
            
            if(cohorts?.Items.length > 0){
                const dataArray = cohorts.Items.map(item => ({
                    cohortid: item.cohortId,
                    siteid: siteid
                }));
                
                // Send the data to SQS
                await sendMessagesToSQS(dataArray, parameters[process.env.sqsDeleteCohortUrl]);
            }
        } catch (err) {
            return {
                statusCode: 500,
                body: JSON.stringify({ error: "Error while deleting site cohorts", details: err.message }),
                headers: {
                    'Access-Control-Allow-Origin': '*',
                }
            };
        }
        
        return {
            statusCode: 200,
            body: JSON.stringify({
                msg: "deleted"
            }),
            headers: {
                'Access-Control-Allow-Origin': '*',
            }
        };
    } catch (err) {
        let errorMsg = "Internal Server Error";
        if (err.name === 'ConditionalCheckFailedException') {
            errorMsg = "Cannot decrement to a negative number";
        }
        return {
            statusCode: 500,
            body: JSON.stringify({ error: errorMsg, details: err.message }),
            headers: {
                'Access-Control-Allow-Origin': '*',
            }
        };
    }
};

// Utility function to split array into batches
const batchArray = (array, batchSize) => {
    const results = [];
    for (let i = 0; i < array.length; i += batchSize) {
        results.push(array.slice(i, i + batchSize));
    }
    return results;
};

// Function to send messages to SQS in batches
const sendMessagesToSQS = async (dataArray, queueUrl) => {
    const batches = batchArray(dataArray, 10);
    
    for (const batch of batches) {
        const entries = batch.map((item, index) => ({
            Id: `${index}`, // Unique identifier for each message in the batch
            MessageBody: JSON.stringify({
                cohortid: item.cohortid,
                siteid: item.siteid
            }),
        }));

        const params = {
            QueueUrl: queueUrl,
            Entries: entries,
        };

        try {
            const result = await sqsClient.send(new SendMessageBatchCommand(params));
            console.log(`Batch sent successfully:`, result);
        } catch (error) {
            console.error("Error sending batch to SQS:", error);
        }
    }
};