import { DynamoDBDocumentClient, TransactWriteCommand } from "@aws-sdk/lib-dynamodb";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { SSMClient, GetParameterCommand } from '@aws-sdk/client-ssm';
const ddbDocClient = DynamoDBDocumentClient.from(new DynamoDBClient());
const ssmClient = new SSMClient();

export const handler = async (event) => {
    const requestBody = JSON.parse(event.body);
    const siteid = event.pathParameters.siteid;
    const cohortid = event.pathParameters.cohortid;
    if (siteid === ":siteid" || siteid === "%20" || siteid === ":%7Bsiteid%7D" || cohortid === ":cohortid" || cohortid === "%20" || cohortid === ":%7Bcohortid%7D") {
        return {
            statusCode: 400,
            headers: {
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({ error: "Missing parameters" }),
        };
    }
    var dynamodbTableName = await ssmClient.send(new GetParameterCommand({
        Name: process.env.dynamodbTableName
    }));
    dynamodbTableName = dynamodbTableName.Parameter.Value;

    const action = event.queryStringParameters.action;
    const date = new Date().toISOString();

    try {
        const transactParams = {
            TransactItems: [
                {
                    Update: {
                        TableName: dynamodbTableName,
                        Key: {
                            pk: "cohorts",
                            sk: "cohort#" + cohortid
                        },
                        UpdateExpression: "SET cohortStatus = :cohortStatus, updatedBy = :updatedBy, updatedAt = :updatedAt",
                        ExpressionAttributeValues: {
                            ':cohortStatus': action,
                            ':updatedBy': requestBody.updatedBy ? requestBody.updatedBy : "admin",
                            ':updatedAt': date
                        },
                    }
                },
                {
                    Update: {
                        TableName: dynamodbTableName,
                        Key: {
                            pk: "sites",
                            sk: "cohort-site#site#" + siteid + "#cohort#" + cohortid
                        },
                        UpdateExpression: "SET cohortStatus = :cohortStatus, updatedBy = :updatedBy, updatedAt = :updatedAt",
                        ExpressionAttributeValues: {
                            ':cohortStatus': action,
                            ':updatedBy': requestBody.updatedBy ? requestBody.updatedBy : "admin",
                            ':updatedAt': date
                        },
                    }
                }
            ]
        };

        await ddbDocClient.send(new TransactWriteCommand(transactParams));

        return {
            statusCode: 200,
            headers: {
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                "msg": 'Updated'
            }),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: 500,
            headers: {
                'Access-Control-Allow-Origin': '*',
            },
            body: JSON.stringify({ error: "Internal Server Error", details: err.message }),
        };
    }
};