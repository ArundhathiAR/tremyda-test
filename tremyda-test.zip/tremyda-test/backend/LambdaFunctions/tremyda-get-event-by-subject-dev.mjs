import { DynamoDBDocumentClient, QueryCommand } from "@aws-sdk/lib-dynamodb";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { SSMClient, GetParameterCommand } from '@aws-sdk/client-ssm';
const ddb = DynamoDBDocumentClient.from(new DynamoDBClient());
const ssmClient = new SSMClient();

export const handler = async (event, context) => {
    const subjectid = event.pathParameters.subjectid;
    if (subjectid === ":subjectid" || subjectid === "%20" || subjectid === ":%7Bsubjectid%7D" ) {
        return {
            statusCode: 400,
            headers: {
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({ error: "Missing parameters" }),
        };
    }

    var dynamodbTableName = await ssmClient.send(new GetParameterCommand({
        Name: process.env.dynamodbTableName
    }));
    dynamodbTableName = dynamodbTableName.Parameter.Value;

    const params = {
        TableName: dynamodbTableName,
        KeyConditionExpression: 'pk = :pk and begins_with(sk, :sk)',
        ExpressionAttributeValues: {
            ':pk': 'events',
            ':sk': `event-subject#subject#${subjectid}#event`
        },
    };

    try {
        const data = await ddb.send(new QueryCommand(params));

        const results = data.Items.map(item => {
            const { pk, sk, ...filteredItem } = item;
            return filteredItem;
        });

        return {
            statusCode: 200,
            body: JSON.stringify({
                items: results,
                count: data.Count,
            }),
            headers: {
                'Access-Control-Allow-Origin': '*',
            }
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: "Internal Server Error", details: err.message }),
            headers: {
                'Access-Control-Allow-Origin': '*',
            }
        };
    }
};