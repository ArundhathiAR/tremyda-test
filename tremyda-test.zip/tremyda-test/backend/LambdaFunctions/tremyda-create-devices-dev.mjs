import { DynamoDBDocumentClient, TransactWriteCommand, QueryCommand, UpdateCommand } from "@aws-sdk/lib-dynamodb";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { v4 as uuidv4 } from 'uuid';
import { SSMClient, GetParameterCommand } from '@aws-sdk/client-ssm';
const ddbDocClient = DynamoDBDocumentClient.from(new DynamoDBClient());
const ssmClient = new SSMClient();

export const handler = async (event) => {
    const subjectid = event.pathParameters.subjectid;
    if (subjectid === ":subjectid" || subjectid === "%20" || subjectid === ":%7Bsubjectid%7D") {
        return {
            statusCode: 400,
            headers: {
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({ error: "Missing parameters" }),
        };
    }

    const date = new Date().toISOString();
    const uuid = uuidv4();

    var dynamodbTableName = await ssmClient.send(new GetParameterCommand({
        Name: process.env.dynamodbTableName
    }));
    dynamodbTableName = dynamodbTableName.Parameter.Value;

    try {
        const requestBody = JSON.parse(event.body);

        let params = {
            TableName: dynamodbTableName,
            KeyConditionExpression: 'pk = :pk and sk = :sk',
            ExpressionAttributeValues: {
                ':pk': `subjects`,
                ':sk': `subject#${subjectid}`
            },
        };
        const data = await ddbDocClient.send(new QueryCommand(params));
        const transactParams = {
            TransactItems: [
                {
                    Put: {
                        TableName: dynamodbTableName,
                        Item: {
                            pk: "devices",
                            sk: "device#" + uuid,
                            createdAt: date,
                            createdBy: requestBody.createdBy,
                            updatedAt: date,
                            updatedBy: requestBody.createdBy,
                            deviceId: uuid,
                            deviceType: requestBody.deviceType,
                            deviceDescription: requestBody.deviceDescription,
                            subjectId: subjectid
                        },
                    },
                },
                {
                    Put: {
                        TableName: dynamodbTableName,
                        Item: {
                            pk: "subjects",
                            sk: "device-subject#subject#" + subjectid + "#device#" + uuid,
                            createdAt: date,
                            createdBy: requestBody.createdBy,
                            updatedAt: date,
                            updatedBy: requestBody.createdBy,
                            deviceId: uuid,
                            deviceType: requestBody.deviceType,
                            deviceDescription: requestBody.deviceDescription,
                            subjectId: subjectid,
                            subjectName: requestBody.subjectName,
                            cohortId: data.Items[0].cohortId,
                            cohortName: data.Items[0].cohortName,
                            numberOfDevices: data.Items[0].numberOfDevices,
                            subjectDescription: data.Items[0].subjectDescription
                        },
                    },
                },
                {
                    Update: {
                        TableName: dynamodbTableName,
                        Key: {
                            pk: "subjects",
                            sk: "subject#" + subjectid
                        },
                        UpdateExpression: "SET numberOfDevices = if_not_exists(numberOfDevices, :start) + :inc",
                        ExpressionAttributeValues: {
                            ':inc': 1,
                            ':start': 0,
                        },
                    }
                },
                 {
                    Update: {
                        TableName: dynamodbTableName,
                        Key: {
                            pk: "cohorts",
                            sk: "subject-cohort#cohort#" + data.Items[0].cohortId+ "#subject#" +subjectid
                        },
                        UpdateExpression: "SET numberOfDevices = if_not_exists(numberOfDevices, :start) + :inc",
                        ExpressionAttributeValues: {
                            ':inc': 1,
                            ':start': 0,
                        },
                    }
                }
            ]
        };

        await ddbDocClient.send(new TransactWriteCommand(transactParams));

        const updateSubjectDevicesParams = {
            TableName: dynamodbTableName,
            Key: {
                pk: "subjects",
                sk: "device-subject#subject#" + subjectid + "#device#" + uuid,
            },
            UpdateExpression: "SET numberOfDevices = if_not_exists(numberOfDevices, :start) + :inc",
            ExpressionAttributeValues: {
                ':inc': 1,
                ':start': 0,
            },
        };
        await ddbDocClient.send(new UpdateCommand(updateSubjectDevicesParams));

        return {
            statusCode: 200,
            body: JSON.stringify({ "Device Created": uuid }),
            headers: {
                'Access-Control-Allow-Origin': '*',
            }
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: "Internal Server Error", details: err.message }),
            headers: {
                'Access-Control-Allow-Origin': '*',
            }
        };
    }
};