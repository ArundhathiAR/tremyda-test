import { S3Client, GetObjectCommand } from "@aws-sdk/client-s3";
import { SQSClient, SendMessageCommand } from "@aws-sdk/client-sqs";
import { SSMClient, GetParameterCommand } from "@aws-sdk/client-ssm";
import {
  DynamoDBDocumentClient,
  PutCommand,
  UpdateCommand,
  QueryCommand,
  TransactWriteCommand,
} from "@aws-sdk/lib-dynamodb";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { v4 as uuidv4 } from "uuid";
const ssmClient = new SSMClient();
const s3Client = new S3Client();
const sqsClient = new SQSClient();
const ddb = DynamoDBDocumentClient.from(new DynamoDBClient({}));

export const handler = async (event) => {
  try {
    var sqsFormattedJsonUrl = await ssmClient.send(
      new GetParameterCommand({
        Name: process.env.sqsFormattedJsonUrl,
      })
    );
    sqsFormattedJsonUrl = sqsFormattedJsonUrl.Parameter.Value;
    var dynamodbTableName = await ssmClient.send(
      new GetParameterCommand({
        Name: process.env.dynamodbTableName,
      })
    );  
    dynamodbTableName = dynamodbTableName.Parameter.Value;
    const date = new Date();
    const uuid = uuidv4();
    const s3Bucket = event.Records[0].s3.bucket.name;
    
    // const s3Key = event.Records[0].s3.object.key;
    // const jsonObject = await s3Client.send(
    //   new GetObjectCommand({ Bucket: s3Bucket, Key: s3Key })
    // );
    
    // const fileReader = Buffer.from(
    //   await streamToBuffer(jsonObject.Body)
    // ).toString("utf-8");
    // const json_data = `[${fileReader.replace(/}{/g, "},{")}]`;
    // const formattedJson = { records: JSON.parse(json_data) };
    // const singleRecord = formattedJson.records[0];
    
    
    
    // added static s3 object key for testing purpose, please remove once testing is done
    const s3Key = event.Records[0].s3.object.key;
    const jsonObjectPayload = await s3Client.send(
      new GetObjectCommand({ Bucket: s3Bucket, Key: s3Key })
    );
    
    //console.log({jsonObjectPayload});
    
    const fileReader = Buffer.from(
      await streamToBuffer(jsonObjectPayload.Body)
    ).toString("utf-8");
    const json_data = `[${fileReader.replace(/}{/g, "},{")}]`;
    const formattedJson = { records: JSON.parse(json_data) };
    const singleRecord = formattedJson.records[0];
    const deviceCreatedDate = new Date(singleRecord.deviceCreated);
    const currentDate = date.toISOString().split("T")[0];

    const GetEventparams = {
      TableName: dynamodbTableName,
      KeyConditionExpression: "pk = :pk and begins_with(sk, :sk)",
      ExpressionAttributeValues: {
        ":pk": "events",
        ":sk": `event-device-subject#subject#${singleRecord.subjectId}#device#${singleRecord.deviceId}#event`,
        ":date": currentDate,
      },
      FilterExpression: "begins_with(readingStart, :date)",
    };

    const data = await ddb.send(new QueryCommand(GetEventparams));

    const sortedEvents = data.Items.sort(
      (a, b) =>
        new Date(b.readingStart).getTime() - new Date(a.readingStart).getTime()
    );

    if (
      !data.Count > 0 ||
      !isCurrentTimeLessThanOrEqualTo(sortedEvents[0].readingStop)
    ) {
      const { readingStart, readingStop } = getRoundedReadingTimes();
      
      const params = {
          TransactItems: [
            {
                Put: {
                    TableName: dynamodbTableName,
                    Item: {
                      pk: "events",
                      sk: `event-device-subject#subject#${singleRecord.subjectId}#device#${singleRecord.deviceId.trim()}#event#${uuid}`,
                      eventType: "dataset",
                      readingStart: readingStart,
                      readingStop: readingStop,
                      deviceId: singleRecord.deviceId.trim(),
                      subjectId: singleRecord.subjectId,
                      cohortId: singleRecord.cohortId,
                      siteId: singleRecord.siteId,
                    },
                  }
              },
            {
                Update: {
                    TableName: dynamodbTableName,
                    Key: {
                        pk: "counter",
                        sk: `event#createdDate#${currentDate}`
                    },
                    UpdateExpression: "SET numberOfEvents = if_not_exists(numberOfEvents, :start) + :inc",
                    ExpressionAttributeValues: {
                        ':inc': 1,
                        ':start': 0,
                      },
                  }
              },
            {
                Put: {
                    TableName: dynamodbTableName,
                    Item: {
                        pk: "updates",
                        sk: date.toISOString(),
                        deviceId: singleRecord.deviceId,
                        subjectId: singleRecord.subjectId,
                        type : "event",
                        action: "create",
                        createdAt: date.toISOString()
                      },
                  }
              }
            ]
        };

      
      
      await ddb.send(new TransactWriteCommand(params));
  }


    for (let record of updatedJSON) {
      const params = {
        MessageGroupId: "test",
        MessageBody: JSON.stringify(record),
        QueueUrl: sqsFormattedJsonUrl,
      };
      await sqsClient.send(new SendMessageCommand(params));
      count = count + 1;
    }
    console.log(count);
    return {
      statusCode: 200,
    };
  } catch (err) {
    console.log(err);
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: "Internal Server Error",
        details: err.message,
      }),
    };
  }
};

// Helper function to convert stream to buffer
const streamToBuffer = async (stream) => {
  return new Promise((resolve, reject) => {
    const chunks = [];
    stream.on("data", (chunk) => chunks.push(chunk));
    stream.on("end", () => resolve(Buffer.concat(chunks)));
    stream.on("error", (error) => reject(error));
  });
};

function isCurrentTimeLessThanOrEqualTo(givenTime) {
  const currentTime = new Date().toISOString();

  return currentTime <= givenTime;
}

function getRoundedReadingTimes() {
  const currentTime = new Date();

  const minutes = currentTime.getUTCMinutes();
  const roundedMinutes = Math.floor(minutes / 15) * 15;

  const readingStart = new Date(
    Date.UTC(
      currentTime.getUTCFullYear(),
      currentTime.getUTCMonth(),
      currentTime.getUTCDate(),
      currentTime.getUTCHours(),
      roundedMinutes,
      0
    )
  );
  const readingStop = new Date(readingStart.getTime() + 15 * 60000);

  return {
    readingStart: readingStart.toISOString(),
    readingStop: readingStop.toISOString(),
  };
}

// this function is only for creating events with custom dates
function getReadingTimesFromDeviceCreated(deviceCreated) {
  const readingStop = new Date(
    deviceCreated.getTime() + 15 * 60 * 1000
  ).toISOString();

  return {
    readingStart: deviceCreated.toISOString(),
    readingStop: readingStop.toISOString(),
  };
}
