import {
  DynamoDBDocumentClient,
  PutCommand,
  UpdateCommand,
} from "@aws-sdk/lib-dynamodb";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { v4 as uuidv4 } from "uuid";
import { SSMClient, GetParameterCommand } from "@aws-sdk/client-ssm";
const ddbDocClient = DynamoDBDocumentClient.from(new DynamoDBClient());
const ssmClient = new SSMClient();

export const handler = async (event) => {
  console.log(event);
  var dynamodbTableName = await ssmClient.send(
    new GetParameterCommand({
      Name: process.env.dynamodbTableName,
    })
  );
  dynamodbTableName = dynamodbTableName.Parameter.Value;

  const date = new Date().toISOString();
  const uuid = uuidv4();
  const requestBody = JSON.parse(event.body);

  try {
    const params = {
      TableName: dynamodbTableName,
      Item: {
        pk: "sites",
        sk: "site#" + uuid,
        siteName: requestBody.siteName,
        createdAt: date,
        createdBy: requestBody.createdBy,
        updatedAt: date,
        updatedBy: requestBody.createdBy,
        siteId: uuid,
        siteStatus: "active",
        numberOfSubjects: 0,
        numberOfCohorts: 0,
        siteAddress: requestBody.siteAddress,
        contactName: requestBody.contactName,
        contactEmail: requestBody.contactEmail,
      },
    };
    await ddbDocClient.send(new PutCommand(params));
  } catch (err) {
    console.log(err);
    return {
      statusCode: 500,
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({
        error: "Internal Server Error",
        details: err.message,
      }),
    };
  }
  try {
    const params = {
      TableName: dynamodbTableName,
      Item: {
        pk: "updates",
        sk: date,
        name: requestBody.siteName,
        siteId: uuid,
        type: "site",
        action: "create",
        createdAt: date,
      },
    };
    await ddbDocClient.send(new PutCommand(params));
  } catch (err) {
    console.log(err);
    return {
      statusCode: 500,
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({
        error: "Internal Server Error",
        details: err.message,
      }),
    };
  }

  try {
    const params = {
      TableName: dynamodbTableName,
      Key: {
        pk: "counter",
        sk: "count",
      },
      UpdateExpression:
        "SET numberOfSites = if_not_exists(numberOfSites, :start) + :inc",
      ExpressionAttributeValues: {
        ":inc": 1,
        ":start": 0,
      },
    };
    await ddbDocClient.send(new UpdateCommand(params));
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({
        "Site Created": uuid,
      }),
    };
  } catch (err) {
    console.log(err);
    return {
      statusCode: 500,
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({
        error: "Internal Server Error",
        details: err.message,
      }),
    };
  }
};
