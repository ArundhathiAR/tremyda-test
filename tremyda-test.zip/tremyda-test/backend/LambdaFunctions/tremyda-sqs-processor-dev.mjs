import { DynamoDBDocumentClient, QueryCommand } from "@aws-sdk/lib-dynamodb";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { SQSClient, SendMessageCommand } from "@aws-sdk/client-sqs";
import { SSMClient, GetParameterCommand } from '@aws-sdk/client-ssm';
const ssmClient = new SSMClient();
const sqsClient = new SQSClient();
const ddb = DynamoDBDocumentClient.from(new DynamoDBClient({}));
let dynamodbTableNameParam = await ssmClient.send(new GetParameterCommand({
    Name: process.env.dynamodbTableName
}));
const dynamodbTableName = dynamodbTableNameParam.Parameter.Value;

const queryDdb = async (partitionKey, sortKey) => {
    const params = {
        TableName: dynamodbTableName,
        KeyConditionExpression: "pk = :pk and sk = :sk",
        ExpressionAttributeValues: {
            ":pk": partitionKey,
            ":sk": sortKey,
        },
    };
    const data = await ddb.send(new QueryCommand(params));
    return data;
};

export const handler = async (event) => {
    let sqsProcessedJsonUrlParam = await ssmClient.send(new GetParameterCommand({
        Name: process.env.sqsProcessedJsonUrl
    }));
    const sqsProcessedJsonUrl = sqsProcessedJsonUrlParam.Parameter.Value;

    try {
        const record = JSON.parse(event.Records[0].body);
        const cohortId = record.cohortId;
        const siteId = record.siteId;
        const subjectId = record.subjectId;

        const cohortData = await queryDdb("cohorts", `cohort#${cohortId}`);
        if (cohortData.Count === 0) {
            console.log("Error in cohort ID");
            throw new Error("Cohort ID not found");
        }

        const siteData = await queryDdb("sites", `site#${siteId}`);
        if (siteData.Count === 0) {
            console.log("Error in site ID");
            throw new Error("Site ID not found");
        }

        const subjectData = await queryDdb("subjects", `subject#${subjectId}`);
        if (subjectData.Count === 0) {
            console.log("Error in subject ID");
            throw new Error("Subject ID not found");
        }

        const params = {
            MessageGroupId: "test-2",
            MessageBody: JSON.stringify(record),
            QueueUrl: sqsProcessedJsonUrl,
        };
        await sqsClient.send(new SendMessageCommand(params));

        return {
            statusCode: 200,
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: "Internal Server Error", details: err.message }),
        };
    }
};