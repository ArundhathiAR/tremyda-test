import { DynamoDBDocumentClient, PutCommand } from "@aws-sdk/lib-dynamodb";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { SSMClient, GetParameterCommand } from '@aws-sdk/client-ssm';
import { v4 as uuidv4 } from 'uuid';
const ddb = DynamoDBDocumentClient.from(new DynamoDBClient({}));
const ssmClient = new SSMClient();
export const handler = async (event) => {
    try {
        var dynamodbTableName = await ssmClient.send(new GetParameterCommand({
            Name: process.env.dynamodbTableName
        }));
        dynamodbTableName = dynamodbTableName.Parameter.Value;
        const uuid = uuidv4();
        const record = JSON.parse(event.Records[0].body);
        const createdAt = new Date().toISOString();
        let item = {
            pk: 'readings',
            sk: `subject#${record.subjectId}#device#${record.deviceId.trim()}#createdAt#${createdAt}#uuid#${uuid}`,
            cohortId: record.cohortId,
            siteId: record.siteId,
            subjectId: record.subjectId,
            createdAt: createdAt,
            createdBy: record.createdBy,
            deviceCreated: record.deviceCreated,
            deviceId: record.deviceId.trim()
        };
        if (record.m_label && record.n_label) {
            item.values = [
                {
                    m_label: record.m_label,
                    m_value: record.m_value,
                    m_units: record.m_units
                },
                {
                    n_label: record.n_label,
                    n_units: record.n_units,
                    n_value: record.n_value
                }
            ];
        } else {
            item.value = {
                m_label: record.m_label,
                m_value: record.m_value,
                m_units: record.m_units
            };
        }
        const params = {
            TableName: dynamodbTableName,
            Item: item
        };
        await ddb.send(new PutCommand(params));
        return {
            statusCode: 200,
            body: JSON.stringify({ msg: 'Success' }),
        };
    } catch (error) {
        console.error(error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Internal Server Error', details: error.message }),
        };
    }
};