import { DynamoDBDocumentClient, TransactWriteCommand, QueryCommand } from "@aws-sdk/lib-dynamodb";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { SSMClient, GetParametersCommand } from '@aws-sdk/client-ssm';
import { SQSClient, SendMessageBatchCommand } from "@aws-sdk/client-sqs";

const ddbDocClient = DynamoDBDocumentClient.from(new DynamoDBClient());
const ssmClient = new SSMClient();
const sqsClient = new SQSClient();

export const handler = async (event) => {
    let cohortid, siteid;
    
    try{
    
        if (event.pathParameters) {  
            console.log("from api gateway ..........");
            cohortid = event.pathParameters.cohortid;
            siteid = event.pathParameters.siteid;
            if (cohortid === ":cohortid" || cohortid === "%20" || cohortid === ":%7Bcohortid%7D" || siteid === ":siteid" || siteid === "%20" || siteid === ":%7Bsiteid%7D") {
                return {
                    statusCode: 400,
                    headers: {
                        'Access-Control-Allow-Origin': '*'
                    },
                    body: JSON.stringify({ error: "Missing parameters" }),
                };
            }
        }
        else if(event.Records && event.Records[0].eventSource === "aws:sqs"){
            console.log("from SQS .........., event");
            console.log(event.Records);
            const messageBody = JSON.parse(event.Records[0].body);
            cohortid = messageBody.cohortid;
            siteid = messageBody.siteid;
        }
        else {
            return {
                statusCode: 400,
                headers: {
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({ error: "Invalid event format" }),
            };
        }
        
        const parameterNames = [
          process.env.dynamodbTableName,
          process.env.sqsDeleteSubjectUrl,
          ];
          
        let parameters = {};
        
        try {
            
            const ssmParams = await ssmClient.send(new GetParametersCommand({ Names: parameterNames }));
            ssmParams.Parameters.forEach(param => parameters[param.Name] = param.Value);
        } catch (err) {
            return {
                statusCode: 500,
                body: JSON.stringify({ message: 'Failed to fetch parameters from SSM', details: err.message }),
                headers: { 'Access-Control-Allow-Origin': '*' }
            };
        }
    
        const dynamodbTableName = parameters[process.env.dynamodbTableName];
        
        console.log(parameters);
        
        const getParams = {
            TableName: dynamodbTableName,
            KeyConditionExpression: 'pk = :pk and sk = :sk',
            ExpressionAttributeValues: {
                ':pk': `cohorts`,
                ':sk': `cohort#${cohortid}`
            },
        };
        const data = await ddbDocClient.send(new QueryCommand(getParams));
    
        if (data.Items[0].cohortStatus === "deleted") {
            return {
                statusCode: 200,
                body: JSON.stringify({
                    msg: "Already deleted"
                }),
                headers: {
                    'Access-Control-Allow-Origin': '*',
                }
            };
        }
    
        const transactWriteParams = {
            TransactItems: [
                {
                    Update: {
                        TableName: dynamodbTableName,
                        Key: {
                            pk: "cohorts",
                            sk: "cohort#" + cohortid
                        },
                        UpdateExpression: "SET cohortStatus = :cohortStatus",
                        ExpressionAttributeValues: {
                            ':cohortStatus': "deleted",
                        },
                    }
                },
                {
                    Update: {
                        TableName: dynamodbTableName,
                        Key: {
                            pk: "sites",
                            sk: "cohort-site#site#" + siteid + "#cohort#" + cohortid
                        },
                        UpdateExpression: "SET cohortStatus = :cohortStatus",
                        ExpressionAttributeValues: {
                            ':cohortStatus': "deleted",
                        },
                    }
                },
                {
                    Update: {
                        TableName: dynamodbTableName,
                        Key: {
                            pk: "counter",
                            sk: "count"
                        },
                        UpdateExpression: "SET numberOfCohorts = if_not_exists(numberOfCohorts, :start) - :dec",
                        ConditionExpression: "numberOfCohorts >= :dec OR attribute_not_exists(numberOfCohorts)",
                        ExpressionAttributeValues: {
                            ':dec': 1,
                            ':start': 0
                        },
                    }
                },
                {
                    Update: {
                        TableName: dynamodbTableName,
                        Key: {
                            pk: "sites",
                            sk: "site#" + siteid
                        },
                        UpdateExpression: "SET numberOfCohorts = if_not_exists(numberOfCohorts, :start) - :dec",
                        ConditionExpression: "numberOfCohorts >= :dec OR attribute_not_exists(numberOfCohorts)",
                        ExpressionAttributeValues: {
                            ':dec': 1,
                            ':start': 0
                        },
                    }
                }
            ]
        };


        await ddbDocClient.send(new TransactWriteCommand(transactWriteParams));
        
        // get subject and send to SQS
        try {
            const getCohortSubjectParams = {
                TableName: dynamodbTableName,
                KeyConditionExpression: 'pk = :pk and begins_with(sk, :sk)',
                ExpressionAttributeValues: {
                    ':pk': `cohorts`,
                    ':sk': `subject-cohort#cohort#${cohortid}`
                },
            };
        
            // Query the DynamoDB table to get the subjects
            const subjects = await ddbDocClient.send(new QueryCommand(getCohortSubjectParams));
            
            console.log(subjects,  {
                    ':pk': `cohorts`,
                    ':sk': `subject-cohort#cohort#${cohortid}`
                },);
    
            
            if(subjects?.Items.length > 0){
    
                // Prepare data to be sent to SQS
                const dataArray = subjects.Items.map(item => ({
                    subjectid: item.subjectId,
                    cohortid: cohortid
                }));
                
                console.log(dataArray);
        
                // Send the data to SQS in batches
                await sendMessagesToSQS(dataArray, parameters[process.env.sqsDeleteSubjectUrl]);
            }
        } catch (err) {
            return {
                statusCode: 500,
                body: JSON.stringify({ error: "Error while deleting cohort subjects", details: err.message }),
                headers: {
                    'Access-Control-Allow-Origin': '*',
                }
            };
        }
        
        return {
            statusCode: 200,
            body: JSON.stringify({
                msg: "deleted"
            }),
            headers: {
                'Access-Control-Allow-Origin': '*',
            }
        };
    } catch (err) {
        let errorMsg = "Internal Server Error";
        if (err.name === 'ConditionalCheckFailedException') {
            errorMsg = "Cannot decrement to a negative ";
        }
        return {
            statusCode: 500,
            body: JSON.stringify({ error: errorMsg, details: err.message }),
            headers: {
                'Access-Control-Allow-Origin': '*',
            }
        };
    }
};


// Utility function to split array into chunks
const chunkArray = (array, chunkSize) => {
    const results = [];
    for (let i = 0; i < array.length; i += chunkSize) {
        results.push(array.slice(i, i + chunkSize));
    }
    return results;
};

// Function to send messages to SQS in batches
const sendMessagesToSQS = async (dataArray, queueUrl) => {
    // Chunk the data array into batches of 10 (SQS limit)
    const batches = chunkArray(dataArray, 10);
    
    for (const batch of batches) {
        const entries = batch.map((item, index) => ({
            Id: `${index}`, // Unique identifier for each message in the batch
            MessageBody: JSON.stringify({
                subjectid: item.subjectid,
                cohortid: item.cohortid,
            }),
        }));

        const params = {
            QueueUrl: queueUrl,
            Entries: entries,
        };

        try {
            const result = await sqsClient.send(new SendMessageBatchCommand(params));
            console.log(`Batch sent successfully:`, result);
        } catch (error) {
            console.error("Error sending batch to SQS:", error);
        }
    }
};