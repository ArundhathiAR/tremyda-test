import { DynamoDBDocumentClient, QueryCommand } from "@aws-sdk/lib-dynamodb";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { SSMClient, GetParameterCommand } from "@aws-sdk/client-ssm";
const ddb = DynamoDBDocumentClient.from(new DynamoDBClient());
const ssmClient = new SSMClient();

export const handler = async (event, context) => {
  const cohortid = event.pathParameters.cohortid;
  if (
    cohortid === ":cohortid" ||
    cohortid === "%20" ||
    cohortid === ":%7Bcohortid%7D"
  ) {
    return {
      statusCode: 400,
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({ error: "Missing parameters" }),
    };
  }

  var dynamodbTableName = await ssmClient.send(
    new GetParameterCommand({
      Name: process.env.dynamodbTableName,
    })
  );
  dynamodbTableName = dynamodbTableName.Parameter.Value;

  if (event.queryStringParameters && event.queryStringParameters.action) {
    const params = {
      TableName: dynamodbTableName,
      KeyConditionExpression: "pk = :pk and begins_with(sk, :sk)",
      ExpressionAttributeValues: {
        ":pk": "subjects",
        ":sk": "subject#",
      },
      ProjectionExpression: "subjectId, subjectName",
    };

    try {
      const data = await ddb.send(new QueryCommand(params));
      return {
        statusCode: 200,
        body: JSON.stringify({
          items: data.Items,
          count: data.Count,
        }),
        headers: {
          "Access-Control-Allow-Origin": "*",
        },
      };
    } catch (err) {
      return {
        statusCode: 500,
        body: JSON.stringify({
          error: "Internal Server Error",
          details: err.message,
        }),
        headers: {
          "Access-Control-Allow-Origin": "*",
        },
      };
    }
  }

  const {
    pageSize = 10,
    pageToken,
    status = "active",
  } = event.queryStringParameters || {};
  const pageSizeInt = parseInt(pageSize, 10);

  const params = {
    TableName: dynamodbTableName,
    KeyConditionExpression: "pk = :pk and begins_with(sk, :sk)",
    ExpressionAttributeValues: {
      ":pk": "cohorts",
      ":sk": `subject-cohort#cohort#${cohortid}#subject`,
      ":subjectStatus": status,
    },
    FilterExpression: "subjectStatus = :subjectStatus",
  };

  try {
    const data = await ddb.send(new QueryCommand(params));

    const allItems = data.Items.map((item) => {
      const { pk, ...filteredItem } = item;
      return filteredItem;
    }).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

    const startIndex = pageToken
      ? parseInt(
          Buffer.from(pageToken, "base64").toString("utf-8").slice(8),
          10
        )
      : 0;
    const paginatedItems = allItems.slice(startIndex, startIndex + pageSizeInt);
    const nextPageToken =
      startIndex + pageSizeInt < allItems.length
        ? Buffer.from(`pageidx:${startIndex + pageSizeInt}`).toString("base64")
        : null;

    return {
      statusCode: 200,
      body: JSON.stringify({
        items: paginatedItems,
        count: paginatedItems.length,
        nextPageToken,
      }),
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
    };
  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: "Internal Server Error",
        details: err.message,
      }),
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
    };
  }
};
