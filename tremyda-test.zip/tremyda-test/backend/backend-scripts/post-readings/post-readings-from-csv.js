const fs = require("fs");
const path = require("path");
const csv = require("csv-parser");
const axios = require("axios");
// development env
const baseUrl = "https://eso28vs64b.execute-api.ap-south-1.amazonaws.com/dev";

// UAT
// const baseUrl = "https://xf63lfxiy1.execute-api.us-west-1.amazonaws.com/dev";


const deviceData = {
  siteId: "56e61d32-e18b-424c-9927-abf48eec49f7",
  cohortId: "f041e70c-d03f-46a8-b141-61b5cc264f22",
  subjectId: "279b0127-9b72-4d01-ad02-4f394036d0a4",
  deviceId: "f3ddec55-c076-40ce-aa64-41103a991f23",
  createdBy: "admin",
};

const defaultDeviceCreated = new Date();
const readingsInterval = 30; // Interval in minutes

const recordLabels = {
  n_label: "Voltage",
  n_units: "V",
  m_label: "Current",
  m_units: "A",
};

const readingsFolder = path.join(__dirname, "readings");

async function processCSVFiles() {
  try {
    const files = await fs.promises.readdir(readingsFolder);
    for (let index = 0; index < files.length; index++) {
      const file = files[index];
      const filePath = path.join(readingsFolder, file);

      if (path.extname(file) === ".csv") {
        const fileDeviceCreated = new Date(defaultDeviceCreated);
        fileDeviceCreated.setMinutes(
          defaultDeviceCreated.getMinutes() + index * readingsInterval
        );

        const records = [];

        await new Promise((resolve, reject) => {
          fs.createReadStream(filePath)
            .pipe(
              csv({
                mapHeaders: ({ header }) => header.trim(), // Trim whitespace from headers
                mapValues: ({ value }) => value.trim(), // Trim whitespace from values
              })
            )
            .on("data", (row) => {
              if (row["Potential/V"] && row["Current/A"]) {
                const record = {
                  n_value: row["Potential/V"],
                  m_value: row["Current/A"],
                };
                records.push(record);
              }
            })
            .on("end", resolve)
            .on("error", reject);
        });

        const formattedData = {
          Records: records.map((record, index) => {
            const deviceDate = new Date(fileDeviceCreated);
            deviceDate.setSeconds(fileDeviceCreated.getSeconds() + index * 1);
            return {
              Data: JSON.stringify({
                ...deviceData,
                deviceCreated: new Date(deviceDate).toISOString(),
                m_label: recordLabels.m_label,
                m_units: recordLabels.m_units,
                n_label: recordLabels.n_label,
                n_units: recordLabels.n_units,
                m_value: record.m_value,
                n_value: record.n_value,
              }),
            };
          }),
        };

        // console.log(JSON.stringify(formattedData, null, 2));
        // setTimeout(async () => {
        await postReadingsData(formattedData);
        // }, 1000);
      }
    }
  } catch (error) {
    console.error("Error processing CSV files:", error);
  }
}

async function postReadingsData(formattedData) {
  const apiEndpoint = `${baseUrl}/subjects/${deviceData.subjectId}/devices/${deviceData.deviceId}/readings`;

  try {
    const response = await axios.post(apiEndpoint, formattedData);
    console.log(
      "Readings sent successfully:",
      response,
      response.status,
      response.data,
      "Batch size:",
      formattedData?.Records?.length
    );
    // console.log(response?.data);
  } catch (error) {
    console.error("Error sending data:", error);
  }
}

// Execute the main function
processCSVFiles();
